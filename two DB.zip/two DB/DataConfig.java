package com.example.config;

import java.util.Properties;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.core.env.Environment;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.jdbc.datasource.DriverManagerDataSource;
import org.springframework.orm.hibernate4.HibernateTransactionManager;
import org.springframework.orm.hibernate4.LocalSessionFactoryBean;
import org.springframework.transaction.annotation.EnableTransactionManagement;

import com.example.dao.EmployeeJPARepository;
import com.example.model.Employee;

//@Component
//@PropertySource("classpath:application.properties")
@Configuration
@EnableTransactionManagement
/*
 * @EnableJpaRepositories(basePackageClasses = Employee.class,
 * entityManagerFactoryRef = "EmployeeJPARepository")
 */
public class DataConfig {

	@Autowired
	private Environment env;

	/*
	 * @Autowired private DataSource dataSource;
	 * 
	 * @Autowired private DataSource dataSource2;
	 */

	@Value("${db.driver}")
	private String DB_DRIVER;

	@Value("${db.password}")
	private String DB_PASSWORD;

	@Value("${db.url}")
	private String DB_URL;

	@Value("${db.username}")
	private String DB_USERNAME;

	@Value("${hibernate.dialect}")
	private String HIBERNATE_DIALECT;

	@Value("${hibernate.show_sql}")
	private String HIBERNATE_SHOW_SQL;

	@Value("${hibernate.hbm2ddl.auto}")
	private String HIBERNATE_HBM2DDL_AUTO;

	@Value("${entitymanager.packagesToScan}")
	private String ENTITYMANAGER_PACKAGES_TO_SCAN;

	@Value("${db2.driver}")
	private String DB2_DRIVER;

	@Value("${db2.password}")
	private String DB2_PASSWORD;

	@Value("${db2.url}")
	private String DB2_URL;

	@Value("${db2.username}")
	private String DB2_USERNAME;

	@Value("${hibernate2.dialect}")
	private String HIBERNATE2_DIALECT;

	@Value("${hibernate2.show_sql}")
	private String HIBERNATE2_SHOW_SQL;

	@Value("${hibernate2.hbm2ddl.auto}")
	private String HIBERNATE2_HBM2DDL_AUTO;

	@Value("${entitymanager2.packagesToScan}")
	private String ENTITYMANAGER2_PACKAGES_TO_SCAN;

	@Primary
	@Bean(name = "dataSource")
	public DataSource dataSource() {
		DriverManagerDataSource dataSource = new DriverManagerDataSource();
		dataSource.setDriverClassName(env.getProperty("db.driver"));
		dataSource.setUrl(DB_URL);
		dataSource.setUsername(DB_USERNAME);
		dataSource.setPassword(DB_PASSWORD);
		System.out.println("DB_URL*********" + DB_URL
				+ "DB_USERNAME*************  " + DB_USERNAME);
		return dataSource;
	}

	@Bean(name = "sessionFactory")
	public LocalSessionFactoryBean sessionFactory() {
		LocalSessionFactoryBean sessionFactoryBean = new LocalSessionFactoryBean();
		sessionFactoryBean.setDataSource(dataSource());
		sessionFactoryBean.setPackagesToScan(ENTITYMANAGER_PACKAGES_TO_SCAN);
		Properties hibernateProperties = new Properties();
		System.out.println("HIBERNATE_DIALECT is:************************** "
				+ HIBERNATE_DIALECT + env.getProperty("hibernate.dialect "));
		hibernateProperties.put("hibernate.dialect", HIBERNATE_DIALECT);
		hibernateProperties.put("hibernate.show_sql", HIBERNATE_SHOW_SQL);
		hibernateProperties.put("hibernate.hbm2ddl.auto",
				HIBERNATE_HBM2DDL_AUTO);
		sessionFactoryBean.setHibernateProperties(hibernateProperties);

		return sessionFactoryBean;

	}

	@Bean(name = "transactionManager")
	public HibernateTransactionManager transactionManager() {
		HibernateTransactionManager transactionManager = new HibernateTransactionManager();
		transactionManager.setSessionFactory(sessionFactory().getObject());
		System.out.println("TM1&&&&&&&&&&&&&&&&&&&&&" + transactionManager);
		return transactionManager;
	}

	@Bean(name = "dataSource2")
	public DataSource dataSource2() {
		DriverManagerDataSource dataSource = new DriverManagerDataSource();
		dataSource.setDriverClassName(env.getProperty("db2.driver"));
		System.out.println("DB2_URL*********" + DB2_URL
				+ "DB2_USERNAME*************  " + DB2_USERNAME);
		dataSource.setUrl(DB2_URL);
		dataSource.setUsername(DB2_USERNAME);
		dataSource.setPassword(DB2_PASSWORD);
		return dataSource;
	}

	@Bean(name = "sessionFactory2")
	public LocalSessionFactoryBean sessionFactory2() {
		LocalSessionFactoryBean sessionFactoryBean = new LocalSessionFactoryBean();
		sessionFactoryBean.setDataSource(dataSource2());
		sessionFactoryBean.setPackagesToScan(ENTITYMANAGER2_PACKAGES_TO_SCAN);
		Properties hibernateProperties = new Properties();
		System.out.println("HIBERNATE_DIALECT is: &&&&&&&&&&&&&&&&&"
				+ HIBERNATE2_DIALECT + env.getProperty("hibernate.dialect"));
		hibernateProperties.put("hibernate.dialect", HIBERNATE2_DIALECT);
		hibernateProperties.put("hibernate.show_sql", HIBERNATE2_SHOW_SQL);
		hibernateProperties.put("hibernate.hbm2ddl.auto",
				HIBERNATE2_HBM2DDL_AUTO);
		sessionFactoryBean.setHibernateProperties(hibernateProperties);

		return sessionFactoryBean;

	}

	@Bean(name = "transactionManager2")
	public HibernateTransactionManager transactionManager2() {
		HibernateTransactionManager transactionManager = new HibernateTransactionManager();
		transactionManager.setSessionFactory(sessionFactory2().getObject());
		System.out.println("TM2*******************************"
				+ transactionManager);
		return transactionManager;
	}

}
