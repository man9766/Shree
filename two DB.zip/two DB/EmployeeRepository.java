package com.example.dao;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.data.repository.CrudRepository;

import com.example.model.Employee;

//@Transactional
@EnableJpaRepositories(transactionManagerRef="transactionManager")
public interface EmployeeRepository extends CrudRepository<Employee, Integer> {

	List<Employee> findAll();

	/*
	 * @Query("select em.lastName from employee em where em.id = ?1") Employee
	 * findByLastname(String lastname);
	 */

	List<Employee> findBylastName(String lastName);

	@Modifying
	@Query("delete  from Employee u where u.empId = ?1")
	void delete(Integer empId);

	// @Query(value = "SELECT * FROM employee2 WHERE lastName = ?1", countQuery
	// = "SELECT count(*) FROM employee2 WHERE lastName = ?1", nativeQuery =
	// true)
	Page<Employee> findBylastName(String lastname, Pageable pageable);

	Iterable<Employee> findAll(Sort sort);
Employee save(Employee e);
	Page<Employee> findAll(Pageable pageable);

	List<Employee> findByfirstName(String firstName);

	List<Employee> findByFirstNameOrderByEmpIdAsc(int empId);
	// List<Employee>findBylastNameOrfirstName(String firstName, String
	// lastName);

}
