package com.example.dao;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.example.model.Address;
@Transactional
@EnableJpaRepositories(transactionManagerRef="transactionManager2")
public interface AddressRepository extends CrudRepository<Address, Integer> {
	
	Address save(Address address);
	
	

}
