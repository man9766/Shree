/*package com.apmoller.mock;

import com.apmoller.main.dao.CbeProcessInputDataDao;
import com.apmoller.main.model.RequestData;
import com.apmoller.main.model.ResponseData;

public class MockCbeProcessInputDataDaoImpl implements CbeProcessInputDataDao{

	ResponseData responseData = new ResponseData();
	
	@Override
	public ResponseData processInputData(RequestData requestData) {
		
		if ("ABC".equals(requestData.getOperater()))
			responseData.setMessage("Request has been processed Successfully!!");
		    responseData.setResponseCode("SUCCESS00");
		
		return responseData;
	}

}
*/