package com.apmoller.utility;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.apmoller.main.controller.CBEController;
import com.apmoller.main.model.RequestData;

@Component
public class RequestValidation {

	private static final Logger logger = LoggerFactory
			.getLogger(RequestValidation.class);

	public boolean validateRequestData(RequestData requestData) {

		boolean breturn = false;
		if ("".equals(requestData.getOperater())) {

			logger.info("operater is missing");

			breturn = true;
		}
		return breturn;

	}

}
