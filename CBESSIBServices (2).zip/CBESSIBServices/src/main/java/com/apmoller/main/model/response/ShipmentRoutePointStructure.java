
package com.apmoller.main.model.response;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * A Geographical Area or a Site where Cargo
 * 				following a Shipment Route is (or would be - see Note 1 below)
 * 				loaded/unloaded to/from a vehicle. This includes:
 * 				- Place Of Receipt
 * 				Geographical Area
 * 				- Place Of Delivery Geographical Area
 * 				- A
 * 				Geographical Area or Site where cargo is (or would be)
 * 				trans-loaded
 * 				from one vehicle to another.
 * 				Note 1: Not all Shipment Routes are used
 * 				for actual cargo operations.
 * 				For such routes (eg Product Routes),
 * 				Shipment Route Points are
 * 				points where cargo WOULD BE loaded/unloaded
 * 				if the route were an
 * 				Operational Route.
 * 				A Shipment Route's set of
 * 				Shipment Route Points need not identify all
 * 				of the points at which
 * 				Cargo is/would be loaded/unloaded. For
 * 				example, a Contractual Route
 * 				need only include those Shipment Route
 * 				Points for which the
 * 				Enterprise has a contractual obligation.
 * 
 * 				A Shipment Route Point is
 * 				typically a City/Port or a Site, but can in
 * 				some cases be a
 * 				State/Province or a Country. For Operational Routes,
 * 				Shipment Route
 * 				Points where cargo is to be loaded to or discharged
 * 				from a Voyage
 * 				must be specified as Sites. This is to ensure that the
 * 				Terminal for
 * 				each marine operation is known. (Site specific details
 * 				for haulage
 * 				are in the Haulage Site entity).
 * 
 * <p>Java class for ShipmentRoutePointStructure complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ShipmentRoutePointStructure"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="Site" type="{http://services.apmoller.net/AMM/v4}SiteStructure"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ShipmentRoutePointStructure", propOrder = {
    "site"
})
public class ShipmentRoutePointStructure {

    @XmlElement(name = "Site", required = true)
    protected SiteStructure site;

    /**
     * Gets the value of the site property.
     * 
     * @return
     *     possible object is
     *     {@link SiteStructure }
     *     
     */
    public SiteStructure getSite() {
        return site;
    }

    /**
     * Sets the value of the site property.
     * 
     * @param value
     *     allowed object is
     *     {@link SiteStructure }
     *     
     */
    public void setSite(SiteStructure value) {
        this.site = value;
    }

}
