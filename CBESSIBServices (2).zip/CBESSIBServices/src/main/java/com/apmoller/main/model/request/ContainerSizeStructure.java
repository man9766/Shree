
package com.apmoller.main.model.request;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * Maersk names for container size e.g. '45' which
 * 				indicates the length is 45 feet, this coresponds to the 'L1' ISO
 * 				container length. Possible values are 20, 40 and 45.
 * 			
 * 
 * <p>Java class for ContainerSizeStructure complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ContainerSizeStructure"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="ContainerSizeCd" type="{http://services.apmoller.net/AMM/v4}String3NonNullType"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ContainerSizeStructure", propOrder = {
    "containerSizeCd"
})
public class ContainerSizeStructure {

    @XmlElement(name = "ContainerSizeCd", required = true)
    protected String containerSizeCd;

    /**
     * Gets the value of the containerSizeCd property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getContainerSizeCd() {
        return containerSizeCd;
    }

    /**
     * Sets the value of the containerSizeCd property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setContainerSizeCd(String value) {
        this.containerSizeCd = value;
    }

}
