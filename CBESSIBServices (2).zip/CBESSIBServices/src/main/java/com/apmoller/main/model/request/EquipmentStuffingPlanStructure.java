
package com.apmoller.main.model.request;

import java.math.BigDecimal;
import java.math.BigInteger;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * 'Cargo In A Container':
 * 				A plan (and associated plan
 * 				status information) to stuff material
 * 				from a Cargo line,
 * 				or part of a
 * 				Cargo line, in a Container assigned to a Shipment.
 * 			
 * 
 * <p>Java class for EquipmentStuffingPlanStructure complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="EquipmentStuffingPlanStructure"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="Cargo" type="{http://services.apmoller.net/AMM/v4}CargoCustomStuffType"/&gt;
 *         &lt;element name="Measure" type="{http://services.apmoller.net/AMM/v4}Decimal18d4Type" minOccurs="0"/&gt;
 *         &lt;element name="MeasureUnitOfMeasurement" type="{http://services.apmoller.net/AMM/v4}UnitOfMeasurementCustomValType" minOccurs="0"/&gt;
 *         &lt;element name="PackageCount" type="{http://services.apmoller.net/AMM/v4}Integer13Type"/&gt;
 *         &lt;element name="Weight" type="{http://services.apmoller.net/AMM/v4}Decimal18d4Type" minOccurs="0"/&gt;
 *         &lt;element name="WeightUnitOfMeasurement" type="{http://services.apmoller.net/AMM/v4}UnitOfMeasurementCustomValType" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "EquipmentStuffingPlanStructure", propOrder = {
    "cargo",
    "measure",
    "measureUnitOfMeasurement",
    "packageCount",
    "weight",
    "weightUnitOfMeasurement"
})
public class EquipmentStuffingPlanStructure {

    @XmlElement(name = "Cargo", required = true)
    protected CargoCustomStuffType cargo;
    @XmlElement(name = "Measure")
    protected BigDecimal measure;
    @XmlElement(name = "MeasureUnitOfMeasurement")
    protected UnitOfMeasurementCustomValType measureUnitOfMeasurement;
    @XmlElement(name = "PackageCount", required = true)
    protected BigInteger packageCount;
    @XmlElement(name = "Weight")
    protected BigDecimal weight;
    @XmlElement(name = "WeightUnitOfMeasurement")
    protected UnitOfMeasurementCustomValType weightUnitOfMeasurement;

    /**
     * Gets the value of the cargo property.
     * 
     * @return
     *     possible object is
     *     {@link CargoCustomStuffType }
     *     
     */
    public CargoCustomStuffType getCargo() {
        return cargo;
    }

    /**
     * Sets the value of the cargo property.
     * 
     * @param value
     *     allowed object is
     *     {@link CargoCustomStuffType }
     *     
     */
    public void setCargo(CargoCustomStuffType value) {
        this.cargo = value;
    }

    /**
     * Gets the value of the measure property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getMeasure() {
        return measure;
    }

    /**
     * Sets the value of the measure property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setMeasure(BigDecimal value) {
        this.measure = value;
    }

    /**
     * Gets the value of the measureUnitOfMeasurement property.
     * 
     * @return
     *     possible object is
     *     {@link UnitOfMeasurementCustomValType }
     *     
     */
    public UnitOfMeasurementCustomValType getMeasureUnitOfMeasurement() {
        return measureUnitOfMeasurement;
    }

    /**
     * Sets the value of the measureUnitOfMeasurement property.
     * 
     * @param value
     *     allowed object is
     *     {@link UnitOfMeasurementCustomValType }
     *     
     */
    public void setMeasureUnitOfMeasurement(UnitOfMeasurementCustomValType value) {
        this.measureUnitOfMeasurement = value;
    }

    /**
     * Gets the value of the packageCount property.
     * 
     * @return
     *     possible object is
     *     {@link BigInteger }
     *     
     */
    public BigInteger getPackageCount() {
        return packageCount;
    }

    /**
     * Sets the value of the packageCount property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigInteger }
     *     
     */
    public void setPackageCount(BigInteger value) {
        this.packageCount = value;
    }

    /**
     * Gets the value of the weight property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getWeight() {
        return weight;
    }

    /**
     * Sets the value of the weight property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setWeight(BigDecimal value) {
        this.weight = value;
    }

    /**
     * Gets the value of the weightUnitOfMeasurement property.
     * 
     * @return
     *     possible object is
     *     {@link UnitOfMeasurementCustomValType }
     *     
     */
    public UnitOfMeasurementCustomValType getWeightUnitOfMeasurement() {
        return weightUnitOfMeasurement;
    }

    /**
     * Sets the value of the weightUnitOfMeasurement property.
     * 
     * @param value
     *     allowed object is
     *     {@link UnitOfMeasurementCustomValType }
     *     
     */
    public void setWeightUnitOfMeasurement(UnitOfMeasurementCustomValType value) {
        this.weightUnitOfMeasurement = value;
    }

}
