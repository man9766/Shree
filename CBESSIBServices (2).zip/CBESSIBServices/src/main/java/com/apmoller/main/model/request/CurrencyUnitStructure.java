
package com.apmoller.main.model.request;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.datatype.XMLGregorianCalendar;


/**
 * Contains the currencies, ISO (ISO 4217) codes and
 * 				names.
 * 			
 * 
 * <p>Java class for CurrencyUnitStructure complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="CurrencyUnitStructure"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="CurrencyISOCd" type="{http://services.apmoller.net/AMM/v4}String50NonNullType" minOccurs="0"/&gt;
 *         &lt;element name="CurrencyISOName" type="{http://services.apmoller.net/AMM/v4}String100Type" minOccurs="0"/&gt;
 *         &lt;element name="CurrencyISONumericCd" type="{http://services.apmoller.net/AMM/v4}String50NonNullType" minOccurs="0"/&gt;
 *         &lt;element name="CurrencySignVal" type="{http://services.apmoller.net/AMM/v4}String100Type" minOccurs="0"/&gt;
 *         &lt;element name="DecimalSeperatorVal" type="{http://services.apmoller.net/AMM/v4}String100Type" minOccurs="0"/&gt;
 *         &lt;element name="DigitsAfterDecimalSeparatorNum" type="{http://services.apmoller.net/AMM/v4}Integer10Type" minOccurs="0"/&gt;
 *         &lt;element name="FractionalUnitName" type="{http://services.apmoller.net/AMM/v4}String100Type" minOccurs="0"/&gt;
 *         &lt;element name="FractionalUnitRate" type="{http://services.apmoller.net/AMM/v4}Decimal15d12Type" minOccurs="0"/&gt;
 *         &lt;element name="FractionalUnitUsedInd" type="{http://services.apmoller.net/AMM/v4}BooleanType" minOccurs="0"/&gt;
 *         &lt;element name="Replaced" type="{http://services.apmoller.net/AMM/v4}CurrencyUnitStructure" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="ValidFromDt" type="{http://services.apmoller.net/AMM/v4}DateType" minOccurs="0"/&gt;
 *         &lt;element name="ValidThruDt" type="{http://services.apmoller.net/AMM/v4}DateType" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "CurrencyUnitStructure", propOrder = {
    "currencyISOCd",
    "currencyISOName",
    "currencyISONumericCd",
    "currencySignVal",
    "decimalSeperatorVal",
    "digitsAfterDecimalSeparatorNum",
    "fractionalUnitName",
    "fractionalUnitRate",
    "fractionalUnitUsedInd",
    "replaced",
    "validFromDt",
    "validThruDt"
})
public class CurrencyUnitStructure {

    @XmlElement(name = "CurrencyISOCd")
    protected String currencyISOCd;
    @XmlElement(name = "CurrencyISOName")
    protected String currencyISOName;
    @XmlElement(name = "CurrencyISONumericCd")
    protected String currencyISONumericCd;
    @XmlElement(name = "CurrencySignVal")
    protected String currencySignVal;
    @XmlElement(name = "DecimalSeperatorVal")
    protected String decimalSeperatorVal;
    @XmlElement(name = "DigitsAfterDecimalSeparatorNum")
    protected BigInteger digitsAfterDecimalSeparatorNum;
    @XmlElement(name = "FractionalUnitName")
    protected String fractionalUnitName;
    @XmlElement(name = "FractionalUnitRate")
    protected BigDecimal fractionalUnitRate;
    @XmlElement(name = "FractionalUnitUsedInd")
    @XmlSchemaType(name = "anySimpleType")
    protected String fractionalUnitUsedInd;
    @XmlElement(name = "Replaced")
    protected List<CurrencyUnitStructure> replaced;
    @XmlElement(name = "ValidFromDt")
    @XmlSchemaType(name = "date")
    protected XMLGregorianCalendar validFromDt;
    @XmlElement(name = "ValidThruDt")
    @XmlSchemaType(name = "date")
    protected XMLGregorianCalendar validThruDt;

    /**
     * Gets the value of the currencyISOCd property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCurrencyISOCd() {
        return currencyISOCd;
    }

    /**
     * Sets the value of the currencyISOCd property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCurrencyISOCd(String value) {
        this.currencyISOCd = value;
    }

    /**
     * Gets the value of the currencyISOName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCurrencyISOName() {
        return currencyISOName;
    }

    /**
     * Sets the value of the currencyISOName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCurrencyISOName(String value) {
        this.currencyISOName = value;
    }

    /**
     * Gets the value of the currencyISONumericCd property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCurrencyISONumericCd() {
        return currencyISONumericCd;
    }

    /**
     * Sets the value of the currencyISONumericCd property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCurrencyISONumericCd(String value) {
        this.currencyISONumericCd = value;
    }

    /**
     * Gets the value of the currencySignVal property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCurrencySignVal() {
        return currencySignVal;
    }

    /**
     * Sets the value of the currencySignVal property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCurrencySignVal(String value) {
        this.currencySignVal = value;
    }

    /**
     * Gets the value of the decimalSeperatorVal property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDecimalSeperatorVal() {
        return decimalSeperatorVal;
    }

    /**
     * Sets the value of the decimalSeperatorVal property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDecimalSeperatorVal(String value) {
        this.decimalSeperatorVal = value;
    }

    /**
     * Gets the value of the digitsAfterDecimalSeparatorNum property.
     * 
     * @return
     *     possible object is
     *     {@link BigInteger }
     *     
     */
    public BigInteger getDigitsAfterDecimalSeparatorNum() {
        return digitsAfterDecimalSeparatorNum;
    }

    /**
     * Sets the value of the digitsAfterDecimalSeparatorNum property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigInteger }
     *     
     */
    public void setDigitsAfterDecimalSeparatorNum(BigInteger value) {
        this.digitsAfterDecimalSeparatorNum = value;
    }

    /**
     * Gets the value of the fractionalUnitName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFractionalUnitName() {
        return fractionalUnitName;
    }

    /**
     * Sets the value of the fractionalUnitName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFractionalUnitName(String value) {
        this.fractionalUnitName = value;
    }

    /**
     * Gets the value of the fractionalUnitRate property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getFractionalUnitRate() {
        return fractionalUnitRate;
    }

    /**
     * Sets the value of the fractionalUnitRate property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setFractionalUnitRate(BigDecimal value) {
        this.fractionalUnitRate = value;
    }

    /**
     * Gets the value of the fractionalUnitUsedInd property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFractionalUnitUsedInd() {
        return fractionalUnitUsedInd;
    }

    /**
     * Sets the value of the fractionalUnitUsedInd property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFractionalUnitUsedInd(String value) {
        this.fractionalUnitUsedInd = value;
    }

    /**
     * Gets the value of the replaced property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the replaced property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getReplaced().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link CurrencyUnitStructure }
     * 
     * 
     */
    public List<CurrencyUnitStructure> getReplaced() {
        if (replaced == null) {
            replaced = new ArrayList<CurrencyUnitStructure>();
        }
        return this.replaced;
    }

    /**
     * Gets the value of the validFromDt property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getValidFromDt() {
        return validFromDt;
    }

    /**
     * Sets the value of the validFromDt property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setValidFromDt(XMLGregorianCalendar value) {
        this.validFromDt = value;
    }

    /**
     * Gets the value of the validThruDt property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getValidThruDt() {
        return validThruDt;
    }

    /**
     * Sets the value of the validThruDt property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setValidThruDt(XMLGregorianCalendar value) {
        this.validThruDt = value;
    }

}
