
package com.apmoller.main.model.request;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlSeeAlso;
import javax.xml.bind.annotation.XmlType;


/**
 * A group of properties for an Equipment
 * 				Size/SubType
 * 
 * 				Profile that describes characteristics of equipment.
 * 				It
 * 				could e.g. be the characteristics of a reefer container, as these
 * 				comes in diferent varieties with controlled atmosphere, ventilation
 * 				and cooling capabilities.
 * 
 * 				The profiles can also have names like 'STAR
 * 				FRESH', 'MAGNUM',
 * 				'STARVENT' etc. names for container profiles known
 * 				and used within
 * 				the enterprise.
 * 
 * 				A requirement regarding Equipment to
 * 				be used for a Shipment, and how
 * 				this Equipment should be operated.
 * 				Includes:
 * 
 * 				- Whether the Equipment should have temperature control
 * 				capability
 * 				- Low and High temperature range to be maintained
 * 				- Number
 * 				or Gensets required for export haulage
 * 				- Number of Gensets required
 * 				for import haulage
 * 				- Requirements regarding mounting of Gensets at
 * 				export / import
 * 				- Whether Container pre-cooling is required
 * 				- Whether
 * 				a freezer-stuffing Container is required
 * 				- Whether a data logger
 * 				equipment is required, and number of logger
 * 				probes required
 * 				- Whether
 * 				ventilation is required and ventilation speed
 * 				- Humidity requirements
 * 
 * 				Note:
 * 				If cargo to be stuffed in a Container is from different Cargo
 * 				Lines
 * 				with different Cargo Conditioning Requirements, then the
 * 				Equipment
 * 				Conditioning Requirement (eg regarding temperature) may be
 * 				different
 * 				to that for any particular Cargo Conditioning Requirement.
 * 				In the case of a requirement regarding temperature range, typically
 * 				the temperature within the Container must be such that it meets the
 * 				Cargo Conditioning Requirements for all cargo stuffed in the
 * 				Container.
 * 
 * 				An Equipment Conditioning Requirement has an Equipment
 * 				Conditioning
 * 				Requirement Type.
 * 				Examples include:
 * 				- Standard
 * 				- Fresh Mist
 * 				- Super Freezer
 * 				- Starfresh
 * 				- Starfresh Plus
 * 				- Starvent
 * 				- Transfresh
 * 				-
 * 				Magnum
 * 				- Tank
 * 
 * 
 * <p>Java class for EquipmentProfileCustomEmptyType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="EquipmentProfileCustomEmptyType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "EquipmentProfileCustomEmptyType")
@XmlSeeAlso({
    ContainerProfileStructure.class
})
public class EquipmentProfileCustomEmptyType {


}
