
package com.apmoller.main.model.response;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * An order for cargo transport, or a 'prebooking'
 * 				for cargo transport.
 * 
 * 				Versioning: The Shipment entity type and a
 * 				number of associated entity types in
 * 				the Shipment, Shipment Cargo,
 * 				Shipment Equipment, Shipment Route and
 * 				Shipment Price clusters
 * 				together form an extended complex data
 * 				structure or 'compound entity
 * 				type' centred on Shipment. A compound
 * 				Shipment entity can go through
 * 				multiple versions during its
 * 				lifecycle, with each version
 * 				representing the state of the Shipment
 * 				with all its assocated
 * 				entities at a point in time. The specific
 * 				list of entities included
 * 				in the compound Shipment entity type is
 * 				not detailed here; note
 * 				however that Shipment Document (including
 * 				Transport Document) is
 * 				versioned separately.
 * 
 * 				A version of a Shipment may optionally include
 * 				a 'version purpose'
 * 				that indicates the business purpose of the
 * 				version. This must be one
 * 				of a number of defined Types. Eg 'Booking
 * 				Confirmation'.
 * 
 * 				The entity relationship models for the clusters
 * 				mentioned above show
 * 				only relationships between current versions of
 * 				entities.
 * 			
 * 
 * <p>Java class for ShipmentCustomValResType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ShipmentCustomValResType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="ShipmentId" type="{http://services.apmoller.net/AMM/v4}String9NonNullType"/&gt;
 *         &lt;element name="ShipmentRoute" type="{http://services.apmoller.net/AMM/v4}ShipmentRouteCustomSteeredLegType" maxOccurs="unbounded" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ShipmentCustomValResType", propOrder = {
    "shipmentId",
    "shipmentRoute"
})
public class ShipmentCustomValResType {

    @XmlElement(name = "ShipmentId", required = true)
    protected String shipmentId;
    @XmlElement(name = "ShipmentRoute")
    protected List<ShipmentRouteCustomSteeredLegType> shipmentRoute;

    /**
     * Gets the value of the shipmentId property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getShipmentId() {
        return shipmentId;
    }

    /**
     * Sets the value of the shipmentId property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setShipmentId(String value) {
        this.shipmentId = value;
    }

    /**
     * Gets the value of the shipmentRoute property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the shipmentRoute property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getShipmentRoute().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link ShipmentRouteCustomSteeredLegType }
     * 
     * 
     */
    public List<ShipmentRouteCustomSteeredLegType> getShipmentRoute() {
        if (shipmentRoute == null) {
            shipmentRoute = new ArrayList<ShipmentRouteCustomSteeredLegType>();
        }
        return this.shipmentRoute;
    }

}
