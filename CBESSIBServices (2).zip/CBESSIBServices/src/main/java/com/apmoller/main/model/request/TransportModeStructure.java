
package com.apmoller.main.model.request;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * A mode of transport that can be used to transport
 * 				cargo. Eg
 * 				Ocean, Feeder, Barge, Rail, Truck
 * 
 * <p>Java class for TransportModeStructure complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="TransportModeStructure"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="TransportModeCd" type="{http://services.apmoller.net/AMM/v4}String10NonNullType"/&gt;
 *         &lt;element name="WaterLandMode" type="{http://services.apmoller.net/AMM/v4}String1NonNullType"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "TransportModeStructure", propOrder = {
    "transportModeCd",
    "waterLandMode"
})
public class TransportModeStructure {

    @XmlElement(name = "TransportModeCd", required = true)
    protected String transportModeCd;
    @XmlElement(name = "WaterLandMode", required = true)
    protected String waterLandMode;

    /**
     * Gets the value of the transportModeCd property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTransportModeCd() {
        return transportModeCd;
    }

    /**
     * Sets the value of the transportModeCd property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTransportModeCd(String value) {
        this.transportModeCd = value;
    }

    /**
     * Gets the value of the waterLandMode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getWaterLandMode() {
        return waterLandMode;
    }

    /**
     * Sets the value of the waterLandMode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setWaterLandMode(String value) {
        this.waterLandMode = value;
    }

}
