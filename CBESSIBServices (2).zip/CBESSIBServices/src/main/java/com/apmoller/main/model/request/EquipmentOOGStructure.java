
package com.apmoller.main.model.request;

import java.math.BigInteger;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * Details of the excess space used for a Container
 * 				that has been stuffed with OOG Cargo Package(s). Includes:
 * 				- Excess
 * 				height over the roof of the Container
 * 				- Excess length at the front of
 * 				the Container
 * 				- Excess length at the rear of the Container
 * 				- Excess
 * 				width laterally to starboard
 * 				- Excess width laterally to port
 * 
 * 				-
 * 				Displacement: This is the number of slots on the vessel that cannot
 * 				be used ('killed slots') as a result of loading this OOG Container
 * 				(includes the slot that would have in any case been used had the
 * 				Container not been OOG).
 * 
 * 
 * <p>Java class for EquipmentOOGStructure complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="EquipmentOOGStructure"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="Displacement" type="{http://services.apmoller.net/AMM/v4}Integer10Type"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "EquipmentOOGStructure", propOrder = {
    "displacement"
})
public class EquipmentOOGStructure {

    @XmlElement(name = "Displacement", required = true)
    protected BigInteger displacement;

    /**
     * Gets the value of the displacement property.
     * 
     * @return
     *     possible object is
     *     {@link BigInteger }
     *     
     */
    public BigInteger getDisplacement() {
        return displacement;
    }

    /**
     * Sets the value of the displacement property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigInteger }
     *     
     */
    public void setDisplacement(BigInteger value) {
        this.displacement = value;
    }

}
