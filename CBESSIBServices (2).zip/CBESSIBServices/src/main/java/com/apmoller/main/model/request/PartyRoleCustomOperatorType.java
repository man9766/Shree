
package com.apmoller.main.model.request;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSeeAlso;
import javax.xml.bind.annotation.XmlType;


/**
 * A role that a particular Party may play in the
 * 				context of the Enterprise's business environment. Party Role defines
 * 				how a Party can act in this environment.
 * 
 * 				For RCM
 * 				Responsible party
 * 				role at an inland location,
 * 				Responsible party role on vessel
 * 				Responsible party role on-route location
 * 
 * <p>Java class for PartyRoleCustomOperatorType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="PartyRoleCustomOperatorType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="OperatorCode" type="{http://services.apmoller.net/AMM/v4}AlternativeCodeCustomString3Type"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "PartyRoleCustomOperatorType", propOrder = {
    "operatorCode"
})
@XmlSeeAlso({
    OperatorStructure.class
})
public class PartyRoleCustomOperatorType {

    @XmlElement(name = "OperatorCode", required = true)
    protected AlternativeCodeCustomString3Type operatorCode;

    /**
     * Gets the value of the operatorCode property.
     * 
     * @return
     *     possible object is
     *     {@link AlternativeCodeCustomString3Type }
     *     
     */
    public AlternativeCodeCustomString3Type getOperatorCode() {
        return operatorCode;
    }

    /**
     * Sets the value of the operatorCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link AlternativeCodeCustomString3Type }
     *     
     */
    public void setOperatorCode(AlternativeCodeCustomString3Type value) {
        this.operatorCode = value;
    }

}
