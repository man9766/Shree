
package com.apmoller.main.model.request;

import javax.validation.constraints.NotNull;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * This entity replaces the "Route" entity in
 * 				representing a group of specific Journeys
 * 
 * 				HMO060 20121115: Definition
 * 				accorrding to JOR011: The Journey Group or
 * 				better known as Route
 * 				describes where the cargo moves. E.g. between
 * 				Asia and Europe.
 * 				And
 * 				therefore the Journeys within a Journey Group must have a
 * 				direction.
 * 			
 * 
 * <p>Java class for JourneyGroupStructure complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="JourneyGroupStructure"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="JourneyGroupCd" type="{http://services.apmoller.net/AMM/v4}String2NonNullType"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "JourneyGroupStructure", propOrder = {
    "journeyGroupCd"
})
public class JourneyGroupStructure {
   
	@NotNull(message  = "journeyGroupCd can't be Null")
    @XmlElement(name = "JourneyGroupCd", required = true)
    protected String journeyGroupCd;

    /**
     * Gets the value of the journeyGroupCd property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getJourneyGroupCd() {
        return journeyGroupCd;
    }

    /**
     * Sets the value of the journeyGroupCd property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setJourneyGroupCd(String value) {
        this.journeyGroupCd = value;
    }

}
