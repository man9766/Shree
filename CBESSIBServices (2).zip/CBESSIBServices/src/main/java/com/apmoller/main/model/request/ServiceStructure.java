
package com.apmoller.main.model.request;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * A geographical trading area or corridor within
 * 				which Vessels, Barges or Trains are deployed to move containers
 * 				between ports.
 * 
 * 				A service contains a number of Vessel Schedules.
 * 
 * 				Warning! This was sometimes previously referred to as "String" (or
 * 				now, "Old
 * 				String").
 * 
 * 				There are several variants of "Service":
 * 				-
 * 				Boomerang
 * 				- Butterfly
 * 				- Pendulum
 * 
 * 				Candidate attributes:
 * 				Service code -
 * 				the unique three-character code
 * 				Average Service Weight (average
 * 				weight of TEU on service)
 * 				Service Validity Period Start Date
 * 				Service
 * 				Validity Period End Date
 * 
 * 				Cargo carrying capacity between sites that
 * 				is provided by Vehicles (eg
 * 				Vessels) operating on a Rotation
 * 				according to Dated Schedules
 * 				Services are published on The
 * 				Enterprise's public internet website
 * 				as part of the Enterprise's
 * 				offering to Customers
 * 				Service has sometimes previously been known as
 * 				"string".
 * 			
 * 
 * <p>Java class for ServiceStructure complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ServiceStructure"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="ServiceCd" type="{http://services.apmoller.net/AMM/v4}String3NonNullType"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ServiceStructure", propOrder = {
    "serviceCd"
})
public class ServiceStructure {

    @XmlElement(name = "ServiceCd", required = true)
    protected String serviceCd;

    /**
     * Gets the value of the serviceCd property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getServiceCd() {
        return serviceCd;
    }

    /**
     * Sets the value of the serviceCd property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setServiceCd(String value) {
        this.serviceCd = value;
    }

}
