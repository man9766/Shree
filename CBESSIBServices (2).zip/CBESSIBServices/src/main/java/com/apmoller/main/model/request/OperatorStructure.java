
package com.apmoller.main.model.request;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;


/**
 * A Company that operates Vessels, undertakes to
 * 				move Cargo as primary Carrier, and issues Bills Of Lading for the
 * 				Cargo
 * 
 * 				Examples can include:
 * 				- Maersk Line
 * 				- MCC
 * 
 * 
 * <p>Java class for OperatorStructure complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="OperatorStructure"&gt;
 *   &lt;complexContent&gt;
 *     &lt;extension base="{http://services.apmoller.net/AMM/v4}PartyRoleCustomOperatorType"&gt;
 *     &lt;/extension&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "OperatorStructure")
public class OperatorStructure
    extends PartyRoleCustomOperatorType
{


}
