
package com.apmoller.main.model.request;

import java.math.BigInteger;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * Containers transported by the enterprise will not
 * 				always be able to go the entire way from Place of receipt to Place
 * 				of delivery onboard a single mother vessel, as each vessel calls a
 * 				limited number of ports on a fixed rotation.
 * 				Consequently the
 * 				enterprise will often deliver the "Transport product" as the
 * 				sum of a
 * 				number of "Transport Product Legs" that together will move
 * 				the
 * 				container from the original place of receipt to the final place
 * 				of
 * 				delivery.
 * 				The "Transport Product Leg" is defined by
 * 				- Start location
 * 				(Business Defined Area)
 * 				- End location (Business Defined Area)
 * 				-
 * 				(Optional: First Load Port / LOPFI)
 * 				- (Optional: Last Discharge Port
 * 				/ DIPLA)
 * 				A "Transport product leg" can either be an "Ocean product"
 * 				or a
 * 				"Haulage product".
 * 				The "Ocean product" will typically have one or
 * 				more "Dated Sea Legs"
 * 				attached to it.
 * 
 * 
 * <p>Java class for JourneyLegCustomType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="JourneyLegCustomType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="JourneyLegId" type="{http://services.apmoller.net/AMM/v4}String13NonNullType"/&gt;
 *         &lt;element name="RoutingType" type="{http://services.apmoller.net/AMM/v4}RoutingTypeStructure" minOccurs="0"/&gt;
 *         &lt;element name="TransitTime" type="{http://services.apmoller.net/AMM/v4}Integer9Type" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "JourneyLegCustomType", propOrder = {
    "journeyLegId",
    "routingType",
    "transitTime"
})
public class JourneyLegCustomType {

    @XmlElement(name = "JourneyLegId", required = true)
    protected String journeyLegId;
    @XmlElement(name = "RoutingType")
    protected RoutingTypeStructure routingType;
    @XmlElement(name = "TransitTime")
    protected BigInteger transitTime;

    /**
     * Gets the value of the journeyLegId property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getJourneyLegId() {
        return journeyLegId;
    }

    /**
     * Sets the value of the journeyLegId property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setJourneyLegId(String value) {
        this.journeyLegId = value;
    }

    /**
     * Gets the value of the routingType property.
     * 
     * @return
     *     possible object is
     *     {@link RoutingTypeStructure }
     *     
     */
    public RoutingTypeStructure getRoutingType() {
        return routingType;
    }

    /**
     * Sets the value of the routingType property.
     * 
     * @param value
     *     allowed object is
     *     {@link RoutingTypeStructure }
     *     
     */
    public void setRoutingType(RoutingTypeStructure value) {
        this.routingType = value;
    }

    /**
     * Gets the value of the transitTime property.
     * 
     * @return
     *     possible object is
     *     {@link BigInteger }
     *     
     */
    public BigInteger getTransitTime() {
        return transitTime;
    }

    /**
     * Sets the value of the transitTime property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigInteger }
     *     
     */
    public void setTransitTime(BigInteger value) {
        this.transitTime = value;
    }

}
