
package com.apmoller.main.model.request;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.datatype.XMLGregorianCalendar;


/**
 * Information about transport between two Shipment
 * 				Route Points, OR, about Pre Carriage transport to the Place of
 * 				Receipt (first Shipment Route Point) or On-Carriage transport from
 * 				the Place of Delivery (last Shipment Route Point).
 * 				In the case of
 * 				Pre-Carriage / On-Carriage, there is only one
 * 				associated Shipment
 * 				Route Point.
 * 
 * 				The transport information can include:
 * 				- Start Shipment
 * 				Route Point
 * 				- End Shipment Route Point
 * 				- Expected Arrival Time
 * 				-
 * 				Expected Departure Time
 * 				- Transport Mode
 * 				- Voyage Number
 * 				- Vessel Block
 * 				Stowage Code
 * 
 * 
 * 
 * <p>Java class for ShipmentRouteLinkCustomType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ShipmentRouteLinkCustomType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="Arrival" type="{http://services.apmoller.net/AMM/v4}DatedVoyageStructure"/&gt;
 *         &lt;element name="ETD" type="{http://services.apmoller.net/AMM/v4}DateTimeType"/&gt;
 *         &lt;element name="End" type="{http://services.apmoller.net/AMM/v4}ShipmentRoutePointStructure"/&gt;
 *         &lt;element name="JourneyLeg" type="{http://services.apmoller.net/AMM/v4}JourneyLegCustomType"/&gt;
 *         &lt;element name="LayoverTime" type="{http://services.apmoller.net/AMM/v4}Integer9Type" minOccurs="0"/&gt;
 *         &lt;element name="Start" type="{http://services.apmoller.net/AMM/v4}ShipmentRoutePointStructure"/&gt;
 *         &lt;element name="SteeredLegStatus" type="{http://services.apmoller.net/AMM/v4}String1NonNullType" minOccurs="0"/&gt;
 *         &lt;element name="TransportMode" type="{http://services.apmoller.net/AMM/v4}TransportModeStructure"/&gt;
 *         &lt;element name="Carrier" type="{http://services.apmoller.net/AMM/v4}CarrierStructure" minOccurs="0"/&gt;
 *         &lt;element name="StringDirectionType" type="{http://services.apmoller.net/AMM/v4}StringDirectionTypeStructure" minOccurs="0"/&gt;
 *         &lt;element name="TransportationTypeCd" type="{http://services.apmoller.net/AMM/v4}String50NonNullType" minOccurs="0"/&gt;
 *         &lt;element name="ShipmentLinkCost" type="{http://services.apmoller.net/AMM/v4}ShipmentLinkCostStructure" maxOccurs="unbounded" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ShipmentRouteLinkCustomType", propOrder = {
    "arrival",
    "etd",
    "end",
    "journeyLeg",
    "layoverTime",
    "start",
    "steeredLegStatus",
    "transportMode",
    "carrier",
    "stringDirectionType",
    "transportationTypeCd",
    "shipmentLinkCost"
})
public class ShipmentRouteLinkCustomType {

    @XmlElement(name = "Arrival", required = true)
    protected DatedVoyageStructure arrival;
    @XmlElement(name = "ETD", required = true)
    @XmlSchemaType(name = "dateTime")
    protected XMLGregorianCalendar etd;
    @XmlElement(name = "End", required = true)
    protected ShipmentRoutePointStructure end;
    @XmlElement(name = "JourneyLeg", required = true)
    protected JourneyLegCustomType journeyLeg;
    @XmlElement(name = "LayoverTime")
    protected BigInteger layoverTime;
    @XmlElement(name = "Start", required = true)
    protected ShipmentRoutePointStructure start;
    @XmlElement(name = "SteeredLegStatus")
    protected String steeredLegStatus;
    @XmlElement(name = "TransportMode", required = true)
    protected TransportModeStructure transportMode;
    @XmlElement(name = "Carrier")
    protected CarrierStructure carrier;
    @XmlElement(name = "StringDirectionType")
    protected StringDirectionTypeStructure stringDirectionType;
    @XmlElement(name = "TransportationTypeCd")
    protected String transportationTypeCd;
    @XmlElement(name = "ShipmentLinkCost")
    protected List<ShipmentLinkCostStructure> shipmentLinkCost;

    /**
     * Gets the value of the arrival property.
     * 
     * @return
     *     possible object is
     *     {@link DatedVoyageStructure }
     *     
     */
    public DatedVoyageStructure getArrival() {
        return arrival;
    }

    /**
     * Sets the value of the arrival property.
     * 
     * @param value
     *     allowed object is
     *     {@link DatedVoyageStructure }
     *     
     */
    public void setArrival(DatedVoyageStructure value) {
        this.arrival = value;
    }

    /**
     * Gets the value of the etd property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getETD() {
        return etd;
    }

    /**
     * Sets the value of the etd property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setETD(XMLGregorianCalendar value) {
        this.etd = value;
    }

    /**
     * Gets the value of the end property.
     * 
     * @return
     *     possible object is
     *     {@link ShipmentRoutePointStructure }
     *     
     */
    public ShipmentRoutePointStructure getEnd() {
        return end;
    }

    /**
     * Sets the value of the end property.
     * 
     * @param value
     *     allowed object is
     *     {@link ShipmentRoutePointStructure }
     *     
     */
    public void setEnd(ShipmentRoutePointStructure value) {
        this.end = value;
    }

    /**
     * Gets the value of the journeyLeg property.
     * 
     * @return
     *     possible object is
     *     {@link JourneyLegCustomType }
     *     
     */
    public JourneyLegCustomType getJourneyLeg() {
        return journeyLeg;
    }

    /**
     * Sets the value of the journeyLeg property.
     * 
     * @param value
     *     allowed object is
     *     {@link JourneyLegCustomType }
     *     
     */
    public void setJourneyLeg(JourneyLegCustomType value) {
        this.journeyLeg = value;
    }

    /**
     * Gets the value of the layoverTime property.
     * 
     * @return
     *     possible object is
     *     {@link BigInteger }
     *     
     */
    public BigInteger getLayoverTime() {
        return layoverTime;
    }

    /**
     * Sets the value of the layoverTime property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigInteger }
     *     
     */
    public void setLayoverTime(BigInteger value) {
        this.layoverTime = value;
    }

    /**
     * Gets the value of the start property.
     * 
     * @return
     *     possible object is
     *     {@link ShipmentRoutePointStructure }
     *     
     */
    public ShipmentRoutePointStructure getStart() {
        return start;
    }

    /**
     * Sets the value of the start property.
     * 
     * @param value
     *     allowed object is
     *     {@link ShipmentRoutePointStructure }
     *     
     */
    public void setStart(ShipmentRoutePointStructure value) {
        this.start = value;
    }

    /**
     * Gets the value of the steeredLegStatus property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSteeredLegStatus() {
        return steeredLegStatus;
    }

    /**
     * Sets the value of the steeredLegStatus property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSteeredLegStatus(String value) {
        this.steeredLegStatus = value;
    }

    /**
     * Gets the value of the transportMode property.
     * 
     * @return
     *     possible object is
     *     {@link TransportModeStructure }
     *     
     */
    public TransportModeStructure getTransportMode() {
        return transportMode;
    }

    /**
     * Sets the value of the transportMode property.
     * 
     * @param value
     *     allowed object is
     *     {@link TransportModeStructure }
     *     
     */
    public void setTransportMode(TransportModeStructure value) {
        this.transportMode = value;
    }

    /**
     * Gets the value of the carrier property.
     * 
     * @return
     *     possible object is
     *     {@link CarrierStructure }
     *     
     */
    public CarrierStructure getCarrier() {
        return carrier;
    }

    /**
     * Sets the value of the carrier property.
     * 
     * @param value
     *     allowed object is
     *     {@link CarrierStructure }
     *     
     */
    public void setCarrier(CarrierStructure value) {
        this.carrier = value;
    }

    /**
     * Gets the value of the stringDirectionType property.
     * 
     * @return
     *     possible object is
     *     {@link StringDirectionTypeStructure }
     *     
     */
    public StringDirectionTypeStructure getStringDirectionType() {
        return stringDirectionType;
    }

    /**
     * Sets the value of the stringDirectionType property.
     * 
     * @param value
     *     allowed object is
     *     {@link StringDirectionTypeStructure }
     *     
     */
    public void setStringDirectionType(StringDirectionTypeStructure value) {
        this.stringDirectionType = value;
    }

    /**
     * Gets the value of the transportationTypeCd property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTransportationTypeCd() {
        return transportationTypeCd;
    }

    /**
     * Sets the value of the transportationTypeCd property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTransportationTypeCd(String value) {
        this.transportationTypeCd = value;
    }

    /**
     * Gets the value of the shipmentLinkCost property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the shipmentLinkCost property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getShipmentLinkCost().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link ShipmentLinkCostStructure }
     * 
     * 
     */
    public List<ShipmentLinkCostStructure> getShipmentLinkCost() {
        if (shipmentLinkCost == null) {
            shipmentLinkCost = new ArrayList<ShipmentLinkCostStructure>();
        }
        return this.shipmentLinkCost;
    }

}
