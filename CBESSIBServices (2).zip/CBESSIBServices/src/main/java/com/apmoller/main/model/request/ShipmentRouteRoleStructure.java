
package com.apmoller.main.model.request;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * A role or mode of usage for a Shipment Route. A
 * 				Shipment Route Role must have a
 * 				Shipment Route Role Type. Example
 * 				Shipment Route Role Types include:
 * 				- Product Route
 * 				- Operational Route
 * 				- Contractual Route
 * 				- Arranged Route
 * 				- Customer Preferred Route
 * 			
 * 
 * <p>Java class for ShipmentRouteRoleStructure complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ShipmentRouteRoleStructure"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="RouteRoleType" type="{http://services.apmoller.net/AMM/v4}RouteRoleTypeStructure"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ShipmentRouteRoleStructure", propOrder = {
    "routeRoleType"
})
public class ShipmentRouteRoleStructure {

    @XmlElement(name = "RouteRoleType", required = true)
    protected RouteRoleTypeStructure routeRoleType;

    /**
     * Gets the value of the routeRoleType property.
     * 
     * @return
     *     possible object is
     *     {@link RouteRoleTypeStructure }
     *     
     */
    public RouteRoleTypeStructure getRouteRoleType() {
        return routeRoleType;
    }

    /**
     * Sets the value of the routeRoleType property.
     * 
     * @param value
     *     allowed object is
     *     {@link RouteRoleTypeStructure }
     *     
     */
    public void setRouteRoleType(RouteRoleTypeStructure value) {
        this.routeRoleType = value;
    }

}
