
package com.apmoller.main.model.request;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for ValueType.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="ValueType"&gt;
 *   &lt;restriction base="{http://services.apmoller.net/AMM/v4}String20NonNullType"&gt;
 *     &lt;enumeration value="BOOKING_EQUIRY"/&gt;
 *     &lt;enumeration value="BOOKING_CONSUMPTION"/&gt;
 *     &lt;enumeration value="BOOKING_CANCELLATION"/&gt;
 *     &lt;enumeration value="PTA"/&gt;
 *   &lt;/restriction&gt;
 * &lt;/simpleType&gt;
 * </pre>
 * 
 */
@XmlType(name = "ValueType")
@XmlEnum
public enum ValueType {

    BOOKING_EQUIRY,
    BOOKING_CONSUMPTION,
    BOOKING_CANCELLATION,
    PTA;

    public String value() {
        return name();
    }

    public static ValueType fromValue(String v) {
        return valueOf(v);
    }

}
