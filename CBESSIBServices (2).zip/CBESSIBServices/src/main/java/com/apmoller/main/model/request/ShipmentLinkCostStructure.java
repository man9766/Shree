
package com.apmoller.main.model.request;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for ShipmentLinkCostStructure complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ShipmentLinkCostStructure"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="EquipmentSize" type="{http://services.apmoller.net/AMM/v4}EquipmentSizeStructure" minOccurs="0"/&gt;
 *         &lt;element name="ContainerType" type="{http://services.apmoller.net/AMM/v4}ContainerTypeStructure"/&gt;
 *         &lt;element name="LinkCostStructure" type="{http://services.apmoller.net/AMM/v4}LinkCostStructure" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ShipmentLinkCostStructure", propOrder = {
    "equipmentSize",
    "containerType",
    "linkCostStructure"
})
public class ShipmentLinkCostStructure {

    @XmlElement(name = "EquipmentSize")
    protected EquipmentSizeStructure equipmentSize;
    @XmlElement(name = "ContainerType", required = true)
    protected ContainerTypeStructure containerType;
    @XmlElement(name = "LinkCostStructure")
    protected LinkCostStructure linkCostStructure;

    /**
     * Gets the value of the equipmentSize property.
     * 
     * @return
     *     possible object is
     *     {@link EquipmentSizeStructure }
     *     
     */
    public EquipmentSizeStructure getEquipmentSize() {
        return equipmentSize;
    }

    /**
     * Sets the value of the equipmentSize property.
     * 
     * @param value
     *     allowed object is
     *     {@link EquipmentSizeStructure }
     *     
     */
    public void setEquipmentSize(EquipmentSizeStructure value) {
        this.equipmentSize = value;
    }

    /**
     * Gets the value of the containerType property.
     * 
     * @return
     *     possible object is
     *     {@link ContainerTypeStructure }
     *     
     */
    public ContainerTypeStructure getContainerType() {
        return containerType;
    }

    /**
     * Sets the value of the containerType property.
     * 
     * @param value
     *     allowed object is
     *     {@link ContainerTypeStructure }
     *     
     */
    public void setContainerType(ContainerTypeStructure value) {
        this.containerType = value;
    }

    /**
     * Gets the value of the linkCostStructure property.
     * 
     * @return
     *     possible object is
     *     {@link LinkCostStructure }
     *     
     */
    public LinkCostStructure getLinkCostStructure() {
        return linkCostStructure;
    }

    /**
     * Sets the value of the linkCostStructure property.
     * 
     * @param value
     *     allowed object is
     *     {@link LinkCostStructure }
     *     
     */
    public void setLinkCostStructure(LinkCostStructure value) {
        this.linkCostStructure = value;
    }

}
