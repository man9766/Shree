
package com.apmoller.main.model.request;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * A route between Geographical Areas or Sites that
 * 				is relevant in the context of a Shipment.
 * 
 * 				A Shipment Route describes
 * 				a through journey (of cargo and/or
 * 				equipment) through a series of
 * 				Shipment Route Points, from Place Of
 * 				Receipt (first Shipment Route
 * 				Point) to Place Of Delivery (last
 * 				Shipment Route Point). Some
 * 				Pre-carriage / On-carriage information
 * 				(ie regarding aspects of the
 * 				route that are outside the scope of the
 * 				Customer's contract with the
 * 				Enterprise) can be recorded in the
 * 				associated Shipment Route Link
 * 				entity type..
 * 
 * 				Various Product Properties of different Types can be
 * 				associated with a
 * 				Shipment Route. Example Product Property Types
 * 				include:
 * 
 * 				- Named Account Product (NAP)
 * 				- Name Account Customer Id
 * 				-
 * 				Vessel Flag 
 * 
 * 
 * <p>Java class for ShipmentRouteCustomType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ShipmentRouteCustomType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="ShipmentRouteLink" type="{http://services.apmoller.net/AMM/v4}ShipmentRouteLinkCustomType" maxOccurs="unbounded"/&gt;
 *         &lt;element name="ShipmentRouteRole" type="{http://services.apmoller.net/AMM/v4}ShipmentRouteRoleStructure"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ShipmentRouteCustomType", propOrder = {
    "shipmentRouteLink",
    "shipmentRouteRole"
})
public class ShipmentRouteCustomType {

    @XmlElement(name = "ShipmentRouteLink", required = true)
    protected List<ShipmentRouteLinkCustomType> shipmentRouteLink;
    @XmlElement(name = "ShipmentRouteRole", required = true)
    protected ShipmentRouteRoleStructure shipmentRouteRole;

    /**
     * Gets the value of the shipmentRouteLink property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the shipmentRouteLink property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getShipmentRouteLink().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link ShipmentRouteLinkCustomType }
     * 
     * 
     */
    public List<ShipmentRouteLinkCustomType> getShipmentRouteLink() {
        if (shipmentRouteLink == null) {
            shipmentRouteLink = new ArrayList<ShipmentRouteLinkCustomType>();
        }
        return this.shipmentRouteLink;
    }

    /**
     * Gets the value of the shipmentRouteRole property.
     * 
     * @return
     *     possible object is
     *     {@link ShipmentRouteRoleStructure }
     *     
     */
    public ShipmentRouteRoleStructure getShipmentRouteRole() {
        return shipmentRouteRole;
    }

    /**
     * Sets the value of the shipmentRouteRole property.
     * 
     * @param value
     *     allowed object is
     *     {@link ShipmentRouteRoleStructure }
     *     
     */
    public void setShipmentRouteRole(ShipmentRouteRoleStructure value) {
        this.shipmentRouteRole = value;
    }

}
