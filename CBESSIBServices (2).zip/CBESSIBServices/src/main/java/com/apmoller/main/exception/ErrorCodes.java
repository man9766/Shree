package com.apmoller.main.exception;

public interface ErrorCodes {

    String CustomerNotFoundException="Customer Not Found In Database";
    String ServiceNotAvauilable="Service you requested is either down or not available";
    String InvalidRequest="Invalid Request!! Please send valid request data";
    String DataAccessException="Problem in Accessing Database";
    String BusinessServiceException="Problem occured in service layer";
    
    

}