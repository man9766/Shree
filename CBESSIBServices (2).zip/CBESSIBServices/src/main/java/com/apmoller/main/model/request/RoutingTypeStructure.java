
package com.apmoller.main.model.request;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * Classifies the transport pproduct leg. Vaues:
 * 				P:
 * 				ExportS/D Link (Pickup)
 * 				E: Export hub routing
 * 				M: Main Routing
 * 				I: Import
 * 				hub Routing
 * 				D: Import S/D (Delivery)
 * 				T: Inter Terminal Transfer
 * 			
 * 
 * <p>Java class for RoutingTypeStructure complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="RoutingTypeStructure"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="RoutingTypeCd" type="{http://services.apmoller.net/AMM/v4}String1NonNullType"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "RoutingTypeStructure", propOrder = {
    "routingTypeCd"
})
public class RoutingTypeStructure {

    @XmlElement(name = "RoutingTypeCd", required = true)
    protected String routingTypeCd;

    /**
     * Gets the value of the routingTypeCd property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRoutingTypeCd() {
        return routingTypeCd;
    }

    /**
     * Sets the value of the routingTypeCd property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRoutingTypeCd(String value) {
        this.routingTypeCd = value;
    }

}
