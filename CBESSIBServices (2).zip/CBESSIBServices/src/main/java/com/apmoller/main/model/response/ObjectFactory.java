/*
package com.apmoller.main.model.response;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlElementDecl;
import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.namespace.QName;


*//**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the net.apmoller.services.amm.v4 package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 *//*
@XmlRegistry
public class ObjectFactory {

    private final static QName _ValidateShipmentOnYieldRequest_QNAME = new QName("http://services.apmoller.net/AMM/v4", "ValidateShipmentOnYieldRequest");
    private final static QName _ValidateShipmentOnYieldResponse_QNAME = new QName("http://services.apmoller.net/AMM/v4", "ValidateShipmentOnYieldResponse");

    *//**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: net.apmoller.services.amm.v4
     * 
     *//*
    public ObjectFactory() {
    }

    *//**
     * Create an instance of {@link ValidateShipmentOnYieldRequestType }
     * 
     *//*
    public ValidateShipmentOnYieldRequestType createValidateShipmentOnYieldRequestType() {
        return new ValidateShipmentOnYieldRequestType();
    }

    *//**
     * Create an instance of {@link ValidateShipmentOnYieldResponseType }
     * 
     *//*
    public ValidateShipmentOnYieldResponseType createValidateShipmentOnYieldResponseType() {
        return new ValidateShipmentOnYieldResponseType();
    }

    *//**
     * Create an instance of {@link AdditionalRequestParameterType }
     * 
     *//*
    public AdditionalRequestParameterType createAdditionalRequestParameterType() {
        return new AdditionalRequestParameterType();
    }

    *//**
     * Create an instance of {@link AdditionalRequestParamListType }
     * 
     *//*
    public AdditionalRequestParamListType createAdditionalRequestParamListType() {
        return new AdditionalRequestParamListType();
    }

    *//**
     * Create an instance of {@link AlternativeCodeCustomString13Type }
     * 
     *//*
    public AlternativeCodeCustomString13Type createAlternativeCodeCustomString13Type() {
        return new AlternativeCodeCustomString13Type();
    }

    *//**
     * Create an instance of {@link AlternativeCodeCustomString3Type }
     * 
     *//*
    public AlternativeCodeCustomString3Type createAlternativeCodeCustomString3Type() {
        return new AlternativeCodeCustomString3Type();
    }

    *//**
     * Create an instance of {@link AlternativeCodeCustomString8Type }
     * 
     *//*
    public AlternativeCodeCustomString8Type createAlternativeCodeCustomString8Type() {
        return new AlternativeCodeCustomString8Type();
    }

    *//**
     * Create an instance of {@link AlternativeCodeStructure }
     * 
     *//*
    public AlternativeCodeStructure createAlternativeCodeStructure() {
        return new AlternativeCodeStructure();
    }

    *//**
     * Create an instance of {@link AssetCustomEmptyType }
     * 
     *//*
    public AssetCustomEmptyType createAssetCustomEmptyType() {
        return new AssetCustomEmptyType();
    }

    *//**
     * Create an instance of {@link BucketCustomColorType }
     * 
     *//*
    public BucketCustomColorType createBucketCustomColorType() {
        return new BucketCustomColorType();
    }

    *//**
     * Create an instance of {@link BucketCustomType }
     * 
     *//*
    public BucketCustomType createBucketCustomType() {
        return new BucketCustomType();
    }

    *//**
     * Create an instance of {@link CardinalDirectionStructure }
     * 
     *//*
    public CardinalDirectionStructure createCardinalDirectionStructure() {
        return new CardinalDirectionStructure();
    }

    *//**
     * Create an instance of {@link CargoCustomStuffType }
     * 
     *//*
    public CargoCustomStuffType createCargoCustomStuffType() {
        return new CargoCustomStuffType();
    }

    *//**
     * Create an instance of {@link CargoCustomType }
     * 
     *//*
    public CargoCustomType createCargoCustomType() {
        return new CargoCustomType();
    }

    *//**
     * Create an instance of {@link CargoTypeStructure }
     * 
     *//*
    public CargoTypeStructure createCargoTypeStructure() {
        return new CargoTypeStructure();
    }

    *//**
     * Create an instance of {@link CommitmentCustomIdType }
     * 
     *//*
    public CommitmentCustomIdType createCommitmentCustomIdType() {
        return new CommitmentCustomIdType();
    }

    *//**
     * Create an instance of {@link CommitmentCustomValType }
     * 
     *//*
    public CommitmentCustomValType createCommitmentCustomValType() {
        return new CommitmentCustomValType();
    }

    *//**
     * Create an instance of {@link CommodityClassificationCustomCdType }
     * 
     *//*
    public CommodityClassificationCustomCdType createCommodityClassificationCustomCdType() {
        return new CommodityClassificationCustomCdType();
    }

    *//**
     * Create an instance of {@link CommodityClassificationTreatmentStructure }
     * 
     *//*
    public CommodityClassificationTreatmentStructure createCommodityClassificationTreatmentStructure() {
        return new CommodityClassificationTreatmentStructure();
    }

    *//**
     * Create an instance of {@link ContainerProfileStructure }
     * 
     *//*
    public ContainerProfileStructure createContainerProfileStructure() {
        return new ContainerProfileStructure();
    }

    *//**
     * Create an instance of {@link ContainerSizeStructure }
     * 
     *//*
    public ContainerSizeStructure createContainerSizeStructure() {
        return new ContainerSizeStructure();
    }

    *//**
     * Create an instance of {@link ContainerCustomIdType }
     * 
     *//*
    public ContainerCustomIdType createContainerCustomIdType() {
        return new ContainerCustomIdType();
    }

    *//**
     * Create an instance of {@link DangerousCharacteristicsCustomTBProdType }
     * 
     *//*
    public DangerousCharacteristicsCustomTBProdType createDangerousCharacteristicsCustomTBProdType() {
        return new DangerousCharacteristicsCustomTBProdType();
    }

    *//**
     * Create an instance of {@link ContainerTypeStructure }
     * 
     *//*
    public ContainerTypeStructure createContainerTypeStructure() {
        return new ContainerTypeStructure();
    }

    *//**
     * Create an instance of {@link CountryCurrencyStructure }
     * 
     *//*
    public CountryCurrencyStructure createCountryCurrencyStructure() {
        return new CountryCurrencyStructure();
    }

    *//**
     * Create an instance of {@link CurrencyUnitCustomCdType }
     * 
     *//*
    public CurrencyUnitCustomCdType createCurrencyUnitCustomCdType() {
        return new CurrencyUnitCustomCdType();
    }

    *//**
     * Create an instance of {@link CustomerCustomCodeType }
     * 
     *//*
    public CustomerCustomCodeType createCustomerCustomCodeType() {
        return new CustomerCustomCodeType();
    }

    *//**
     * Create an instance of {@link DatedVoyageCustomType }
     * 
     *//*
    public DatedVoyageCustomType createDatedVoyageCustomType() {
        return new DatedVoyageCustomType();
    }

    *//**
     * Create an instance of {@link DatedVoyageStructure }
     * 
     *//*
    public DatedVoyageStructure createDatedVoyageStructure() {
        return new DatedVoyageStructure();
    }

    *//**
     * Create an instance of {@link DefinedAreaCustomSiteType }
     * 
     *//*
    public DefinedAreaCustomSiteType createDefinedAreaCustomSiteType() {
        return new DefinedAreaCustomSiteType();
    }

    *//**
     * Create an instance of {@link EquipmentOOGStructure }
     * 
     *//*
    public EquipmentOOGStructure createEquipmentOOGStructure() {
        return new EquipmentOOGStructure();
    }

    *//**
     * Create an instance of {@link EquipmentProfileCustomEmptyType }
     * 
     *//*
    public EquipmentProfileCustomEmptyType createEquipmentProfileCustomEmptyType() {
        return new EquipmentProfileCustomEmptyType();
    }

    *//**
     * Create an instance of {@link EquipmentCustomContType }
     * 
     *//*
    public EquipmentCustomContType createEquipmentCustomContType() {
        return new EquipmentCustomContType();
    }

    *//**
     * Create an instance of {@link EquipmentStuffingPlanStructure }
     * 
     *//*
    public EquipmentStuffingPlanStructure createEquipmentStuffingPlanStructure() {
        return new EquipmentStuffingPlanStructure();
    }

    *//**
     * Create an instance of {@link GenericVehicleCustomEmptyType }
     * 
     *//*
    public GenericVehicleCustomEmptyType createGenericVehicleCustomEmptyType() {
        return new GenericVehicleCustomEmptyType();
    }

    *//**
     * Create an instance of {@link JourneyGroupStructure }
     * 
     *//*
    public JourneyGroupStructure createJourneyGroupStructure() {
        return new JourneyGroupStructure();
    }

    *//**
     * Create an instance of {@link JourneyLegCustomType }
     * 
     *//*
    public JourneyLegCustomType createJourneyLegCustomType() {
        return new JourneyLegCustomType();
    }

    *//**
     * Create an instance of {@link JourneyCustomGrpDirType }
     * 
     *//*
    public JourneyCustomGrpDirType createJourneyCustomGrpDirType() {
        return new JourneyCustomGrpDirType();
    }

    *//**
     * Create an instance of {@link IrregularCommitmentCustomIdType }
     * 
     *//*
    public IrregularCommitmentCustomIdType createIrregularCommitmentCustomIdType() {
        return new IrregularCommitmentCustomIdType();
    }

    *//**
     * Create an instance of {@link IrregularCommitmentCustomConsType }
     * 
     *//*
    public IrregularCommitmentCustomConsType createIrregularCommitmentCustomConsType() {
        return new IrregularCommitmentCustomConsType();
    }

    *//**
     * Create an instance of {@link IrregularCommitmentStructure }
     * 
     *//*
    public IrregularCommitmentStructure createIrregularCommitmentStructure() {
        return new IrregularCommitmentStructure();
    }

    *//**
     * Create an instance of {@link ISOContainerHeightStructure }
     * 
     *//*
    public ISOContainerHeightStructure createISOContainerHeightStructure() {
        return new ISOContainerHeightStructure();
    }

    *//**
     * Create an instance of {@link ISOContainerSizeTypeStructure }
     * 
     *//*
    public ISOContainerSizeTypeStructure createISOContainerSizeTypeStructure() {
        return new ISOContainerSizeTypeStructure();
    }

    *//**
     * Create an instance of {@link OperatorStructure }
     * 
     *//*
    public OperatorStructure createOperatorStructure() {
        return new OperatorStructure();
    }

    *//**
     * Create an instance of {@link PartyRoleStructure }
     * 
     *//*
    public PartyRoleStructure createPartyRoleStructure() {
        return new PartyRoleStructure();
    }

    *//**
     * Create an instance of {@link PartyRoleCustomOperatorType }
     * 
     *//*
    public PartyRoleCustomOperatorType createPartyRoleCustomOperatorType() {
        return new PartyRoleCustomOperatorType();
    }

    *//**
     * Create an instance of {@link ReceiptDeliveryModeStructure }
     * 
     *//*
    public ReceiptDeliveryModeStructure createReceiptDeliveryModeStructure() {
        return new ReceiptDeliveryModeStructure();
    }

    *//**
     * Create an instance of {@link RegularCommitmentCustomIdType }
     * 
     *//*
    public RegularCommitmentCustomIdType createRegularCommitmentCustomIdType() {
        return new RegularCommitmentCustomIdType();
    }

    *//**
     * Create an instance of {@link RegularCommitmentCustomFFEConsType }
     * 
     *//*
    public RegularCommitmentCustomFFEConsType createRegularCommitmentCustomFFEConsType() {
        return new RegularCommitmentCustomFFEConsType();
    }

    *//**
     * Create an instance of {@link RegularCommitmentStructure }
     * 
     *//*
    public RegularCommitmentStructure createRegularCommitmentStructure() {
        return new RegularCommitmentStructure();
    }

    *//**
     * Create an instance of {@link RouteRoleTypeStructure }
     * 
     *//*
    public RouteRoleTypeStructure createRouteRoleTypeStructure() {
        return new RouteRoleTypeStructure();
    }

    *//**
     * Create an instance of {@link RoutingTypeStructure }
     * 
     *//*
    public RoutingTypeStructure createRoutingTypeStructure() {
        return new RoutingTypeStructure();
    }

    *//**
     * Create an instance of {@link ServiceContractCommitmentCustomCustomerType }
     * 
     *//*
    public ServiceContractCommitmentCustomCustomerType createServiceContractCommitmentCustomCustomerType() {
        return new ServiceContractCommitmentCustomCustomerType();
    }

    *//**
     * Create an instance of {@link ServiceContractStructure }
     * 
     *//*
    public ServiceContractStructure createServiceContractStructure() {
        return new ServiceContractStructure();
    }

    *//**
     * Create an instance of {@link ServiceStructure }
     * 
     *//*
    public ServiceStructure createServiceStructure() {
        return new ServiceStructure();
    }

    *//**
     * Create an instance of {@link ShipmentEquipmentAssignmentCustomEqProfType }
     * 
     *//*
    public ShipmentEquipmentAssignmentCustomEqProfType createShipmentEquipmentAssignmentCustomEqProfType() {
        return new ShipmentEquipmentAssignmentCustomEqProfType();
    }

    *//**
     * Create an instance of {@link ShipmentPartyRoleStructure }
     * 
     *//*
    public ShipmentPartyRoleStructure createShipmentPartyRoleStructure() {
        return new ShipmentPartyRoleStructure();
    }

    *//**
     * Create an instance of {@link ShipmentPartyStructure }
     * 
     *//*
    public ShipmentPartyStructure createShipmentPartyStructure() {
        return new ShipmentPartyStructure();
    }

    *//**
     * Create an instance of {@link ShipmentReferenceStructure }
     * 
     *//*
    public ShipmentReferenceStructure createShipmentReferenceStructure() {
        return new ShipmentReferenceStructure();
    }

    *//**
     * Create an instance of {@link ShipmentPriceCustomType }
     * 
     *//*
    public ShipmentPriceCustomType createShipmentPriceCustomType() {
        return new ShipmentPriceCustomType();
    }

    *//**
     * Create an instance of {@link ShipmentRouteLinkCustomSteeredLegType }
     * 
     *//*
    public ShipmentRouteLinkCustomSteeredLegType createShipmentRouteLinkCustomSteeredLegType() {
        return new ShipmentRouteLinkCustomSteeredLegType();
    }

    *//**
     * Create an instance of {@link ShipmentRouteLinkCustomType }
     * 
     *//*
    public ShipmentRouteLinkCustomType createShipmentRouteLinkCustomType() {
        return new ShipmentRouteLinkCustomType();
    }

    *//**
     * Create an instance of {@link ShipmentRoutePointStructure }
     * 
     *//*
    public ShipmentRoutePointStructure createShipmentRoutePointStructure() {
        return new ShipmentRoutePointStructure();
    }

    *//**
     * Create an instance of {@link StringDirectionTypeStructure }
     * 
     *//*
    public StringDirectionTypeStructure createStringDirectionTypeStructure() {
        return new StringDirectionTypeStructure();
    }

    *//**
     * Create an instance of {@link ShipmentLinkCostStructure }
     * 
     *//*
    public ShipmentLinkCostStructure createShipmentLinkCostStructure() {
        return new ShipmentLinkCostStructure();
    }

    *//**
     * Create an instance of {@link EquipmentSizeStructure }
     * 
     *//*
    public EquipmentSizeStructure createEquipmentSizeStructure() {
        return new EquipmentSizeStructure();
    }

    *//**
     * Create an instance of {@link LinkCostStructure }
     * 
     *//*
    public LinkCostStructure createLinkCostStructure() {
        return new LinkCostStructure();
    }

    *//**
     * Create an instance of {@link CurrencyUnitStructure }
     * 
     *//*
    public CurrencyUnitStructure createCurrencyUnitStructure() {
        return new CurrencyUnitStructure();
    }

    *//**
     * Create an instance of {@link CarrierStructure }
     * 
     *//*
    public CarrierStructure createCarrierStructure() {
        return new CarrierStructure();
    }

    *//**
     * Create an instance of {@link ShipmentRouteRoleStructure }
     * 
     *//*
    public ShipmentRouteRoleStructure createShipmentRouteRoleStructure() {
        return new ShipmentRouteRoleStructure();
    }

    *//**
     * Create an instance of {@link ShipmentRouteCustomType }
     * 
     *//*
    public ShipmentRouteCustomType createShipmentRouteCustomType() {
        return new ShipmentRouteCustomType();
    }

    *//**
     * Create an instance of {@link ShipmentRouteCustomSteeredLegType }
     * 
     *//*
    public ShipmentRouteCustomSteeredLegType createShipmentRouteCustomSteeredLegType() {
        return new ShipmentRouteCustomSteeredLegType();
    }

    *//**
     * Create an instance of {@link ShipmentCustomIdType }
     * 
     *//*
    public ShipmentCustomIdType createShipmentCustomIdType() {
        return new ShipmentCustomIdType();
    }

    *//**
     * Create an instance of {@link ShipmentCustomValResType }
     * 
     *//*
    public ShipmentCustomValResType createShipmentCustomValResType() {
        return new ShipmentCustomValResType();
    }

    *//**
     * Create an instance of {@link ShipmentCustomValReqType }
     * 
     *//*
    public ShipmentCustomValReqType createShipmentCustomValReqType() {
        return new ShipmentCustomValReqType();
    }

    *//**
     * Create an instance of {@link ShipmentStatusStructure }
     * 
     *//*
    public ShipmentStatusStructure createShipmentStatusStructure() {
        return new ShipmentStatusStructure();
    }

    *//**
     * Create an instance of {@link SiteStructure }
     * 
     *//*
    public SiteStructure createSiteStructure() {
        return new SiteStructure();
    }

    *//**
     * Create an instance of {@link TariffRateCustomType }
     * 
     *//*
    public TariffRateCustomType createTariffRateCustomType() {
        return new TariffRateCustomType();
    }

    *//**
     * Create an instance of {@link TransportModeStructure }
     * 
     *//*
    public TransportModeStructure createTransportModeStructure() {
        return new TransportModeStructure();
    }

    *//**
     * Create an instance of {@link UnitOfMeasurementCustomValType }
     * 
     *//*
    public UnitOfMeasurementCustomValType createUnitOfMeasurementCustomValType() {
        return new UnitOfMeasurementCustomValType();
    }

    *//**
     * Create an instance of {@link VesselCustomCodeType }
     * 
     *//*
    public VesselCustomCodeType createVesselCustomCodeType() {
        return new VesselCustomCodeType();
    }

    *//**
     * Create an instance of {@link VesselStructure }
     * 
     *//*
    public VesselStructure createVesselStructure() {
        return new VesselStructure();
    }

    *//**
     * Create an instance of {@link ValidationDetailsType }
     * 
     *//*
    public ValidationDetailsType createValidationDetailsType() {
        return new ValidationDetailsType();
    }

    *//**
     * Create an instance of {@link ShipmentPartyRolesType }
     * 
     *//*
    public ShipmentPartyRolesType createShipmentPartyRolesType() {
        return new ShipmentPartyRolesType();
    }

    *//**
     * Create an instance of {@link ValidationEquipmentType }
     * 
     *//*
    public ValidationEquipmentType createValidationEquipmentType() {
        return new ValidationEquipmentType();
    }

    *//**
     * Create an instance of {@link ValdiateCustomReqType }
     * 
     *//*
    public ValdiateCustomReqType createValdiateCustomReqType() {
        return new ValdiateCustomReqType();
    }

    *//**
     * Create an instance of {@link JAXBElement }{@code <}{@link ValidateShipmentOnYieldRequestType }{@code >}}
     * 
     *//*
    @XmlElementDecl(namespace = "http://services.apmoller.net/AMM/v4", name = "ValidateShipmentOnYieldRequest")
    public JAXBElement<ValidateShipmentOnYieldRequestType> createValidateShipmentOnYieldRequest(ValidateShipmentOnYieldRequestType value) {
        return new JAXBElement<ValidateShipmentOnYieldRequestType>(_ValidateShipmentOnYieldRequest_QNAME, ValidateShipmentOnYieldRequestType.class, null, value);
    }

    *//**
     * Create an instance of {@link JAXBElement }{@code <}{@link ValidateShipmentOnYieldResponseType }{@code >}}
     * 
     *//*
    @XmlElementDecl(namespace = "http://services.apmoller.net/AMM/v4", name = "ValidateShipmentOnYieldResponse")
    public JAXBElement<ValidateShipmentOnYieldResponseType> createValidateShipmentOnYieldResponse(ValidateShipmentOnYieldResponseType value) {
        return new JAXBElement<ValidateShipmentOnYieldResponseType>(_ValidateShipmentOnYieldResponse_QNAME, ValidateShipmentOnYieldResponseType.class, null, value);
    }

}
*/