
package com.apmoller.main.model.response;

import java.math.BigDecimal;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for RegularCommitmentCustomFFEConsType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="RegularCommitmentCustomFFEConsType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="ConsumedFFEWeek" type="{http://services.apmoller.net/AMM/v4}Decimal9d4Type"/&gt;
 *         &lt;element name="FFE" type="{http://services.apmoller.net/AMM/v4}Decimal9d4WithNegativeType"/&gt;
 *         &lt;element name="UnusedFFE" type="{http://services.apmoller.net/AMM/v4}Decimal18d4WithNegativeType"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "RegularCommitmentCustomFFEConsType", propOrder = {
    "consumedFFEWeek",
    "ffe",
    "unusedFFE"
})
public class RegularCommitmentCustomFFEConsType {

    @XmlElement(name = "ConsumedFFEWeek", required = true)
    protected BigDecimal consumedFFEWeek;
    @XmlElement(name = "FFE", required = true)
    protected BigDecimal ffe;
    @XmlElement(name = "UnusedFFE", required = true)
    protected BigDecimal unusedFFE;

    /**
     * Gets the value of the consumedFFEWeek property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getConsumedFFEWeek() {
        return consumedFFEWeek;
    }

    /**
     * Sets the value of the consumedFFEWeek property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setConsumedFFEWeek(BigDecimal value) {
        this.consumedFFEWeek = value;
    }

    /**
     * Gets the value of the ffe property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getFFE() {
        return ffe;
    }

    /**
     * Sets the value of the ffe property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setFFE(BigDecimal value) {
        this.ffe = value;
    }

    /**
     * Gets the value of the unusedFFE property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getUnusedFFE() {
        return unusedFFE;
    }

    /**
     * Sets the value of the unusedFFE property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setUnusedFFE(BigDecimal value) {
        this.unusedFFE = value;
    }

}
