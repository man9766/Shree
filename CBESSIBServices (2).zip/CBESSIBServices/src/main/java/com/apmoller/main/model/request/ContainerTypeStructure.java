
package com.apmoller.main.model.request;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * Maersk names for container type e.g. 'DRY' which
 * 				indicates that this container is for dry cargo that does not need a
 * 				reefer.
 * 				Other examples include, REEF, OPEN, TANK, BULK etc.
 * 			
 * 
 * <p>Java class for ContainerTypeStructure complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ContainerTypeStructure"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="ContainerTypeCd" type="{http://services.apmoller.net/AMM/v4}String4NonNullType"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ContainerTypeStructure", propOrder = {
    "containerTypeCd"
})
public class ContainerTypeStructure {

    @XmlElement(name = "ContainerTypeCd", required = true)
    protected String containerTypeCd;

    /**
     * Gets the value of the containerTypeCd property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getContainerTypeCd() {
        return containerTypeCd;
    }

    /**
     * Sets the value of the containerTypeCd property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setContainerTypeCd(String value) {
        this.containerTypeCd = value;
    }

}
