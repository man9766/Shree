   
package com.apmoller.main.model.request;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

import org.hibernate.validator.constraints.NotBlank;

import com.apmoller.main.model.RequestDataSample;







/**
 * <p>Java class for ValidateShipmentOnYieldRequestType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ValidateShipmentOnYieldRequestType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="ShipmentRequest" type="{http://services.apmoller.net/AMM/v4}ValdiateCustomReqType" maxOccurs="unbounded"/&gt;
 *         &lt;element name="RequestParameterList" type="{http://services.apmoller.net/AMM/v4}AdditionalRequestParamListType" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ValidateShipmentOnYieldRequestType", propOrder = {
		/*"listSampleRequest"*/
    "shipmentRequest",
    "requestParameterList"
})
public class ValidateShipmentOnYieldRequestType implements Serializable{


	
	/*
	@XmlElement(name = "ListSampleRequest")
	protected List<RequestDataSample> listSampleRequest;
	
	public List<RequestDataSample> getListSampleRequest() {
		return listSampleRequest;
	}

	public void setListSampleRequest(List<RequestDataSample> listSampleRequest) {
		this.listSampleRequest = listSampleRequest;
	}*/

    @XmlElement(name = "ShipmentRequest", required = true)
    //@NotBlank(message = "shipmentRequest must not be blank!")
    protected List<ValdiateCustomReqType> shipmentRequest;
    @XmlElement(name = "RequestParameterList")
    protected AdditionalRequestParamListType requestParameterList;
    
   
	/**
     * Gets the value of the shipmentRequest property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the shipmentRequest property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getShipmentRequest().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link ValdiateCustomReqType }
     * 
     * 
     */
    public List<ValdiateCustomReqType> getShipmentRequest() {
        if (shipmentRequest == null) {
            shipmentRequest = new ArrayList<ValdiateCustomReqType>();
        }
        return this.shipmentRequest;
    }

    /**
     * Gets the value of the requestParameterList property.
     * 
     * @return
     *     possible object is
     *     {@link AdditionalRequestParamListType }
     *     
     */
    public AdditionalRequestParamListType getRequestParameterList() {
        return requestParameterList;
    }

    /**
     * Sets the value of the requestParameterList property.
     * 
     * @param value
     *     allowed object is
     *     {@link AdditionalRequestParamListType }
     *     
     */
    public void setRequestParameterList(AdditionalRequestParamListType value) {
        this.requestParameterList = value;
    }

}


/*@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ValidateShipmentOnYieldRequestType", propOrder = {
    "shipmentRequest",
    "requestParameterList"
})
public class ValidateShipmentOnYieldRequestType implements Serializable{

	 @XmlElement(name = "ShipmentRequest", required = true)
	    protected List<ValdiateCustomReqType> shipmentRequest;
	    
	 @XmlElement(name = "RequestParameterList")
	    protected AdditionalRequestParamListType requestParameterList;
	    
	    
	    
		public List<ValdiateCustomReqType> getShipmentRequest() {
			return shipmentRequest;
		}
		public void setShipmentRequest(List<ValdiateCustomReqType> shipmentRequest) {
			this.shipmentRequest = shipmentRequest;
		}
		public AdditionalRequestParamListType getRequestParameterList() {
			return requestParameterList;
		}
		public void setRequestParameterList(AdditionalRequestParamListType requestParameterList) {
			this.requestParameterList = requestParameterList;
		}
	
	
	
	
	@XmlElement(name = "shipmentrequest", required = true)
    protected  String shipmentrequest;
    
	@XmlElement(name = "requestparameterlist", required = true)
    protected List<RequestDataSample> requestparameterlist;

	

	

	public String getShipmentrequest() {
		return shipmentrequest;
	}

	public void setShipmentrequest(String shipmentrequest) {
		this.shipmentrequest = shipmentrequest;
	}

	public List<RequestDataSample> getRequestparameterlist() {
		return requestparameterlist;
	}

	public void setRequestparameterlist(List<RequestDataSample> requestparameterlist) {
		this.requestparameterlist = requestparameterlist;
	}


	

	
    
        
    

}


*/





