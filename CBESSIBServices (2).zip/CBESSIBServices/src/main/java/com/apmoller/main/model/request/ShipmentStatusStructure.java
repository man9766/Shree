
package com.apmoller.main.model.request;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * A state that a Shipment can be in during its
 * 				lifecycle. Examples include:
 * 
 * 				- Active: The Shipment is active, i.e.,
 * 				the transport order execution
 * 				is not yet completed.
 * 				- Cancelled by
 * 				Customer: Inactive state. The Shipment has been
 * 				cancelled by a
 * 				Customer.
 * 				- Cancelled by Carrier: Inactive state. The Shipment has
 * 				been
 * 				cancelled by the carrier
 * 				- Migrated Off: Inactive state. The
 * 				Shipment has been reorganized
 * 				(split/combine scenario, or operational
 * 				routing deviates from
 * 				product route), and new Shipment(s) have been
 * 				populated. This
 * 				Shipment is linked to the new Shipment(s) by the
 * 				Shipment Linkage
 * 				entity.
 * 				- Terminated: Transport has finished (that
 * 				is, cargo has been
 * 				delivered to the receiver), and all customer
 * 				service tasks have been
 * 				completed.
 * 				- Completed: The Shipment is
 * 				considered complete from a financial
 * 				perspective
 * 
 * 
 * <p>Java class for ShipmentStatusStructure complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ShipmentStatusStructure"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="ShipmentStatusCd" type="{http://services.apmoller.net/AMM/v4}String30NonNullType"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ShipmentStatusStructure", propOrder = {
    "shipmentStatusCd"
})
public class ShipmentStatusStructure {

    @XmlElement(name = "ShipmentStatusCd", required = true)
    protected String shipmentStatusCd;

    /**
     * Gets the value of the shipmentStatusCd property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getShipmentStatusCd() {
        return shipmentStatusCd;
    }

    /**
     * Sets the value of the shipmentStatusCd property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setShipmentStatusCd(String value) {
        this.shipmentStatusCd = value;
    }

}
