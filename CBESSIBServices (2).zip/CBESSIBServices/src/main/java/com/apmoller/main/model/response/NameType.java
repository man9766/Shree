
package com.apmoller.main.model.response;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for NameType.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="NameType"&gt;
 *   &lt;restriction base="{http://services.apmoller.net/AMM/v4}String15NonNullType"&gt;
 *     &lt;enumeration value="REQUEST_CONTEXT"/&gt;
 *   &lt;/restriction&gt;
 * &lt;/simpleType&gt;
 * </pre>
 * 
 */
@XmlType(name = "NameType")
@XmlEnum
public enum NameType {

    REQUEST_CONTEXT;

    public String value() {
        return name();
    }

    public static NameType fromValue(String v) {
        return valueOf(v);
    }

}
