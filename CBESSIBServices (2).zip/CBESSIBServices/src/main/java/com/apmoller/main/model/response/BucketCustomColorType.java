
package com.apmoller.main.model.response;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * A Bucket against which a Booking for a Shipment
 * 				was (wholly or partly) accepted
 * 
 * <p>Java class for BucketCustomColorType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="BucketCustomColorType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="BucketColourCode" type="{http://services.apmoller.net/AMM/v4}String50NonNullType"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "BucketCustomColorType", propOrder = {
    "bucketColourCode"
})
public class BucketCustomColorType {

    @XmlElement(name = "BucketColourCode", required = true)
    protected String bucketColourCode;

    /**
     * Gets the value of the bucketColourCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBucketColourCode() {
        return bucketColourCode;
    }

    /**
     * Sets the value of the bucketColourCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBucketColourCode(String value) {
        this.bucketColourCode = value;
    }

}
