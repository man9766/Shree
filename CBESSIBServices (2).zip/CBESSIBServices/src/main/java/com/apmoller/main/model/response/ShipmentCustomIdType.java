
package com.apmoller.main.model.response;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * An order for cargo transport, or a 'prebooking'
 * 				for cargo transport.
 * 
 * 				Versioning: The Shipment entity type and a
 * 				number of associated entity types in
 * 				the Shipment, Shipment Cargo,
 * 				Shipment Equipment, Shipment Route and
 * 				Shipment Price clusters
 * 				together form an extended complex data
 * 				structure or 'compound entity
 * 				type' centred on Shipment. A compound
 * 				Shipment entity can go through
 * 				multiple versions during its
 * 				lifecycle, with each version
 * 				representing the state of the Shipment
 * 				with all its assocated
 * 				entities at a point in time. The specific
 * 				list of entities included
 * 				in the compound Shipment entity type is
 * 				not detailed here; note
 * 				however that Shipment Document (including
 * 				Transport Document) is
 * 				versioned separately.
 * 
 * 				A version of a Shipment may optionally include
 * 				a 'version purpose'
 * 				that indicates the business purpose of the
 * 				version. This must be one
 * 				of a number of defined Types. Eg 'Booking
 * 				Confirmation'.
 * 
 * 				The entity relationship models for the clusters
 * 				mentioned above show
 * 				only relationships between current versions of
 * 				entities.
 * 			
 * 
 * <p>Java class for ShipmentCustomIdType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ShipmentCustomIdType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="ShipmentId" type="{http://services.apmoller.net/AMM/v4}String9NonNullType"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ShipmentCustomIdType", propOrder = {
    "shipmentId"
})
public class ShipmentCustomIdType {

    @XmlElement(name = "ShipmentId", required = true)
    protected String shipmentId;

    /**
     * Gets the value of the shipmentId property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getShipmentId() {
        return shipmentId;
    }

    /**
     * Sets the value of the shipmentId property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setShipmentId(String value) {
        this.shipmentId = value;
    }

}
