
package com.apmoller.main.model.request;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * The four cardinal directions or cardinal points
 * 				are the directions of north, south, east, and west, commonly denoted
 * 				by their initials: N, S, E, W. East and west are at right angles to
 * 				north and south, with east being in the direction of rotation and
 * 				west being directly opposite. Intermediate points between the four
 * 				cardinal directions from the points of the compass. The intermediate
 * 				(intercardinal, or ordinal) directions are north-east (NE),
 * 				north-west (NW), south-west (SW), and south-east (SE).
 * 			
 * 
 * <p>Java class for CardinalDirectionStructure complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="CardinalDirectionStructure"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="CardinalDirectionCd" type="{http://services.apmoller.net/AMM/v4}String2NonNullType"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "CardinalDirectionStructure", propOrder = {
    "cardinalDirectionCd"
})
public class CardinalDirectionStructure {

    @XmlElement(name = "CardinalDirectionCd", required = true)
    protected String cardinalDirectionCd;

    /**
     * Gets the value of the cardinalDirectionCd property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCardinalDirectionCd() {
        return cardinalDirectionCd;
    }

    /**
     * Sets the value of the cardinalDirectionCd property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCardinalDirectionCd(String value) {
        this.cardinalDirectionCd = value;
    }

}
