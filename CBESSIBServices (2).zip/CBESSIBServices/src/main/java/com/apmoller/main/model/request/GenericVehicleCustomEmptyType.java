
package com.apmoller.main.model.request;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlSeeAlso;
import javax.xml.bind.annotation.XmlType;


/**
 * A specific instance of a means of transport (for
 * 				example a vessel, a truck, a railway wagon or a barge) designed for
 * 				the transport of cargo (usually more specifically for the transport
 * 				of containers).
 * 				It may link to more specific type of vehicle.
 * 			
 * 
 * <p>Java class for GenericVehicleCustomEmptyType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="GenericVehicleCustomEmptyType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "GenericVehicleCustomEmptyType")
@XmlSeeAlso({
    VesselCustomCodeType.class,
    VesselStructure.class
})
public class GenericVehicleCustomEmptyType {


}
