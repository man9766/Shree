package com.apmoller.main.service;


import java.util.List;

import org.springframework.stereotype.Service;

import com.apmoller.main.exception.BusinessServiceLayerException;
import com.apmoller.main.model.RequestData;
import com.apmoller.main.model.ResponseData;

@Service
public interface CbeProcessInputDataService {
	
	public ResponseData processInputData(RequestData addDetails) throws BusinessServiceLayerException;

	public List<RequestData> processInputDataRequest(String operator);
}
