/*package com.apmoller.main.dao.impl;



import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.apmoller.main.controller.CBEController;
import com.apmoller.main.dao.CbeProcessInputDataDao;
import com.apmoller.main.dao.CbeProcessInputDataRepository;
import com.apmoller.main.exception.DaoAccessException;
import com.apmoller.main.model.RequestData;
import com.apmoller.main.model.ResponseData;

@Component
public class CbeProcessInputDataDaoImpl implements CbeProcessInputDataDao {
	
	private static final Logger logger = LoggerFactory
			.getLogger(CbeProcessInputDataDaoImpl.class);
	
	@Autowired
	private ResponseData responseData;
	
	

	@Autowired
	CbeProcessInputDataRepository cbeProcessInputDataRepository;
	
	//private static final Logger logger = LoggerFactory.getLogger(CbeProcessInputDataDaoImpl.class);

		
		@Override
		public ResponseData processInputData(RequestData addDetails) throws Exception{
			ResponseData responseData =  new ResponseData();
			
			
			if("".equals(addDetails.getOperater()) )
			throw new Exception();
			else
			{
			//try {
			System.out.println("********");
			cbeProcessInputDataRepository.save(addDetails);
			
			//}catch(Exception databaseException)
			{
				logger.info("####EXCEPTION:: Problem in DAO Layer Accessign database, Database call failed in processInputData Method of CbeProcessInputDataDaoImpl ###########"+databaseException);
				throw new DaoAccessException();
			}
			
			responseData.setMessage("Request Has been process Successfully");
			responseData.setResponseCode("SUCCESS0000");
			return responseData;
			}
			
		}
		
		public List<RequestData> processInputDataRequest(String operator)
		{
			//List<RequestData> requestData = new ArrayList<RequestData>();
			
			return cbeProcessInputDataRepository.findAll();
			
		}

	
}
*/