
package com.apmoller.main.model.request;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * 
 * 				Route Role Type.
 * 				Route Role Types include:
 * 				- Product
 * 				Route
 * 				- Operational Route
 * 				- Contractual Route
 * 				- Arranged Route
 * 				-
 * 				Customer Preferred Route
 * 				- Pricing Route
 * 				- Other: A Shipment Route
 * 				Role of a Type that is not one of the main
 * 				Shipment Route Role Types.
 * 				Examples include:
 * 				- Initial Transport Plan
 * 				- Route at time of first
 * 				load
 * 
 * 
 * <p>Java class for RouteRoleTypeStructure complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="RouteRoleTypeStructure"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="RouteRoleTypeCd" type="{http://services.apmoller.net/AMM/v4}String1NonNullType"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "RouteRoleTypeStructure", propOrder = {
    "routeRoleTypeCd"
})
public class RouteRoleTypeStructure {

    @XmlElement(name = "RouteRoleTypeCd", required = true)
    protected String routeRoleTypeCd;

    /**
     * Gets the value of the routeRoleTypeCd property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRouteRoleTypeCd() {
        return routeRoleTypeCd;
    }

    /**
     * Sets the value of the routeRoleTypeCd property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRouteRoleTypeCd(String value) {
        this.routeRoleTypeCd = value;
    }

}
