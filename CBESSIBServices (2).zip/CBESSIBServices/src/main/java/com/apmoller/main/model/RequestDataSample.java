package com.apmoller.main.model;

import java.io.Serializable;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;



@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "requestdatasample")
public class RequestDataSample implements Serializable{
	
	
	@XmlElement(name = "OperaterValue")
	private String operaterValue;
		/*private String shipmentid;
		private String startsitecode;
		private String endsitecode;
		private String bookedbycustomercd;
		private String contractualcustomercd;
		private String shippercd;
		private String priceownercd;
		*/

	
	public String getOperaterValue() {
		return operaterValue;
	}


	public void setOperaterValue(String operaterValue) {
		this.operaterValue = operaterValue;
	}
		
	



/*

		public String getShipmentid() {
			return shipmentid;
		}










		public void setShipmentid(String shipmentid) {
			this.shipmentid = shipmentid;
		}










		public String getStartsitecode() {
			return startsitecode;
		}










		public void setStartsitecode(String startsitecode) {
			this.startsitecode = startsitecode;
		}










		public String getEndsitecode() {
			return endsitecode;
		}










		public void setEndsitecode(String endsitecode) {
			this.endsitecode = endsitecode;
		}










		public String getBookedbycustomercd() {
			return bookedbycustomercd;
		}










		public void setBookedbycustomercd(String bookedbycustomercd) {
			this.bookedbycustomercd = bookedbycustomercd;
		}










		public String getContractualcustomercd() {
			return contractualcustomercd;
		}










		public void setContractualcustomercd(String contractualcustomercd) {
			this.contractualcustomercd = contractualcustomercd;
		}










		public String getShippercd() {
			return shippercd;
		}










		public void setShippercd(String shippercd) {
			this.shippercd = shippercd;
		}










		public String getPriceownercd() {
			return priceownercd;
		}










		public void setPriceownercd(String priceownercd) {
			this.priceownercd = priceownercd;
		}




*/





	










/*
		public RequestDataSample(String operater, String shipmentId,
				String startSiteCode, String endSiteCode,
				String bookedByCustomerCd, String contractualCustomerCd,
				String shipperCd, String priceOwnerCd) {
			super();
			
			this.operater = operater;
			this.shipmentid = shipmentId;
			this.startsitecode = startSiteCode;
			this.endsitecode = endSiteCode;
			this.bookedbycustomercd = bookedByCustomerCd;
			this.contractualcustomercd = contractualCustomerCd;
			this.shippercd = shipperCd;
			this.priceownercd = priceOwnerCd;
		}*/


/*		@Override
		public String toString() {
			return "RequestData [operater=" + operater + ", shipmentId="
					+ shipmentid + ", startSiteCode=" + startsitecode
					+ ", endSiteCode=" + endsitecode + ", bookedByCustomerCd="
					+ bookedbycustomercd + ", contractualCustomerCd="
					+ contractualcustomercd + ", shipperCd=" + shippercd
					+ ", priceOwnerCd=" + priceownercd + "]";
		}
*/
}
