package com.apmoller.main.service.impl;



import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import com.apmoller.main.exception.BusinessServiceLayerException;
import com.apmoller.main.model.RequestData;
import com.apmoller.main.model.ResponseData;
import com.apmoller.main.service.CbeProcessInputDataService;

@Service
public class CbeProcessInputDataServiceImpl implements CbeProcessInputDataService{
	
	
	/*@Autowired
	CbeProcessInputDataDao cbeProcessInputDataDao;
	
	
	public CbeProcessInputDataDao getCbeProcessInputDataDao() {
		return cbeProcessInputDataDao;
	}


	public void setCbeProcessInputDataDao(CbeProcessInputDataDao cbeProcessInputDataDao) {
		this.cbeProcessInputDataDao = cbeProcessInputDataDao;
	}
*/

	public ResponseData processInputData(RequestData addDetails) throws BusinessServiceLayerException {
		ResponseData responseData =  new ResponseData();
		/*try {
		responseData =  cbeProcessInputDataDao.processInputData(addDetails);
		}catch(Exception businesServiceException) {
			
			throw new BusinessServiceLayerException();
		}*/
		
		return responseData;
	}
	
	public List<RequestData> processInputDataRequest(String operator)
	{
		//return cbeProcessInputDataDao.processInputDataRequest(operator);
		 List<RequestData> listrequestData = new ArrayList<RequestData>();
		return listrequestData;		
	}
	
	
}
