
package com.apmoller.main.model.request;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * A reference associated with a Shipment, and
 * 				optionally with detailed data associated with the Shipment. The
 * 				reference must have an owner: either the Enterprise (or part
 * 				thereof), or an external Party.
 * 
 * 				A Shipment Reference must have a
 * 				Type. Examples of Types include:
 * 				- Booking Number
 * 				- Party Booking
 * 				Reference
 * 				- Haulage Reference
 * 				- E-Trade Partner Reference
 * 				- Dock
 * 				Receipt Number
 * 				- Freight Invoice Number
 * 				- Bonded Shipment Transport Nr
 * 				- Service Contract Number
 * 
 * 
 * <p>Java class for ShipmentReferenceStructure complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ShipmentReferenceStructure"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="ShipmentReferenceString" type="{http://services.apmoller.net/AMM/v4}String100NonNullType"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ShipmentReferenceStructure", propOrder = {
    "shipmentReferenceString"
})
public class ShipmentReferenceStructure {

    @XmlElement(name = "ShipmentReferenceString", required = true)
    protected String shipmentReferenceString;

    /**
     * Gets the value of the shipmentReferenceString property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getShipmentReferenceString() {
        return shipmentReferenceString;
    }

    /**
     * Sets the value of the shipmentReferenceString property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setShipmentReferenceString(String value) {
        this.shipmentReferenceString = value;
    }

}
