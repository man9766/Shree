@javax.xml.bind.annotation.XmlSchema(namespace = "http://services.apmoller.net/AMM/v4", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package com.apmoller.main.model.response;
