
package com.apmoller.main.model.request;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;


/**
 * An order for cargo transport, or a 'prebooking'
 * 				for cargo transport.
 * 
 * 				Versioning: The Shipment entity type and a
 * 				number of associated entity types in
 * 				the Shipment, Shipment Cargo,
 * 				Shipment Equipment, Shipment Route and
 * 				Shipment Price clusters
 * 				together form an extended complex data
 * 				structure or 'compound entity
 * 				type' centred on Shipment. A compound
 * 				Shipment entity can go through
 * 				multiple versions during its
 * 				lifecycle, with each version
 * 				representing the state of the Shipment
 * 				with all its assocated
 * 				entities at a point in time. The specific
 * 				list of entities included
 * 				in the compound Shipment entity type is
 * 				not detailed here; note
 * 				however that Shipment Document (including
 * 				Transport Document) is
 * 				versioned separately.
 * 
 * 				A version of a Shipment may optionally include
 * 				a 'version purpose'
 * 				that indicates the business purpose of the
 * 				version. This must be one
 * 				of a number of defined Types. Eg 'Booking
 * 				Confirmation'.
 * 
 * 				The entity relationship models for the clusters
 * 				mentioned above show
 * 				only relationships between current versions of
 * 				entities.
 * 			
 * 
 * <p>Java class for ShipmentCustomValReqType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ShipmentCustomValReqType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="Cargo" type="{http://services.apmoller.net/AMM/v4}CargoCustomType"/&gt;
 *         &lt;element name="DeliveryReceiptModeCombination" type="{http://services.apmoller.net/AMM/v4}Receipt-DeliveryModeStructure"/&gt;
 *         &lt;element name="IsConferencePriced" type="{http://services.apmoller.net/AMM/v4}BooleanType" minOccurs="0"/&gt;
 *         &lt;element name="Operator" type="{http://services.apmoller.net/AMM/v4}OperatorStructure"/&gt;
 *         &lt;element name="ServiceContract" type="{http://services.apmoller.net/AMM/v4}ServiceContractStructure" minOccurs="0"/&gt;
 *         &lt;element name="ShipmentEquipmentAssignment" type="{http://services.apmoller.net/AMM/v4}ShipmentEquipmentAssignmentCustomEqProfType" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="ShipmentId" type="{http://services.apmoller.net/AMM/v4}String9NonNullType"/&gt;
 *         &lt;element name="ShipmentPartyRoles" type="{http://services.apmoller.net/AMM/v4}ShipmentPartyRolesType"/&gt;
 *         &lt;element name="ShipmentReference" type="{http://services.apmoller.net/AMM/v4}ShipmentReferenceStructure" minOccurs="0"/&gt;
 *         &lt;element name="ShipmentRoute" type="{http://services.apmoller.net/AMM/v4}ShipmentRouteCustomType" maxOccurs="unbounded"/&gt;
 *         &lt;element name="ShipmentStatus" type="{http://services.apmoller.net/AMM/v4}ShipmentStatusStructure"/&gt;
 *         &lt;element name="ShipmentConfirmed" type="{http://services.apmoller.net/AMM/v4}String20NonNullType" minOccurs="0"/&gt;
 *         &lt;element name="IsMilitary" type="{http://services.apmoller.net/AMM/v4}BooleanType" minOccurs="0"/&gt;
 *         &lt;element name="PricedByAFLS" type="{http://services.apmoller.net/AMM/v4}BooleanType" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ShipmentCustomValReqType", propOrder = {
    "cargo",
    "deliveryReceiptModeCombination",
    "isConferencePriced",
    "operator",
    "serviceContract",
    "shipmentEquipmentAssignment",
    "shipmentId",
    "shipmentPartyRoles",
    "shipmentReference",
    "shipmentRoute",
    "shipmentStatus",
    "shipmentConfirmed",
    "isMilitary",
    "pricedByAFLS"
})
public class ShipmentCustomValReqType {

    @XmlElement(name = "Cargo", required = true)
    protected CargoCustomType cargo;
    @XmlElement(name = "DeliveryReceiptModeCombination", required = true)
    protected ReceiptDeliveryModeStructure deliveryReceiptModeCombination;
    @XmlElement(name = "IsConferencePriced")
    @XmlSchemaType(name = "anySimpleType")
    protected String isConferencePriced;
    @XmlElement(name = "Operator", required = true)
    protected OperatorStructure operator;
    @XmlElement(name = "ServiceContract")
    protected ServiceContractStructure serviceContract;
    @XmlElement(name = "ShipmentEquipmentAssignment")
    protected List<ShipmentEquipmentAssignmentCustomEqProfType> shipmentEquipmentAssignment;
    @XmlElement(name = "ShipmentId", required = true)
    protected String shipmentId;
    @XmlElement(name = "ShipmentPartyRoles", required = true)
    protected ShipmentPartyRolesType shipmentPartyRoles;
    @XmlElement(name = "ShipmentReference")
    protected ShipmentReferenceStructure shipmentReference;
    @XmlElement(name = "ShipmentRoute", required = true)
    protected List<ShipmentRouteCustomType> shipmentRoute;
    @XmlElement(name = "ShipmentStatus", required = true)
    protected ShipmentStatusStructure shipmentStatus;
    @XmlElement(name = "ShipmentConfirmed")
    protected String shipmentConfirmed;
    @XmlElement(name = "IsMilitary")
    @XmlSchemaType(name = "anySimpleType")
    protected String isMilitary;
    @XmlElement(name = "PricedByAFLS")
    @XmlSchemaType(name = "anySimpleType")
    protected String pricedByAFLS;

    /**
     * Gets the value of the cargo property.
     * 
     * @return
     *     possible object is
     *     {@link CargoCustomType }
     *     
     */
    public CargoCustomType getCargo() {
        return cargo;
    }

    /**
     * Sets the value of the cargo property.
     * 
     * @param value
     *     allowed object is
     *     {@link CargoCustomType }
     *     
     */
    public void setCargo(CargoCustomType value) {
        this.cargo = value;
    }

    /**
     * Gets the value of the deliveryReceiptModeCombination property.
     * 
     * @return
     *     possible object is
     *     {@link ReceiptDeliveryModeStructure }
     *     
     */
    public ReceiptDeliveryModeStructure getDeliveryReceiptModeCombination() {
        return deliveryReceiptModeCombination;
    }

    /**
     * Sets the value of the deliveryReceiptModeCombination property.
     * 
     * @param value
     *     allowed object is
     *     {@link ReceiptDeliveryModeStructure }
     *     
     */
    public void setDeliveryReceiptModeCombination(ReceiptDeliveryModeStructure value) {
        this.deliveryReceiptModeCombination = value;
    }

    /**
     * Gets the value of the isConferencePriced property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getIsConferencePriced() {
        return isConferencePriced;
    }

    /**
     * Sets the value of the isConferencePriced property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setIsConferencePriced(String value) {
        this.isConferencePriced = value;
    }

    /**
     * Gets the value of the operator property.
     * 
     * @return
     *     possible object is
     *     {@link OperatorStructure }
     *     
     */
    public OperatorStructure getOperator() {
        return operator;
    }

    /**
     * Sets the value of the operator property.
     * 
     * @param value
     *     allowed object is
     *     {@link OperatorStructure }
     *     
     */
    public void setOperator(OperatorStructure value) {
        this.operator = value;
    }

    /**
     * Gets the value of the serviceContract property.
     * 
     * @return
     *     possible object is
     *     {@link ServiceContractStructure }
     *     
     */
    public ServiceContractStructure getServiceContract() {
        return serviceContract;
    }

    /**
     * Sets the value of the serviceContract property.
     * 
     * @param value
     *     allowed object is
     *     {@link ServiceContractStructure }
     *     
     */
    public void setServiceContract(ServiceContractStructure value) {
        this.serviceContract = value;
    }

    /**
     * Gets the value of the shipmentEquipmentAssignment property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the shipmentEquipmentAssignment property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getShipmentEquipmentAssignment().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link ShipmentEquipmentAssignmentCustomEqProfType }
     * 
     * 
     */
    public List<ShipmentEquipmentAssignmentCustomEqProfType> getShipmentEquipmentAssignment() {
        if (shipmentEquipmentAssignment == null) {
            shipmentEquipmentAssignment = new ArrayList<ShipmentEquipmentAssignmentCustomEqProfType>();
        }
        return this.shipmentEquipmentAssignment;
    }

    /**
     * Gets the value of the shipmentId property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getShipmentId() {
        return shipmentId;
    }

    /**
     * Sets the value of the shipmentId property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setShipmentId(String value) {
        this.shipmentId = value;
    }

    /**
     * Gets the value of the shipmentPartyRoles property.
     * 
     * @return
     *     possible object is
     *     {@link ShipmentPartyRolesType }
     *     
     */
    public ShipmentPartyRolesType getShipmentPartyRoles() {
        return shipmentPartyRoles;
    }

    /**
     * Sets the value of the shipmentPartyRoles property.
     * 
     * @param value
     *     allowed object is
     *     {@link ShipmentPartyRolesType }
     *     
     */
    public void setShipmentPartyRoles(ShipmentPartyRolesType value) {
        this.shipmentPartyRoles = value;
    }

    /**
     * Gets the value of the shipmentReference property.
     * 
     * @return
     *     possible object is
     *     {@link ShipmentReferenceStructure }
     *     
     */
    public ShipmentReferenceStructure getShipmentReference() {
        return shipmentReference;
    }

    /**
     * Sets the value of the shipmentReference property.
     * 
     * @param value
     *     allowed object is
     *     {@link ShipmentReferenceStructure }
     *     
     */
    public void setShipmentReference(ShipmentReferenceStructure value) {
        this.shipmentReference = value;
    }

    /**
     * Gets the value of the shipmentRoute property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the shipmentRoute property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getShipmentRoute().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link ShipmentRouteCustomType }
     * 
     * 
     */
    public List<ShipmentRouteCustomType> getShipmentRoute() {
        if (shipmentRoute == null) {
            shipmentRoute = new ArrayList<ShipmentRouteCustomType>();
        }
        return this.shipmentRoute;
    }

    /**
     * Gets the value of the shipmentStatus property.
     * 
     * @return
     *     possible object is
     *     {@link ShipmentStatusStructure }
     *     
     */
    public ShipmentStatusStructure getShipmentStatus() {
        return shipmentStatus;
    }

    /**
     * Sets the value of the shipmentStatus property.
     * 
     * @param value
     *     allowed object is
     *     {@link ShipmentStatusStructure }
     *     
     */
    public void setShipmentStatus(ShipmentStatusStructure value) {
        this.shipmentStatus = value;
    }

    /**
     * Gets the value of the shipmentConfirmed property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getShipmentConfirmed() {
        return shipmentConfirmed;
    }

    /**
     * Sets the value of the shipmentConfirmed property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setShipmentConfirmed(String value) {
        this.shipmentConfirmed = value;
    }

    /**
     * Gets the value of the isMilitary property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getIsMilitary() {
        return isMilitary;
    }

    /**
     * Sets the value of the isMilitary property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setIsMilitary(String value) {
        this.isMilitary = value;
    }

    /**
     * Gets the value of the pricedByAFLS property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPricedByAFLS() {
        return pricedByAFLS;
    }

    /**
     * Sets the value of the pricedByAFLS property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPricedByAFLS(String value) {
        this.pricedByAFLS = value;
    }

}
