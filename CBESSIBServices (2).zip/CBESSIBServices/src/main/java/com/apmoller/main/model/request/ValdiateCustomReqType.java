
package com.apmoller.main.model.request;

import java.io.Serializable;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.datatype.XMLGregorianCalendar;


/**
 * An order for cargo transport, or a 'prebooking'
 * 				for cargo transport.
 * 
 * 				Versioning: The Shipment entity type and a
 * 				number of associated entity types in
 * 				the Shipment, Shipment Cargo,
 * 				Shipment Equipment, Shipment Route and
 * 				Shipment Price clusters
 * 				together form an extended complex data
 * 				structure or 'compound entity
 * 				type' centred on Shipment. A compound
 * 				Shipment entity can go through
 * 				multiple versions during its
 * 				lifecycle, with each version
 * 				representing the state of the Shipment
 * 				with all its assocated
 * 				entities at a point in time. The specific
 * 				list of entities included
 * 				in the compound Shipment entity type is
 * 				not detailed here; note
 * 				however that Shipment Document (including
 * 				Transport Document) is
 * 				versioned separately.
 * 
 * 				A version of a Shipment may optionally include
 * 				a 'version purpose'
 * 				that indicates the business purpose of the
 * 				version. This must be one
 * 				of a number of defined Types. Eg 'Booking
 * 				Confirmation'.
 * 
 * 				The entity relationship models for the clusters
 * 				mentioned above show
 * 				only relationships between current versions of
 * 				entities.
 * 			
 * 
 * <p>Java class for ValdiateCustomReqType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ValdiateCustomReqType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="ClientReference" type="{http://services.apmoller.net/AMM/v4}String1000NonNullType" minOccurs="0"/&gt;
 *         &lt;element name="IsOriginalShipment" type="{http://services.apmoller.net/AMM/v4}BooleanType" minOccurs="0"/&gt;
 *         &lt;element name="Journey" type="{http://services.apmoller.net/AMM/v4}JourneyCustomGrpDirType" minOccurs="0"/&gt;
 *         &lt;element name="ShipmentPriceCalculationDttm" type="{http://services.apmoller.net/AMM/v4}DateTimeType" minOccurs="0"/&gt;
 *         &lt;element name="Shipment" type="{http://services.apmoller.net/AMM/v4}ShipmentCustomValReqType"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.NONE)
@XmlType(name = "ValdiateCustomReqType", propOrder = {
    "clientReference",
    "isOriginalShipment",
    "journey",
    "shipmentPriceCalculationDttm",
    "shipment"
})
public class ValdiateCustomReqType implements Serializable {

    @XmlElement(name = "ClientReference")
    protected String clientReference;
    @XmlElement(name = "IsOriginalShipment")
    @XmlSchemaType(name = "anySimpleType")
    protected String isOriginalShipment;
    @XmlElement(name = "Journey")
    protected JourneyCustomGrpDirType journey;
    @XmlElement(name = "ShipmentPriceCalculationDttm")
    @XmlSchemaType(name = "dateTime")
    protected XMLGregorianCalendar shipmentPriceCalculationDttm;
    @XmlElement(name = "Shipment", required = true)
    protected ShipmentCustomValReqType shipment;

    /**
     * Gets the value of the clientReference property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getClientReference() {
        return clientReference;
    }

    /**
     * Sets the value of the clientReference property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setClientReference(String value) {
        this.clientReference = value;
    }

    /**
     * Gets the value of the isOriginalShipment property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getIsOriginalShipment() {
        return isOriginalShipment;
    }

    /**
     * Sets the value of the isOriginalShipment property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setIsOriginalShipment(String value) {
        this.isOriginalShipment = value;
    }

    /**
     * Gets the value of the journey property.
     * 
     * @return
     *     possible object is
     *     {@link JourneyCustomGrpDirType }
     *     
     */
    public JourneyCustomGrpDirType getJourney() {
        return journey;
    }

    /**
     * Sets the value of the journey property.
     * 
     * @param value
     *     allowed object is
     *     {@link JourneyCustomGrpDirType }
     *     
     */
    public void setJourney(JourneyCustomGrpDirType value) {
        this.journey = value;
    }

    /**
     * Gets the value of the shipmentPriceCalculationDttm property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getShipmentPriceCalculationDttm() {
        return shipmentPriceCalculationDttm;
    }

    /**
     * Sets the value of the shipmentPriceCalculationDttm property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setShipmentPriceCalculationDttm(XMLGregorianCalendar value) {
        this.shipmentPriceCalculationDttm = value;
    }

    /**
     * Gets the value of the shipment property.
     * 
     * @return
     *     possible object is
     *     {@link ShipmentCustomValReqType }
     *     
     */
    public ShipmentCustomValReqType getShipment() {
        return shipment;
    }

    /**
     * Sets the value of the shipment property.
     * 
     * @param value
     *     allowed object is
     *     {@link ShipmentCustomValReqType }
     *     
     */
    public void setShipment(ShipmentCustomValReqType value) {
        this.shipment = value;
    }

}
