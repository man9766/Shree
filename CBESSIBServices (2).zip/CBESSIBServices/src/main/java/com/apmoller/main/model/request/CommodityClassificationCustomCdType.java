
package com.apmoller.main.model.request;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * A classification of goods or products.
 * 				This entity
 * 				encapsulates the superset of all possible commodity codes
 * 				from all of
 * 				the different Commodity Coding Systems - so for example
 * 				the set of
 * 				Harmonised (HS six-character, sometimes abbreviated to
 * 				HS6) commodity
 * 				codes and their corresponding names will sit
 * 				alongside (often
 * 				similar) sets of commodity codes from the likes of
 * 				TARIC and UNSPSC.
 * 
 * 				These classifications will also potentially occupy different tiers
 * 				in
 * 				their respective hierarchies, from top-level groups like "Live
 * 				Animals" (chapter "01" in the HS system) through middle-tier "Other
 * 				live animals" (chapter/heading "01.06" in the HS system) to
 * 				fine-granularity classifications such as "Birds of prey"
 * 				(chapter/heading/subheading "01.06.31" in the HS system).
 * 
 * 				Note that
 * 				there could well be several instances having the same
 * 				commodity
 * 				classification name "Live Animals", but each code would be
 * 				unique
 * 				within the Coding System which owns each instance, and it is
 * 				unlikely that they would have exactly the same Commodity
 * 				Classification Code (though that is theoretically possible, hence
 * 				the need for a global "Commodity Classification ID" to make each
 * 				instance globally unique).
 * 
 * 				Note also that - for any given code - the
 * 				Commodity Coding System to
 * 				which that code uniquely belongs is always
 * 				derivable, because every
 * 				code belongs to exactly one Commodity
 * 				Classification Tier, and every
 * 				Commodity Classification Tier belongs
 * 				to exactly one Commodity
 * 				Coding System.
 * 
 * 				Candidate attributes:
 * 				*
 * 				Commodity Classification ID (unique identifier for each instance of
 * 				this entity)
 * 				* Parent Commodity Classification ID
 * 				* Commodity Coding
 * 				System (the abbreviation for the Classification
 * 				System/Owner)
 * 				*
 * 				Commodity Classification Code (unique only within its own Commodity
 * 				Coding System)
 * 				* Commodity Classification Name
 * 
 * <p>Java class for CommodityClassificationCustomCdType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="CommodityClassificationCustomCdType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="CommodityClassificationCd" type="{http://services.apmoller.net/AMM/v4}String12NonNullType"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "CommodityClassificationCustomCdType", propOrder = {
    "commodityClassificationCd"
})
public class CommodityClassificationCustomCdType {

    @XmlElement(name = "CommodityClassificationCd", required = true)
    protected String commodityClassificationCd;

    /**
     * Gets the value of the commodityClassificationCd property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCommodityClassificationCd() {
        return commodityClassificationCd;
    }

    /**
     * Sets the value of the commodityClassificationCd property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCommodityClassificationCd(String value) {
        this.commodityClassificationCd = value;
    }

}
