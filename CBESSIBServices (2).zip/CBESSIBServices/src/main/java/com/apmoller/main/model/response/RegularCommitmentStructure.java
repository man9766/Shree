
package com.apmoller.main.model.response;

import java.math.BigDecimal;
import java.math.BigInteger;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for RegularCommitmentStructure complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="RegularCommitmentStructure"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="CommitmentWeek" type="{http://services.apmoller.net/AMM/v4}Integer2Type"/&gt;
 *         &lt;element name="CommitmentYear" type="{http://services.apmoller.net/AMM/v4}Integer4Type"/&gt;
 *         &lt;element name="FFE" type="{http://services.apmoller.net/AMM/v4}Decimal9d4WithNegativeType"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "RegularCommitmentStructure", propOrder = {
    "commitmentWeek",
    "commitmentYear",
    "ffe"
})
public class RegularCommitmentStructure {

    @XmlElement(name = "CommitmentWeek", required = true)
    protected BigInteger commitmentWeek;
    @XmlElement(name = "CommitmentYear", required = true)
    protected BigInteger commitmentYear;
    @XmlElement(name = "FFE", required = true)
    protected BigDecimal ffe;

    /**
     * Gets the value of the commitmentWeek property.
     * 
     * @return
     *     possible object is
     *     {@link BigInteger }
     *     
     */
    public BigInteger getCommitmentWeek() {
        return commitmentWeek;
    }

    /**
     * Sets the value of the commitmentWeek property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigInteger }
     *     
     */
    public void setCommitmentWeek(BigInteger value) {
        this.commitmentWeek = value;
    }

    /**
     * Gets the value of the commitmentYear property.
     * 
     * @return
     *     possible object is
     *     {@link BigInteger }
     *     
     */
    public BigInteger getCommitmentYear() {
        return commitmentYear;
    }

    /**
     * Sets the value of the commitmentYear property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigInteger }
     *     
     */
    public void setCommitmentYear(BigInteger value) {
        this.commitmentYear = value;
    }

    /**
     * Gets the value of the ffe property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getFFE() {
        return ffe;
    }

    /**
     * Sets the value of the ffe property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setFFE(BigDecimal value) {
        this.ffe = value;
    }

}
