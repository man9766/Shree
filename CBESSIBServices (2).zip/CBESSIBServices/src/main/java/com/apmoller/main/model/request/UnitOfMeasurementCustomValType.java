
package com.apmoller.main.model.request;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * The metric by which a Measured Property is
 * 				measured. Example instances are:
 * 
 * 				Second / Hour / Day / Year,
 * 				Micron /
 * 				Centimetre / Metre / Kilometer / Nautical Mile,
 * 				Inch / Foot / Yard /
 * 				Fathom / Mile / Nautical Mile,
 * 				Litre,
 * 				US Gallon,
 * 				Gram / Kilogram /
 * 				Tonne,
 * 				Pound / Ton,
 * 				Knot,
 * 				Kilometres Per Hour,
 * 				Degrees Celcius,
 * 				Centipoise,
 * 				Voltage,
 * 				Ampere,
 * 				TEU,
 * 				FFE,
 * 				......
 * 
 * <p>Java class for UnitOfMeasurementCustomValType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="UnitOfMeasurementCustomValType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="UnitOfMeasurementAbbreviationVal" type="{http://services.apmoller.net/AMM/v4}String50Type"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "UnitOfMeasurementCustomValType", propOrder = {
    "unitOfMeasurementAbbreviationVal"
})
public class UnitOfMeasurementCustomValType {

    @XmlElement(name = "UnitOfMeasurementAbbreviationVal", required = true)
    protected String unitOfMeasurementAbbreviationVal;

    /**
     * Gets the value of the unitOfMeasurementAbbreviationVal property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUnitOfMeasurementAbbreviationVal() {
        return unitOfMeasurementAbbreviationVal;
    }

    /**
     * Sets the value of the unitOfMeasurementAbbreviationVal property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUnitOfMeasurementAbbreviationVal(String value) {
        this.unitOfMeasurementAbbreviationVal = value;
    }

}
