
package com.apmoller.main.model.request;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * A Dated Voyage groups together the sequence of all
 * 				of the visited Dated Site Calls.
 * 
 * <p>Java class for DatedVoyageStructure complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="DatedVoyageStructure"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="Vessel" type="{http://services.apmoller.net/AMM/v4}VesselStructure" minOccurs="0"/&gt;
 *         &lt;element name="VoyageCd" type="{http://services.apmoller.net/AMM/v4}String6NonNullType" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "DatedVoyageStructure", propOrder = {
    "vessel",
    "voyageCd"
})
public class DatedVoyageStructure {

    @XmlElement(name = "Vessel")
    protected VesselStructure vessel;
    @XmlElement(name = "VoyageCd")
    protected String voyageCd;

    /**
     * Gets the value of the vessel property.
     * 
     * @return
     *     possible object is
     *     {@link VesselStructure }
     *     
     */
    public VesselStructure getVessel() {
        return vessel;
    }

    /**
     * Sets the value of the vessel property.
     * 
     * @param value
     *     allowed object is
     *     {@link VesselStructure }
     *     
     */
    public void setVessel(VesselStructure value) {
        this.vessel = value;
    }

    /**
     * Gets the value of the voyageCd property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getVoyageCd() {
        return voyageCd;
    }

    /**
     * Sets the value of the voyageCd property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setVoyageCd(String value) {
        this.voyageCd = value;
    }

}
