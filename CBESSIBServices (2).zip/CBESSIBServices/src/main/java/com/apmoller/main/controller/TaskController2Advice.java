package com.apmoller.main.controller;

import java.util.Locale;

import javax.ws.rs.Produces;
import javax.xml.bind.annotation.XmlRootElement;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.context.i18n.LocaleContextHolder;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

import com.apmoller.main.model.ValidationError;



@ControllerAdvice(assignableTypes = CBEController.class)
//@XmlRootElement
//@Produces(MediaType.APPLICATION_XML_VALUE)
public class TaskController2Advice extends ResponseEntityExceptionHandler {


	
	
    @Override
   // @ResponseBody
    //@Produces(MediaType.APPLICATION_XML_VALUE)
    protected ResponseEntity<Object> handleMethodArgumentNotValid(MethodArgumentNotValidException exception, HttpHeaders headers, HttpStatus status, WebRequest request) {
        ValidationError error = ValidationErrorBuilder.fromBindingErrors(exception.getBindingResult());
        return super.handleExceptionInternal(exception, error, headers, status, request);
    }
   
    
	
	/* @Autowired
	  private MessageSource msgSource;

	  @ExceptionHandler(MethodArgumentNotValidException.class)
	  @ResponseStatus(org.springframework.http.HttpStatus.BAD_REQUEST)
	  @ResponseBody
	  public Message processValidationError(MethodArgumentNotValidException ex) {
	    BindingResult result = ex.getBindingResult();
	    FieldError error = result.getFieldError();

	    return processFieldError(error);
	  }

	  private Message processFieldError(FieldError error) {
	    Message message = null;
	    if (error != null) {
	      Locale currentLocale = LocaleContextHolder.getLocale();
	      String msg = msgSource.getMessage(error.getDefaultMessage(), null, currentLocale);
	      message = new Message(MessageType.ERROR, msg);
	    }
	    return message;
	  }*/
   
}
