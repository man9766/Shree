
package com.apmoller.main.model.response;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * A Dated Voyage groups together the sequence of all
 * 				of the visited Dated Site Calls.
 * 
 * <p>Java class for DatedVoyageCustomType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="DatedVoyageCustomType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="Vessel" type="{http://services.apmoller.net/AMM/v4}VesselCustomCodeType" minOccurs="0"/&gt;
 *         &lt;element name="VoyageCd" type="{http://services.apmoller.net/AMM/v4}String6NonNullType" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "DatedVoyageCustomType", propOrder = {
    "vessel",
    "voyageCd"
})
public class DatedVoyageCustomType {

    @XmlElement(name = "Vessel")
    protected VesselCustomCodeType vessel;
    @XmlElement(name = "VoyageCd")
    protected String voyageCd;

    /**
     * Gets the value of the vessel property.
     * 
     * @return
     *     possible object is
     *     {@link VesselCustomCodeType }
     *     
     */
    public VesselCustomCodeType getVessel() {
        return vessel;
    }

    /**
     * Sets the value of the vessel property.
     * 
     * @param value
     *     allowed object is
     *     {@link VesselCustomCodeType }
     *     
     */
    public void setVessel(VesselCustomCodeType value) {
        this.vessel = value;
    }

    /**
     * Gets the value of the voyageCd property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getVoyageCd() {
        return voyageCd;
    }

    /**
     * Sets the value of the voyageCd property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setVoyageCd(String value) {
        this.voyageCd = value;
    }

}
