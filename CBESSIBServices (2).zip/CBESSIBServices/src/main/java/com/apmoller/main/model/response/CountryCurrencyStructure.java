
package com.apmoller.main.model.response;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * Maps the country to the currency. In certain cases
 * 				a country can be associated with multiple currencies, e.g. going
 * 				from one currency to another the old currency needs to be associated
 * 				with the country for a certain time period. The Country Currency
 * 				should have validity dates.
 * 
 * <p>Java class for CountryCurrencyStructure complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="CountryCurrencyStructure"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="CurrencyUnit" type="{http://services.apmoller.net/AMM/v4}CurrencyUnitCustomCdType"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "CountryCurrencyStructure", propOrder = {
    "currencyUnit"
})
public class CountryCurrencyStructure {

    @XmlElement(name = "CurrencyUnit", required = true)
    protected CurrencyUnitCustomCdType currencyUnit;

    /**
     * Gets the value of the currencyUnit property.
     * 
     * @return
     *     possible object is
     *     {@link CurrencyUnitCustomCdType }
     *     
     */
    public CurrencyUnitCustomCdType getCurrencyUnit() {
        return currencyUnit;
    }

    /**
     * Sets the value of the currencyUnit property.
     * 
     * @param value
     *     allowed object is
     *     {@link CurrencyUnitCustomCdType }
     *     
     */
    public void setCurrencyUnit(CurrencyUnitCustomCdType value) {
        this.currencyUnit = value;
    }

}
