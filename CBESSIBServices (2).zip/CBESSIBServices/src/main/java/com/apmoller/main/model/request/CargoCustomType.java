
package com.apmoller.main.model.request;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;


/**
 * A grouping / unit of cargo of a particular
 * 				Commodity that forms part of a Shipment, and which can also be
 * 				mentioned by a Transport Document.
 * 				An instance of the Cargo entity
 * 				type is often referred to as a Cargo
 * 				Line
 * 
 * 				This entity type forms a key
 * 				linkage between Shipment and Transport
 * 				Document.
 * 
 * 
 * <p>Java class for CargoCustomType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="CargoCustomType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="IsReefer" type="{http://services.apmoller.net/AMM/v4}BooleanType"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "CargoCustomType", propOrder = {
    "isReefer"
})
public class CargoCustomType {

    @XmlElement(name = "IsReefer", required = true)
    @XmlSchemaType(name = "anySimpleType")
    protected String isReefer;

    /**
     * Gets the value of the isReefer property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getIsReefer() {
        return isReefer;
    }

    /**
     * Sets the value of the isReefer property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setIsReefer(String value) {
        this.isReefer = value;
    }

}
