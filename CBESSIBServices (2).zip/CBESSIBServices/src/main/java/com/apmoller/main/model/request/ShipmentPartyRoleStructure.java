
package com.apmoller.main.model.request;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * A role taken by a Party in relation to a Shipment.
 * 
 * 				A Shipment Party Role has a Type. Examples include:
 * 				- Booked By Party
 * 				- Contractual Customer
 * 				- Shipper
 * 				- Consignee
 * 				- First Notify Party
 * 				-
 * 				Additional Notify Party
 * 
 * <p>Java class for ShipmentPartyRoleStructure complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ShipmentPartyRoleStructure"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="PartyRole" type="{http://services.apmoller.net/AMM/v4}PartyRoleStructure" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ShipmentPartyRoleStructure", propOrder = {
    "partyRole"
})
public class ShipmentPartyRoleStructure {

    @XmlElement(name = "PartyRole")
    protected PartyRoleStructure partyRole;

    /**
     * Gets the value of the partyRole property.
     * 
     * @return
     *     possible object is
     *     {@link PartyRoleStructure }
     *     
     */
    public PartyRoleStructure getPartyRole() {
        return partyRole;
    }

    /**
     * Sets the value of the partyRole property.
     * 
     * @param value
     *     allowed object is
     *     {@link PartyRoleStructure }
     *     
     */
    public void setPartyRole(PartyRoleStructure value) {
        this.partyRole = value;
    }

}
