package com.apmoller.main.controller;

import static org.mockito.Matchers.any;

import java.util.ArrayList;
import java.util.List;

import javax.validation.Valid;
import javax.ws.rs.Produces;

import org.hibernate.validator.constraints.NotEmpty;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.client.discovery.DiscoveryClient;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.apmoller.main.exception.BusinessServiceLayerException;
import com.apmoller.main.model.Employee;
import com.apmoller.main.model.PopulateShipmentOnYieldResponseType;
import com.apmoller.main.model.RequestData;
import com.apmoller.main.model.RequestDataSample;
import com.apmoller.main.model.ResponseData;
import com.apmoller.main.model.Task;
import com.apmoller.main.model.ValidationError;
import com.apmoller.main.model.request.ValidateShipmentOnYieldRequestType;
import com.apmoller.main.model.response.ValidateShipmentOnYieldResponseType;
import com.apmoller.main.service.CbeProcessInputDataService;


@RestController
public class CBEController {

	private static final Logger logger = LoggerFactory
			.getLogger(CBEController.class);


   /* @Autowired
	private RequestValidation requestValidation;*/
	
	@Autowired
	private CbeProcessInputDataService cbeProcessInputDataService;
	
	 /* @Autowired
	    private DiscoveryClient discoveryClient;*/

		
	@RequestMapping(value = "/processrequest", method = RequestMethod.POST)
	public ResponseData processInputData(@RequestBody RequestData requestData) throws BusinessServiceLayerException {

		ResponseData responseData;
		logger.info("####Inside process input method###::: Method Type = POST###########");
		logger.info("######Incoming Input Request Data:::::" + requestData);

		       
		responseData = cbeProcessInputDataService.processInputData(requestData);
		
		logger.info("####Exiting  process input method###::: Method Type = POST###########");
		logger.info("####Response Data sending to client##:::" + responseData);
		
		return responseData;

	}
	
	@RequestMapping(value = "/processXMLrequest", method = RequestMethod.POST, 
			consumes =MediaType.APPLICATION_XML_VALUE,
            produces=MediaType.APPLICATION_XML_VALUE)
	public  ValidateShipmentOnYieldResponseType processInputDataForXmlRequest(  @RequestBody ValidateShipmentOnYieldRequestType requestData) throws BusinessServiceLayerException {
		PopulateShipmentOnYieldResponseType populateShipmentOnYieldResponseType = new PopulateShipmentOnYieldResponseType();
		ValidateShipmentOnYieldResponseType validateShipmentOnYieldResponseType = new ValidateShipmentOnYieldResponseType();
		System.out.println("$$$$$$$$$$$$$$$$$$$$INDISE METHOD$$$$$$$$$");
		ResponseData responseData =  new ResponseData();
		logger.info("####Inside process input method###::: Method Type = POST###########");
		logger.info("######Incoming Input Request Data:::::" + requestData);
		System.out.println(requestData.getShipmentRequest().get(0).getClientReference());
		       
		//responseData = cbeProcessInputDataService.processInputData(requestData);
		
		logger.info("####Exiting  process input method###::: Method Type = POST###########");
		logger.info("####Response Data sending to client##:::" + responseData);
		
		validateShipmentOnYieldResponseType= populateShipmentOnYieldResponseType.populateResponse(requestData);
		
		return validateShipmentOnYieldResponseType;

	}
	
	@RequestMapping(value = "/processJSONrequest", method = RequestMethod.POST, 
			consumes =MediaType.APPLICATION_JSON_VALUE,
            produces=MediaType.APPLICATION_JSON_VALUE)
	public  ValidateShipmentOnYieldResponseType processInputDataForJSONRequest(@Valid @RequestBody ValidateShipmentOnYieldRequestType requestData) throws BusinessServiceLayerException {
		PopulateShipmentOnYieldResponseType populateShipmentOnYieldResponseType = new PopulateShipmentOnYieldResponseType();
		ValidateShipmentOnYieldResponseType validateShipmentOnYieldResponseType = new ValidateShipmentOnYieldResponseType();
		System.out.println("$$$$$$$$$$$$$$$$$$$$INDISE METHOD$$$$$$$$$");
		ResponseData responseData =  new ResponseData();
		logger.info("####Inside process input method###::: Method Type = POST###########");
		logger.info("######Incoming Input Request Data:::::" + requestData);

		       
		//responseData = cbeProcessInputDataService.processInputData(requestData);
		
		logger.info("####Exiting  process input method###::: Method Type = POST###########");
		logger.info("####Response Data sending to client##:::" + responseData);
		
		validateShipmentOnYieldResponseType= populateShipmentOnYieldResponseType.populateResponse(requestData);
		
		return validateShipmentOnYieldResponseType;

	}
	
	
	@RequestMapping(value = "/processrequest", method = RequestMethod.GET)
	public List<RequestData> processInputDatarequest(String  operator) {

		List<RequestData> requestData =  new ArrayList<RequestData>();
		List<RequestData> requestData1 =  null;
		logger.info("Inside process processInputDatarequest method");
		logger.info("Request::" + operator);

		requestData = cbeProcessInputDataService.processInputDataRequest(operator);
		/*if(requestData1 == null) throw new */
		logger.info("Response Data is" + requestData);
		return requestData;

	}
	
	@RequestMapping(value= "/save/", method = RequestMethod.POST)
	@ResponseBody
	public Employee save(@RequestBody final Employee employee){
		//call the service save method		
		employee.setId("e1");
		return employee;
	}
	
	@RequestMapping(value = "/task", method = RequestMethod.POST)
    public Task createTask(@Valid @RequestBody Task task) {
		System.out.println("Inside");
        return task;
    }

   /* @ExceptionHandler
    @ResponseStatus(value = HttpStatus.BAD_REQUEST)
    public ValidationError handleException(MethodArgumentNotValidException exception) {
        return createValidationError(exception);
    }

    private ValidationError createValidationError(MethodArgumentNotValidException e) {
        return ValidationErrorBuilder.fromBindingErrors(e.getBindingResult());
    }*/
}



