
package com.apmoller.main.model.response;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * A route between Geographical Areas or Sites that
 * 				is relevant in the context of a Shipment.
 * 
 * 				A Shipment Route describes
 * 				a through journey (of cargo and/or
 * 				equipment) through a series of
 * 				Shipment Route Points, from Place Of
 * 				Receipt (first Shipment Route
 * 				Point) to Place Of Delivery (last
 * 				Shipment Route Point). Some
 * 				Pre-carriage / On-carriage information
 * 				(ie regarding aspects of the
 * 				route that are outside the scope of the
 * 				Customer's contract with the
 * 				Enterprise) can be recorded in the
 * 				associated Shipment Route Link
 * 				entity type..
 * 
 * 				Various Product Properties of different Types can be
 * 				associated with a
 * 				Shipment Route. Example Product Property Types
 * 				include:
 * 
 * 				- Named Account Product (NAP)
 * 				- Name Account Customer Id
 * 				-
 * 				Vessel Flag 
 * 
 * 
 * <p>Java class for ShipmentRouteCustomSteeredLegType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ShipmentRouteCustomSteeredLegType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="ShipmentRouteLink" type="{http://services.apmoller.net/AMM/v4}ShipmentRouteLinkCustomSteeredLegType" minOccurs="0"/&gt;
 *         &lt;element name="ShipmentRouteRole" type="{http://services.apmoller.net/AMM/v4}ShipmentRouteRoleStructure"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ShipmentRouteCustomSteeredLegType", propOrder = {
    "shipmentRouteLink",
    "shipmentRouteRole"
})
public class ShipmentRouteCustomSteeredLegType {

    @XmlElement(name = "ShipmentRouteLink")
    protected ShipmentRouteLinkCustomSteeredLegType shipmentRouteLink;
    @XmlElement(name = "ShipmentRouteRole", required = true)
    protected ShipmentRouteRoleStructure shipmentRouteRole;

    /**
     * Gets the value of the shipmentRouteLink property.
     * 
     * @return
     *     possible object is
     *     {@link ShipmentRouteLinkCustomSteeredLegType }
     *     
     */
    public ShipmentRouteLinkCustomSteeredLegType getShipmentRouteLink() {
        return shipmentRouteLink;
    }

    /**
     * Sets the value of the shipmentRouteLink property.
     * 
     * @param value
     *     allowed object is
     *     {@link ShipmentRouteLinkCustomSteeredLegType }
     *     
     */
    public void setShipmentRouteLink(ShipmentRouteLinkCustomSteeredLegType value) {
        this.shipmentRouteLink = value;
    }

    /**
     * Gets the value of the shipmentRouteRole property.
     * 
     * @return
     *     possible object is
     *     {@link ShipmentRouteRoleStructure }
     *     
     */
    public ShipmentRouteRoleStructure getShipmentRouteRole() {
        return shipmentRouteRole;
    }

    /**
     * Sets the value of the shipmentRouteRole property.
     * 
     * @param value
     *     allowed object is
     *     {@link ShipmentRouteRoleStructure }
     *     
     */
    public void setShipmentRouteRole(ShipmentRouteRoleStructure value) {
        this.shipmentRouteRole = value;
    }

}
