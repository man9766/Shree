
package com.apmoller.main.model.request;

import java.math.BigDecimal;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * A grouping of related Price Elements associated
 * 				with a Shipment.
 * 
 * 				A Shipment Price can also be associated with a Cargo
 * 				Line, and.or
 * 				cargo in a container.
 * 				If the Shipment Price is associated
 * 				only with the Shipment, then the
 * 				price relates to the Shipment as a
 * 				whole, or to an associated
 * 				Transport Document.
 * 
 * 
 * <p>Java class for ShipmentPriceCustomType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ShipmentPriceCustomType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="ProratePct" type="{http://services.apmoller.net/AMM/v4}Decimal9d4Type" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ShipmentPriceCustomType", propOrder = {
    "proratePct"
})
public class ShipmentPriceCustomType {

    @XmlElement(name = "ProratePct")
    protected BigDecimal proratePct;

    /**
     * Gets the value of the proratePct property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getProratePct() {
        return proratePct;
    }

    /**
     * Sets the value of the proratePct property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setProratePct(BigDecimal value) {
        this.proratePct = value;
    }

}
