
package com.apmoller.main.model.request;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * A group of properties of a category of Container.
 * 				Attributes of the group include:
 * 				- Container size
 * 				- Equipment SubType
 * 				- Reefer Sub-Type
 * 				- CSC Approval Number for the profile design
 * 			
 * 
 * <p>Java class for ContainerProfileStructure complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ContainerProfileStructure"&gt;
 *   &lt;complexContent&gt;
 *     &lt;extension base="{http://services.apmoller.net/AMM/v4}EquipmentProfileCustomEmptyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="ContainerSize" type="{http://services.apmoller.net/AMM/v4}ContainerSizeStructure"/&gt;
 *         &lt;element name="ContainerType" type="{http://services.apmoller.net/AMM/v4}ContainerTypeStructure"/&gt;
 *         &lt;element name="ISOContainerSizeType" type="{http://services.apmoller.net/AMM/v4}ISOContainerSizeTypeStructure" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/extension&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ContainerProfileStructure", propOrder = {
    "containerSize",
    "containerType",
    "isoContainerSizeType"
})
public class ContainerProfileStructure
    extends EquipmentProfileCustomEmptyType
{

    @XmlElement(name = "ContainerSize", required = true)
    protected ContainerSizeStructure containerSize;
    @XmlElement(name = "ContainerType", required = true)
    protected ContainerTypeStructure containerType;
    @XmlElement(name = "ISOContainerSizeType")
    protected ISOContainerSizeTypeStructure isoContainerSizeType;

    /**
     * Gets the value of the containerSize property.
     * 
     * @return
     *     possible object is
     *     {@link ContainerSizeStructure }
     *     
     */
    public ContainerSizeStructure getContainerSize() {
        return containerSize;
    }

    /**
     * Sets the value of the containerSize property.
     * 
     * @param value
     *     allowed object is
     *     {@link ContainerSizeStructure }
     *     
     */
    public void setContainerSize(ContainerSizeStructure value) {
        this.containerSize = value;
    }

    /**
     * Gets the value of the containerType property.
     * 
     * @return
     *     possible object is
     *     {@link ContainerTypeStructure }
     *     
     */
    public ContainerTypeStructure getContainerType() {
        return containerType;
    }

    /**
     * Sets the value of the containerType property.
     * 
     * @param value
     *     allowed object is
     *     {@link ContainerTypeStructure }
     *     
     */
    public void setContainerType(ContainerTypeStructure value) {
        this.containerType = value;
    }

    /**
     * Gets the value of the isoContainerSizeType property.
     * 
     * @return
     *     possible object is
     *     {@link ISOContainerSizeTypeStructure }
     *     
     */
    public ISOContainerSizeTypeStructure getISOContainerSizeType() {
        return isoContainerSizeType;
    }

    /**
     * Sets the value of the isoContainerSizeType property.
     * 
     * @param value
     *     allowed object is
     *     {@link ISOContainerSizeTypeStructure }
     *     
     */
    public void setISOContainerSizeType(ISOContainerSizeTypeStructure value) {
        this.isoContainerSizeType = value;
    }

}
