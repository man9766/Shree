
package com.apmoller.main.model.response;

import java.math.BigDecimal;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * A Bucket against which a Booking for a Shipment
 * 				was (wholly or partly) accepted
 * 
 * <p>Java class for BucketCustomType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="BucketCustomType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="BucketCYLimit" type="{http://services.apmoller.net/AMM/v4}Decimal18d4WithNegativeType" minOccurs="0"/&gt;
 *         &lt;element name="BucketColourCode" type="{http://services.apmoller.net/AMM/v4}String50NonNullType"/&gt;
 *         &lt;element name="CurrencyUnit" type="{http://services.apmoller.net/AMM/v4}CurrencyUnitCustomCdType" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "BucketCustomType", propOrder = {
    "bucketCYLimit",
    "bucketColourCode",
    "currencyUnit"
})
public class BucketCustomType {

    @XmlElement(name = "BucketCYLimit")
    protected BigDecimal bucketCYLimit;
    @XmlElement(name = "BucketColourCode", required = true)
    protected String bucketColourCode;
    @XmlElement(name = "CurrencyUnit")
    protected CurrencyUnitCustomCdType currencyUnit;

    /**
     * Gets the value of the bucketCYLimit property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getBucketCYLimit() {
        return bucketCYLimit;
    }

    /**
     * Sets the value of the bucketCYLimit property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setBucketCYLimit(BigDecimal value) {
        this.bucketCYLimit = value;
    }

    /**
     * Gets the value of the bucketColourCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBucketColourCode() {
        return bucketColourCode;
    }

    /**
     * Sets the value of the bucketColourCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBucketColourCode(String value) {
        this.bucketColourCode = value;
    }

    /**
     * Gets the value of the currencyUnit property.
     * 
     * @return
     *     possible object is
     *     {@link CurrencyUnitCustomCdType }
     *     
     */
    public CurrencyUnitCustomCdType getCurrencyUnit() {
        return currencyUnit;
    }

    /**
     * Sets the value of the currencyUnit property.
     * 
     * @param value
     *     allowed object is
     *     {@link CurrencyUnitCustomCdType }
     *     
     */
    public void setCurrencyUnit(CurrencyUnitCustomCdType value) {
        this.currencyUnit = value;
    }

}
