package com.apmoller.main.model;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;

import com.apmoller.main.model.request.ValidateShipmentOnYieldRequestType;
import com.apmoller.main.model.response.AdditionalRequestParamListType;
import com.apmoller.main.model.response.CommitmentCustomValType;
import com.apmoller.main.model.response.ShipmentCustomValResType;
import com.apmoller.main.model.response.ValidateShipmentOnYieldResponseType;
import com.apmoller.main.model.response.ValidationDetailsType;



public class PopulateShipmentOnYieldResponseType {
	
	public ValidateShipmentOnYieldResponseType populateResponse(ValidateShipmentOnYieldRequestType validateShipmentOnYieldRequestType)
	{
		ValidateShipmentOnYieldResponseType validateShipmentOnYieldResponseType = new ValidateShipmentOnYieldResponseType();
		AdditionalRequestParamListType additionalRequestParamListType = new  AdditionalRequestParamListType(); 	
		ShipmentCustomValResType shipmentCustomValResType = new ShipmentCustomValResType();
		List<ValidationDetailsType> validationDetailsTypeList =  new ArrayList<ValidationDetailsType>();
		validationDetailsTypeList.add(populateValidationDetails());
		
		validateShipmentOnYieldResponseType.setClientReference("CR");
		validateShipmentOnYieldResponseType.setCommitmentWeek(new BigInteger("12222"));
		validateShipmentOnYieldResponseType.setLargeBookingLimitFFE("LBLF");
		validateShipmentOnYieldResponseType.setMessage("MESSAGE");
		validateShipmentOnYieldResponseType.setRequestParameterList(additionalRequestParamListType);
		validateShipmentOnYieldResponseType.setShipment(shipmentCustomValResType);
		validateShipmentOnYieldResponseType.setShipmentUptakeAcceptanceCode("SUAC");
		validateShipmentOnYieldResponseType.setShipmentUptakeAcceptanceDescription("SUDESC");
		validateShipmentOnYieldResponseType.setShipmentValidationOutcomeCode("VOC");
		validateShipmentOnYieldResponseType.setShipmentValidationOutcomeDescription("VOD");
		validateShipmentOnYieldResponseType.setStatusCode("0000");
		validateShipmentOnYieldResponseType.setSteeredLegMessage("SLM");
		validateShipmentOnYieldResponseType.setSteeredLegStatusCode("SLSC");
		validateShipmentOnYieldResponseType.setUptakeManagerCondition("UMC");
		validateShipmentOnYieldResponseType.setValidationWarnings("VW");
		validateShipmentOnYieldResponseType.setValidationDetails(validationDetailsTypeList);
		
		return validateShipmentOnYieldResponseType;
		
	}
	
	public ValidationDetailsType populateValidationDetails()
	{
		CommitmentCustomValType commitmentCustomValType = new CommitmentCustomValType();
		ValidationDetailsType validationDetailstype = new ValidationDetailsType();
		validationDetailstype.setCommitment(commitmentCustomValType);
		validationDetailstype.setCommitmentStatus("CS");
		validationDetailstype.setCommitmentUptakeAcceptanceCode("CUAC");
		validationDetailstype.setCommitmentUptakeAcceptanceDescription("CUAD");
		validationDetailstype.setCommitmentValidationOutcomeCode("CVOC");
		validationDetailstype.setCommitmentValidationOutcomeDescription("CVOD");
		validationDetailstype.setTotalFFEConsumed(new BigDecimal("12345"));
		validationDetailstype.setTotalFFENotConsumed(new BigDecimal("12345"));
		
		return validationDetailstype;
		
	}
}

