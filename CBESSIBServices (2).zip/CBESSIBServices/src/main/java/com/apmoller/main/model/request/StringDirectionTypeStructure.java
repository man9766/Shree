
package com.apmoller.main.model.request;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for StringDirectionTypeStructure complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="StringDirectionTypeStructure"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="StringDirectionTypeCd" type="{http://services.apmoller.net/AMM/v4}String50NonNullType" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "StringDirectionTypeStructure", propOrder = {
    "stringDirectionTypeCd"
})
public class StringDirectionTypeStructure {

    @XmlElement(name = "StringDirectionTypeCd")
    protected String stringDirectionTypeCd;

    /**
     * Gets the value of the stringDirectionTypeCd property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getStringDirectionTypeCd() {
        return stringDirectionTypeCd;
    }

    /**
     * Sets the value of the stringDirectionTypeCd property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setStringDirectionTypeCd(String value) {
        this.stringDirectionTypeCd = value;
    }

}
