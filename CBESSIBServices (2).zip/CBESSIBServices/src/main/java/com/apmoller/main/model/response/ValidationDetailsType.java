
package com.apmoller.main.model.response;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * Custom complex element created for Cargo Type and
 * 				Container Size 
 * 
 * <p>Java class for ValidationDetailsType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ValidationDetailsType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="Commitment" type="{http://services.apmoller.net/AMM/v4}CommitmentCustomValType" minOccurs="0"/&gt;
 *         &lt;element name="CommitmentStatus" type="{http://services.apmoller.net/AMM/v4}String20NonNullType"/&gt;
 *         &lt;element name="ValidationPerEquipment" type="{http://services.apmoller.net/AMM/v4}ValidationEquipmentType" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="TotalFFEConsumed" type="{http://services.apmoller.net/AMM/v4}Decimal9d4Type"/&gt;
 *         &lt;element name="TotalFFENotConsumed" type="{http://services.apmoller.net/AMM/v4}Decimal9d4Type"/&gt;
 *         &lt;element name="CommitmentUptakeAcceptanceCode" type="{http://services.apmoller.net/AMM/v4}String3NonNullType" minOccurs="0"/&gt;
 *         &lt;element name="CommitmentUptakeAcceptanceDescription" type="{http://services.apmoller.net/AMM/v4}String50NonNullType" minOccurs="0"/&gt;
 *         &lt;element name="CommitmentValidationOutcomeCode" type="{http://services.apmoller.net/AMM/v4}String50NonNullType" minOccurs="0"/&gt;
 *         &lt;element name="CommitmentValidationOutcomeDescription" type="{http://services.apmoller.net/AMM/v4}String50NonNullType" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ValidationDetailsType", propOrder = {
    "commitment",
    "commitmentStatus",
    "validationPerEquipment",
    "totalFFEConsumed",
    "totalFFENotConsumed",
    "commitmentUptakeAcceptanceCode",
    "commitmentUptakeAcceptanceDescription",
    "commitmentValidationOutcomeCode",
    "commitmentValidationOutcomeDescription"
})
public class ValidationDetailsType {

    @XmlElement(name = "Commitment")
    protected CommitmentCustomValType commitment;
    @XmlElement(name = "CommitmentStatus", required = true)
    protected String commitmentStatus;
    @XmlElement(name = "ValidationPerEquipment")
    protected List<ValidationEquipmentType> validationPerEquipment;
    @XmlElement(name = "TotalFFEConsumed", required = true)
    protected BigDecimal totalFFEConsumed;
    @XmlElement(name = "TotalFFENotConsumed", required = true)
    protected BigDecimal totalFFENotConsumed;
    @XmlElement(name = "CommitmentUptakeAcceptanceCode")
    protected String commitmentUptakeAcceptanceCode;
    @XmlElement(name = "CommitmentUptakeAcceptanceDescription")
    protected String commitmentUptakeAcceptanceDescription;
    @XmlElement(name = "CommitmentValidationOutcomeCode")
    protected String commitmentValidationOutcomeCode;
    @XmlElement(name = "CommitmentValidationOutcomeDescription")
    protected String commitmentValidationOutcomeDescription;

    /**
     * Gets the value of the commitment property.
     * 
     * @return
     *     possible object is
     *     {@link CommitmentCustomValType }
     *     
     */
    public CommitmentCustomValType getCommitment() {
        return commitment;
    }

    /**
     * Sets the value of the commitment property.
     * 
     * @param value
     *     allowed object is
     *     {@link CommitmentCustomValType }
     *     
     */
    public void setCommitment(CommitmentCustomValType value) {
        this.commitment = value;
    }

    /**
     * Gets the value of the commitmentStatus property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCommitmentStatus() {
        return commitmentStatus;
    }

    /**
     * Sets the value of the commitmentStatus property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCommitmentStatus(String value) {
        this.commitmentStatus = value;
    }

    /**
     * Gets the value of the validationPerEquipment property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the validationPerEquipment property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getValidationPerEquipment().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link ValidationEquipmentType }
     * 
     * 
     */
    public List<ValidationEquipmentType> getValidationPerEquipment() {
        if (validationPerEquipment == null) {
            validationPerEquipment = new ArrayList<ValidationEquipmentType>();
        }
        return this.validationPerEquipment;
    }

    /**
     * Gets the value of the totalFFEConsumed property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getTotalFFEConsumed() {
        return totalFFEConsumed;
    }

    /**
     * Sets the value of the totalFFEConsumed property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setTotalFFEConsumed(BigDecimal value) {
        this.totalFFEConsumed = value;
    }

    /**
     * Gets the value of the totalFFENotConsumed property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getTotalFFENotConsumed() {
        return totalFFENotConsumed;
    }

    /**
     * Sets the value of the totalFFENotConsumed property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setTotalFFENotConsumed(BigDecimal value) {
        this.totalFFENotConsumed = value;
    }

    /**
     * Gets the value of the commitmentUptakeAcceptanceCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCommitmentUptakeAcceptanceCode() {
        return commitmentUptakeAcceptanceCode;
    }

    /**
     * Sets the value of the commitmentUptakeAcceptanceCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCommitmentUptakeAcceptanceCode(String value) {
        this.commitmentUptakeAcceptanceCode = value;
    }

    /**
     * Gets the value of the commitmentUptakeAcceptanceDescription property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCommitmentUptakeAcceptanceDescription() {
        return commitmentUptakeAcceptanceDescription;
    }

    /**
     * Sets the value of the commitmentUptakeAcceptanceDescription property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCommitmentUptakeAcceptanceDescription(String value) {
        this.commitmentUptakeAcceptanceDescription = value;
    }

    /**
     * Gets the value of the commitmentValidationOutcomeCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCommitmentValidationOutcomeCode() {
        return commitmentValidationOutcomeCode;
    }

    /**
     * Sets the value of the commitmentValidationOutcomeCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCommitmentValidationOutcomeCode(String value) {
        this.commitmentValidationOutcomeCode = value;
    }

    /**
     * Gets the value of the commitmentValidationOutcomeDescription property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCommitmentValidationOutcomeDescription() {
        return commitmentValidationOutcomeDescription;
    }

    /**
     * Sets the value of the commitmentValidationOutcomeDescription property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCommitmentValidationOutcomeDescription(String value) {
        this.commitmentValidationOutcomeDescription = value;
    }

}
