package com.apmoller.main.exception;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;

//@ResponseStatus(value=HttpStatus.NOT_FOUND, reason="No Booking Order found")
public class CustomerNotFoundException extends BaseException {

	public CustomerNotFoundException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
/*
	public CustomerNotFoundException(String custid)
	{
		super(ErrorCodes.CustomerNotFoundException+" "+ custid);
	}*/
	
}
