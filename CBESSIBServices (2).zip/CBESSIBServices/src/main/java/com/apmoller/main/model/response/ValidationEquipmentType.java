
package com.apmoller.main.model.response;

import java.math.BigDecimal;
import java.math.BigInteger;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * Custom complex element created for Cargo Type and
 * 				Container Size 
 * 
 * <p>Java class for ValidationEquipmentType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ValidationEquipmentType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="Bucket" type="{http://services.apmoller.net/AMM/v4}BucketCustomType" minOccurs="0"/&gt;
 *         &lt;element name="CommitmentConsumptionId" type="{http://services.apmoller.net/AMM/v4}Integer20Type" minOccurs="0"/&gt;
 *         &lt;element name="EquipmentSizeType" type="{http://services.apmoller.net/AMM/v4}String10NonNullType"/&gt;
 *         &lt;element name="EquipmentCount" type="{http://services.apmoller.net/AMM/v4}Integer13Type"/&gt;
 *         &lt;element name="FFEConsumption" type="{http://services.apmoller.net/AMM/v4}Decimal9d4Type"/&gt;
 *         &lt;element name="FFENotConsumed" type="{http://services.apmoller.net/AMM/v4}Decimal9d4Type"/&gt;
 *         &lt;element name="NextOpenBucket" type="{http://services.apmoller.net/AMM/v4}BucketCustomColorType" minOccurs="0"/&gt;
 *         &lt;element name="RateType" type="{http://services.apmoller.net/AMM/v4}String10NonNullType"/&gt;
 *         &lt;element name="TariffRate" type="{http://services.apmoller.net/AMM/v4}TariffRateCustomType" minOccurs="0"/&gt;
 *         &lt;element name="EquipmentTypeUptakeAcceptanceCode" type="{http://services.apmoller.net/AMM/v4}String3NonNullType" minOccurs="0"/&gt;
 *         &lt;element name="EquipmentTypeUptakeAcceptanceDescription" type="{http://services.apmoller.net/AMM/v4}String50NonNullType" minOccurs="0"/&gt;
 *         &lt;element name="EquipmentTypeValidationOutcomeCode" type="{http://services.apmoller.net/AMM/v4}String50NonNullType" minOccurs="0"/&gt;
 *         &lt;element name="EquipmentTypeValidationOutcomeDescription" type="{http://services.apmoller.net/AMM/v4}String50NonNullType" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ValidationEquipmentType", propOrder = {
    "bucket",
    "commitmentConsumptionId",
    "equipmentSizeType",
    "equipmentCount",
    "ffeConsumption",
    "ffeNotConsumed",
    "nextOpenBucket",
    "rateType",
    "tariffRate",
    "equipmentTypeUptakeAcceptanceCode",
    "equipmentTypeUptakeAcceptanceDescription",
    "equipmentTypeValidationOutcomeCode",
    "equipmentTypeValidationOutcomeDescription"
})
public class ValidationEquipmentType {

    @XmlElement(name = "Bucket")
    protected BucketCustomType bucket;
    @XmlElement(name = "CommitmentConsumptionId")
    protected BigInteger commitmentConsumptionId;
    @XmlElement(name = "EquipmentSizeType", required = true)
    protected String equipmentSizeType;
    @XmlElement(name = "EquipmentCount", required = true)
    protected BigInteger equipmentCount;
    @XmlElement(name = "FFEConsumption", required = true)
    protected BigDecimal ffeConsumption;
    @XmlElement(name = "FFENotConsumed", required = true)
    protected BigDecimal ffeNotConsumed;
    @XmlElement(name = "NextOpenBucket")
    protected BucketCustomColorType nextOpenBucket;
    @XmlElement(name = "RateType", required = true)
    protected String rateType;
    @XmlElement(name = "TariffRate")
    protected TariffRateCustomType tariffRate;
    @XmlElement(name = "EquipmentTypeUptakeAcceptanceCode")
    protected String equipmentTypeUptakeAcceptanceCode;
    @XmlElement(name = "EquipmentTypeUptakeAcceptanceDescription")
    protected String equipmentTypeUptakeAcceptanceDescription;
    @XmlElement(name = "EquipmentTypeValidationOutcomeCode")
    protected String equipmentTypeValidationOutcomeCode;
    @XmlElement(name = "EquipmentTypeValidationOutcomeDescription")
    protected String equipmentTypeValidationOutcomeDescription;

    /**
     * Gets the value of the bucket property.
     * 
     * @return
     *     possible object is
     *     {@link BucketCustomType }
     *     
     */
    public BucketCustomType getBucket() {
        return bucket;
    }

    /**
     * Sets the value of the bucket property.
     * 
     * @param value
     *     allowed object is
     *     {@link BucketCustomType }
     *     
     */
    public void setBucket(BucketCustomType value) {
        this.bucket = value;
    }

    /**
     * Gets the value of the commitmentConsumptionId property.
     * 
     * @return
     *     possible object is
     *     {@link BigInteger }
     *     
     */
    public BigInteger getCommitmentConsumptionId() {
        return commitmentConsumptionId;
    }

    /**
     * Sets the value of the commitmentConsumptionId property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigInteger }
     *     
     */
    public void setCommitmentConsumptionId(BigInteger value) {
        this.commitmentConsumptionId = value;
    }

    /**
     * Gets the value of the equipmentSizeType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getEquipmentSizeType() {
        return equipmentSizeType;
    }

    /**
     * Sets the value of the equipmentSizeType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEquipmentSizeType(String value) {
        this.equipmentSizeType = value;
    }

    /**
     * Gets the value of the equipmentCount property.
     * 
     * @return
     *     possible object is
     *     {@link BigInteger }
     *     
     */
    public BigInteger getEquipmentCount() {
        return equipmentCount;
    }

    /**
     * Sets the value of the equipmentCount property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigInteger }
     *     
     */
    public void setEquipmentCount(BigInteger value) {
        this.equipmentCount = value;
    }

    /**
     * Gets the value of the ffeConsumption property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getFFEConsumption() {
        return ffeConsumption;
    }

    /**
     * Sets the value of the ffeConsumption property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setFFEConsumption(BigDecimal value) {
        this.ffeConsumption = value;
    }

    /**
     * Gets the value of the ffeNotConsumed property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getFFENotConsumed() {
        return ffeNotConsumed;
    }

    /**
     * Sets the value of the ffeNotConsumed property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setFFENotConsumed(BigDecimal value) {
        this.ffeNotConsumed = value;
    }

    /**
     * Gets the value of the nextOpenBucket property.
     * 
     * @return
     *     possible object is
     *     {@link BucketCustomColorType }
     *     
     */
    public BucketCustomColorType getNextOpenBucket() {
        return nextOpenBucket;
    }

    /**
     * Sets the value of the nextOpenBucket property.
     * 
     * @param value
     *     allowed object is
     *     {@link BucketCustomColorType }
     *     
     */
    public void setNextOpenBucket(BucketCustomColorType value) {
        this.nextOpenBucket = value;
    }

    /**
     * Gets the value of the rateType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRateType() {
        return rateType;
    }

    /**
     * Sets the value of the rateType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRateType(String value) {
        this.rateType = value;
    }

    /**
     * Gets the value of the tariffRate property.
     * 
     * @return
     *     possible object is
     *     {@link TariffRateCustomType }
     *     
     */
    public TariffRateCustomType getTariffRate() {
        return tariffRate;
    }

    /**
     * Sets the value of the tariffRate property.
     * 
     * @param value
     *     allowed object is
     *     {@link TariffRateCustomType }
     *     
     */
    public void setTariffRate(TariffRateCustomType value) {
        this.tariffRate = value;
    }

    /**
     * Gets the value of the equipmentTypeUptakeAcceptanceCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getEquipmentTypeUptakeAcceptanceCode() {
        return equipmentTypeUptakeAcceptanceCode;
    }

    /**
     * Sets the value of the equipmentTypeUptakeAcceptanceCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEquipmentTypeUptakeAcceptanceCode(String value) {
        this.equipmentTypeUptakeAcceptanceCode = value;
    }

    /**
     * Gets the value of the equipmentTypeUptakeAcceptanceDescription property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getEquipmentTypeUptakeAcceptanceDescription() {
        return equipmentTypeUptakeAcceptanceDescription;
    }

    /**
     * Sets the value of the equipmentTypeUptakeAcceptanceDescription property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEquipmentTypeUptakeAcceptanceDescription(String value) {
        this.equipmentTypeUptakeAcceptanceDescription = value;
    }

    /**
     * Gets the value of the equipmentTypeValidationOutcomeCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getEquipmentTypeValidationOutcomeCode() {
        return equipmentTypeValidationOutcomeCode;
    }

    /**
     * Sets the value of the equipmentTypeValidationOutcomeCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEquipmentTypeValidationOutcomeCode(String value) {
        this.equipmentTypeValidationOutcomeCode = value;
    }

    /**
     * Gets the value of the equipmentTypeValidationOutcomeDescription property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getEquipmentTypeValidationOutcomeDescription() {
        return equipmentTypeValidationOutcomeDescription;
    }

    /**
     * Sets the value of the equipmentTypeValidationOutcomeDescription property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEquipmentTypeValidationOutcomeDescription(String value) {
        this.equipmentTypeValidationOutcomeDescription = value;
    }

}
