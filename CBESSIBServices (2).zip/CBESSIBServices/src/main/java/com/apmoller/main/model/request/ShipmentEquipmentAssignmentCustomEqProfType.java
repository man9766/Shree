
package com.apmoller.main.model.request;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;


/**
 * A requirement for an item of Equipment with
 * 				particular characteristics (eg Equipment Sub-Type) to be used for a
 * 				Shipment.
 * 
 * 				A specific item of Equipment may or may not be specified.
 * 				Typically, when a Shipment Equipment Assignment is created the
 * 				specific
 * 				Equipment item (eg Container Number) to be used is not
 * 				known, and is
 * 				added to the Shipment Equipment Assignment later.
 * 
 * 			
 * 
 * <p>Java class for ShipmentEquipmentAssignmentCustomEqProfType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ShipmentEquipmentAssignmentCustomEqProfType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="Container" type="{http://services.apmoller.net/AMM/v4}ContainerCustomIdType"/&gt;
 *         &lt;element name="EquipmentOOG" type="{http://services.apmoller.net/AMM/v4}EquipmentOOGStructure" minOccurs="0"/&gt;
 *         &lt;element name="EquipmentStuffingPlan" type="{http://services.apmoller.net/AMM/v4}EquipmentStuffingPlanStructure" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="IsOutOfGauge" type="{http://services.apmoller.net/AMM/v4}BooleanType" minOccurs="0"/&gt;
 *         &lt;element name="IsShipperOwned" type="{http://services.apmoller.net/AMM/v4}BooleanType" minOccurs="0"/&gt;
 *         &lt;element name="BookedWeight" type="{http://services.apmoller.net/AMM/v4}Decimal9d3Type" minOccurs="0"/&gt;
 *         &lt;element name="BookedWeightUnitOfMeasurement" type="{http://services.apmoller.net/AMM/v4}UnitOfMeasurementCustomValType" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ShipmentEquipmentAssignmentCustomEqProfType", propOrder = {
    "container",
    "equipmentOOG",
    "equipmentStuffingPlan",
    "isOutOfGauge",
    "isShipperOwned",
    "bookedWeight",
    "bookedWeightUnitOfMeasurement"
})
public class ShipmentEquipmentAssignmentCustomEqProfType {

    @XmlElement(name = "Container", required = true)
    protected ContainerCustomIdType container;
    @XmlElement(name = "EquipmentOOG")
    protected EquipmentOOGStructure equipmentOOG;
    @XmlElement(name = "EquipmentStuffingPlan")
    protected List<EquipmentStuffingPlanStructure> equipmentStuffingPlan;
    @XmlElement(name = "IsOutOfGauge")
    @XmlSchemaType(name = "anySimpleType")
    protected String isOutOfGauge;
    @XmlElement(name = "IsShipperOwned")
    @XmlSchemaType(name = "anySimpleType")
    protected String isShipperOwned;
    @XmlElement(name = "BookedWeight")
    protected BigDecimal bookedWeight;
    @XmlElement(name = "BookedWeightUnitOfMeasurement")
    protected UnitOfMeasurementCustomValType bookedWeightUnitOfMeasurement;

    /**
     * Gets the value of the container property.
     * 
     * @return
     *     possible object is
     *     {@link ContainerCustomIdType }
     *     
     */
    public ContainerCustomIdType getContainer() {
        return container;
    }

    /**
     * Sets the value of the container property.
     * 
     * @param value
     *     allowed object is
     *     {@link ContainerCustomIdType }
     *     
     */
    public void setContainer(ContainerCustomIdType value) {
        this.container = value;
    }

    /**
     * Gets the value of the equipmentOOG property.
     * 
     * @return
     *     possible object is
     *     {@link EquipmentOOGStructure }
     *     
     */
    public EquipmentOOGStructure getEquipmentOOG() {
        return equipmentOOG;
    }

    /**
     * Sets the value of the equipmentOOG property.
     * 
     * @param value
     *     allowed object is
     *     {@link EquipmentOOGStructure }
     *     
     */
    public void setEquipmentOOG(EquipmentOOGStructure value) {
        this.equipmentOOG = value;
    }

    /**
     * Gets the value of the equipmentStuffingPlan property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the equipmentStuffingPlan property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getEquipmentStuffingPlan().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link EquipmentStuffingPlanStructure }
     * 
     * 
     */
    public List<EquipmentStuffingPlanStructure> getEquipmentStuffingPlan() {
        if (equipmentStuffingPlan == null) {
            equipmentStuffingPlan = new ArrayList<EquipmentStuffingPlanStructure>();
        }
        return this.equipmentStuffingPlan;
    }

    /**
     * Gets the value of the isOutOfGauge property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getIsOutOfGauge() {
        return isOutOfGauge;
    }

    /**
     * Sets the value of the isOutOfGauge property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setIsOutOfGauge(String value) {
        this.isOutOfGauge = value;
    }

    /**
     * Gets the value of the isShipperOwned property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getIsShipperOwned() {
        return isShipperOwned;
    }

    /**
     * Sets the value of the isShipperOwned property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setIsShipperOwned(String value) {
        this.isShipperOwned = value;
    }

    /**
     * Gets the value of the bookedWeight property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getBookedWeight() {
        return bookedWeight;
    }

    /**
     * Sets the value of the bookedWeight property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setBookedWeight(BigDecimal value) {
        this.bookedWeight = value;
    }

    /**
     * Gets the value of the bookedWeightUnitOfMeasurement property.
     * 
     * @return
     *     possible object is
     *     {@link UnitOfMeasurementCustomValType }
     *     
     */
    public UnitOfMeasurementCustomValType getBookedWeightUnitOfMeasurement() {
        return bookedWeightUnitOfMeasurement;
    }

    /**
     * Sets the value of the bookedWeightUnitOfMeasurement property.
     * 
     * @param value
     *     allowed object is
     *     {@link UnitOfMeasurementCustomValType }
     *     
     */
    public void setBookedWeightUnitOfMeasurement(UnitOfMeasurementCustomValType value) {
        this.bookedWeightUnitOfMeasurement = value;
    }

}
