
package com.apmoller.main.model.response;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * A specific named vessel, e.g. Emma Maersk and
 * 				attributes describing the vessel like:
 * 				* vessel code
 * 				* Lloyds ship
 * 				number
 * 				* name
 * 				* breadth
 * 				* length
 * 				* draft
 * 				* Vessel capacity (Capacity of a
 * 				vessel measured in number of maximal
 * 				FFE containers which can fit
 * 				inside the vessel.)
 * 				* Weight capacity (The weight capacity is the
 * 				maximal allowed cargo
 * 				weight of all containers under optimal stowage)
 * 				* Reefer capacity
 * 				* Gross weight tonnage
 * 				* Net weight tonnage
 * 				* Dead
 * 				weight
 * 				* Maximum speed
 * 				* Minimum speed
 * 
 * <p>Java class for VesselCustomCodeType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="VesselCustomCodeType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;extension base="{http://services.apmoller.net/AMM/v4}GenericVehicleCustomEmptyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="VesselCode" type="{http://services.apmoller.net/AMM/v4}AlternativeCodeCustomString3Type"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/extension&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "VesselCustomCodeType", propOrder = {
    "vesselCode"
})
public class VesselCustomCodeType
    extends GenericVehicleCustomEmptyType
{

    @XmlElement(name = "VesselCode", required = true)
    protected AlternativeCodeCustomString3Type vesselCode;

    /**
     * Gets the value of the vesselCode property.
     * 
     * @return
     *     possible object is
     *     {@link AlternativeCodeCustomString3Type }
     *     
     */
    public AlternativeCodeCustomString3Type getVesselCode() {
        return vesselCode;
    }

    /**
     * Sets the value of the vesselCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link AlternativeCodeCustomString3Type }
     *     
     */
    public void setVesselCode(AlternativeCodeCustomString3Type value) {
        this.vesselCode = value;
    }

}
