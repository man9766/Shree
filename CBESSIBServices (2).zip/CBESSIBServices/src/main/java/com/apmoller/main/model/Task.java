package com.apmoller.main.model;

import org.hibernate.validator.constraints.NotBlank;

public class Task {

    @NotBlank(message = "Task name must not be blank!")
    private String name;

    @NotBlank(message = "Task description must not be blank!")
    private String description;

   

}