
package com.apmoller.main.model.response;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * Reference table for alternative codes that objects
 * 				can have in other places. Examples include:
 * 				* UN location code
 * 				(UN/LOCODE)
 * 				* RKST code
 * 				* RKTS code
 * 				* GEO ID
 * 				* IATA code
 * 				* Business Unit
 * 				Id e.g. DZALGMSL1
 * 				* Unique Id
 * 
 * 				Party roles' code aliases are stored in
 * 				this entity, e.g. an
 * 				organization' acting as a supplier which has a
 * 				SCV number would be
 * 				stored here together with the alias type of 'SCV
 * 				Code'.
 * 
 * 				Vessel code alias can also be stored in this entity, e.g.:
 * 				'Lloyd Code',
 * 				'Official Registration Number'
 * 
 * <p>Java class for AlternativeCodeStructure complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="AlternativeCodeStructure"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="AlternativeCodeVal" type="{http://services.apmoller.net/AMM/v4}String50NonNullType"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "AlternativeCodeStructure", propOrder = {
    "alternativeCodeVal"
})
public class AlternativeCodeStructure {

    @XmlElement(name = "AlternativeCodeVal", required = true)
    protected String alternativeCodeVal;

    /**
     * Gets the value of the alternativeCodeVal property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAlternativeCodeVal() {
        return alternativeCodeVal;
    }

    /**
     * Sets the value of the alternativeCodeVal property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAlternativeCodeVal(String value) {
        this.alternativeCodeVal = value;
    }

}
