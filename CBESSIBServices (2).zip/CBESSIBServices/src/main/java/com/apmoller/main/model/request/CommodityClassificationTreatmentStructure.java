
package com.apmoller.main.model.request;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * Standard cargo treatment for commodities, e.g.
 * 				scrap metal is shipped as 'Dry (standard)'.
 * 
 * 				QC: This entity mapping
 * 				commodities to CargoType (Maersk Cargo Types)
 * 				are envisioned, it is
 * 				not based on any existing linkage.
 * 			
 * 
 * <p>Java class for CommodityClassificationTreatmentStructure complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="CommodityClassificationTreatmentStructure"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="CommodityClassification" type="{http://services.apmoller.net/AMM/v4}CommodityClassificationCustomCdType"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "CommodityClassificationTreatmentStructure", propOrder = {
    "commodityClassification"
})
public class CommodityClassificationTreatmentStructure {

    @XmlElement(name = "CommodityClassification", required = true)
    protected CommodityClassificationCustomCdType commodityClassification;

    /**
     * Gets the value of the commodityClassification property.
     * 
     * @return
     *     possible object is
     *     {@link CommodityClassificationCustomCdType }
     *     
     */
    public CommodityClassificationCustomCdType getCommodityClassification() {
        return commodityClassification;
    }

    /**
     * Sets the value of the commodityClassification property.
     * 
     * @param value
     *     allowed object is
     *     {@link CommodityClassificationCustomCdType }
     *     
     */
    public void setCommodityClassification(CommodityClassificationCustomCdType value) {
        this.commodityClassification = value;
    }

}
