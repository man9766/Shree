
package com.apmoller.main.model.request;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * A internationally recognised code for a category
 * 				of Container of one specific size and one specific type.
 * 				Examples for
 * 				20ft containers include:
 * 
 * 				- 20G0 general container
 * 				- 20G1 general
 * 				container with ventilation holes
 * 				- 20H1 port hole reefer container
 * 				-
 * 				20T0 tank container
 * 				- 22V0 highly ventilated container
 * 				- 22RO integral
 * 				reefer container
 * 				- 22R1 integral reefer/heated container
 * 				- 22H2
 * 				thermal insulated external container
 * 				- 22U0 open top container
 * 				- 22U1
 * 				open top container - removable top
 * 				- 22P1 flat rack with fixed ends
 * 
 * 				Codes of a similar general format are also used for Containers of
 * 				other
 * 				sizes.
 * 				List of possible container size types according to ISO
 * 				6346:1995.
 * 
 * 				10G1 10G1 Dry (10' x 8' x 8')
 * 				20B0 20B0 Bulk (20' x 8' x
 * 				8')
 * 				20B1 20B1 Bulk (20' x 8' x 8')
 * 				20B3 20B3 Bulk (20' x 8' x 8')
 * 				20B4
 * 				20B4 Bulk (20' x 8' x 8')
 * 				20B5 20B5 Bulk (20' x 8' x 8')
 * 				20B6 20B6
 * 				Bulk (20' x 8' x 8')
 * 				20G0 20G0 Dry (20' x 8' x 8')
 * 				20G1 20G1 Dry (20'
 * 				x 8' x 8')
 * 				20G2 20G2 Dry (20' x 8' x 8')
 * 				20G3 20G3 Dry (20' x 8' x 8')
 * 				20H0 20H0 Insulated (20' x 8' x 8')
 * 				20H1 20H1 Insulated (20' x 8' x
 * 				8')
 * 				20H2 20H2 Insulated (20' x 8' x 8')
 * 				20H5 20H5 Insulated (20' x 8'
 * 				x 8')
 * 				20H6 20H6 Insulated (20' x 8' x 8')
 * 				20P1 20P1 Flat (20' x 8' x
 * 				8')
 * 				20P2 20P2 Flat (20' x 8' x 8')
 * 				20P3 20P3 Flat Collapsible (20' x
 * 				8' x 8')
 * 				20P4 20P4 Flat Collapsible (20' x 8' x 8')
 * 				20P5 20P5 Platform
 * 				Superstructure (20' x 8' x 8')
 * 				20R0 20R0 Reefer (20' x 8' x 8')
 * 				20R1
 * 				20R1 Reefer (20' x 8' x 8')
 * 				20R2 20R2 Reefer (20' x 8' x 8')
 * 				20R3 20R3
 * 				Reefer (20' x 8' x 8')
 * 				20R8 20R8 Reefer (20' x 8' x 8')
 * 				20R9 20R9
 * 				Reefer (20' x 8' x 8')
 * 				20T0 20T0 Tank (20' x 8' x 8')
 * 				20T1 20T1 Tank
 * 				(20' x 8' x 8')
 * 				20T2 20T2 Tank (20' x 8' x 8')
 * 				20T3 20T3 Tank for
 * 				Dangerous Liquid (20' x 8' x 8')
 * 				20T4 20T4 Tank for Dangerous Liquid
 * 				(20' x 8' x 8')
 * 				20T5 20T5 Tank for Dangerous Liquid (20' x 8' x 8')
 * 				20T6 20T6 Tank for Dangerous Liquid (20' x 8' x 8')
 * 				20T7 20T7 Tank
 * 				for Gas (20' x 8' x 8')
 * 				20T8 20T8 Tank for Gas (20' x 8' x 8')
 * 				20T9
 * 				20T9 Tank for Gas (20' x 8' x 8')
 * 				20U0 20U0 Open Top (20' x 8' x 8')
 * 				20U1 20U1 Open Top (20' x 8' x 8')
 * 				20U2 20U2 Open Top (20' x 8' x 8')
 * 				20U3 20U3 Open Top (20' x 8' x 8')
 * 				20U4 20U4 Open Top (20' x 8' x 8')
 * 				20U5 20U5 Open Top (20' x 8' x 8')
 * 				20V0 20V0 Ventilated (20' x 8' x
 * 				8')
 * 				20V2 20V2 Ventilated (20' x 8' x 8')
 * 				20V4 20V4 Ventilated (20' x
 * 				8' x 8')
 * 				22B0 22B0 Bulk (20' x 8'6'' x 8')
 * 				22B1 22B1 Bulk (20' x 8'6''
 * 				x 8')
 * 				22B3 22B3 Bulk (20' x 8'6'' x 8')
 * 				22B4 22B4 Bulk (20' x 8'6'' x
 * 				8')
 * 				22B5 22B5 Bulk (20' x 8'6'' x 8')
 * 				22B6 22B6 Bulk (20' x 8'6'' x
 * 				8')
 * 				22G0 22G0 Dry (20' x 8'6'' x 8')
 * 				22G1 22G1 Dry (20' x 8'6'' x 8')
 * 				22G2 22G2 Dry (20' x 8'6'' x 8')
 * 				22G3 22G3 Dry (20' x 8'6'' x 8')
 * 				22G4 22G4 General Purpose / Dry (20' x 8'6'' x 8')
 * 				22G8 22G8 General
 * 				Purpose / Dry (20' x 8'6'' x 8')
 * 				22G9 22G9 General Purpose / Dry (20'
 * 				x 8'6'' x 8')
 * 				22H0 22H0 Insulated (20' x 8'6'' x 8')
 * 				22H2 22H2
 * 				Insulated (20' x 8'6'' x 8')
 * 				22P1 22P1 Flat (20' x 8'6'' x 8')
 * 				22P2
 * 				22P2 Flat (20' x 8'6'' x 8')
 * 				22P3 22P3 Flat Collapsible (20' x 8'6''
 * 				x 8')
 * 				22P5 22P5 Platform Superstructure (20' x 8'6'' x 8')
 * 				22P7 22P7
 * 				Platform (20' x 8'6'' x 8')
 * 				22P8 22P8 Platform (20' x 8'6'' x 8')
 * 				22P9 22P9 Platform (20' x 8'6'' x 8')
 * 				22R0 22R0 Reefer (20' x 8'6'' x
 * 				8')
 * 				22R1 22R1 Reefer (20' x 8'6'' x 8')
 * 				22R7 22R7 Reefer (20' x 8'6''
 * 				x 8')
 * 				22R9 22R9 Reefer (20' x 8'6'' x 8')
 * 				22S1 22S1 Automobile (20' x
 * 				8'6'' x 8')
 * 				22T0 22T0 Tank (20' x 8'6'' x 8')
 * 				22T1 22T1 Tank (20' x
 * 				8'6'' x 8')
 * 				22T2 22T2 Tank (20' x 8'6'' x 8')
 * 				22T3 22T3 Tank for
 * 				Dangerous Liquid (20' x 8'6'' x 8')
 * 				22T4 22T4 Tank for Dangerous
 * 				Liquid (20' x 8'6'' x 8')
 * 				22T5 22T5 Tank for Dangerous Liquid (20' x
 * 				8'6'' x 8')
 * 				22T6 22T6 Tank for Dangerous Liquid (20' x 8'6'' x 8')
 * 				22T7 22T7 Tank for Gas (20' x 8'6'' x 8')
 * 				22T8 22T8 Tank for Gas (20'
 * 				x 8'6'' x 8')
 * 				22U0 22U0 Open Top (20' x 8'6'' x 8')
 * 				22U1 22U1 Open Top
 * 				(20' x 8'6'' x 8')
 * 				22U6 22U6 Hard Top (20' x 8'6'' x 8')
 * 				22V0 22V0
 * 				Ventilated (20' x 8'6'' x 8')
 * 				22V2 22V2 Ventilated (20' x 8'6'' x 8')
 * 				22V3 22V3 Ventilated (20' x 8'6'' x 8')
 * 				25G0 25G0 High Cube Dry (20'
 * 				x 9'6'' x 8')
 * 				25R1 25R1 High Cube Reefer (20' x 9'6'' x 8')
 * 				26G0 26G0
 * 				High Cube Dry (20' x 9'6'' x 8')
 * 				26H0 26H0 High Cube Insulated (20' x
 * 				9'6'' x 8')
 * 				26T0 26T0 High Cube Tank (20' x 9'6'' x 8')
 * 				28P0 28P0
 * 				Platform (20' x 4'3'' x 8')
 * 				28T8 28T8 Tank for Gas (20' x 4'3'' x 8')
 * 				28U1 28U1 Open Top (20' x 4'3'' x 8')
 * 				28V0 28V0 Ventilated (20' x
 * 				4'3'' x 8')
 * 				29P0 29P0 Platform (20' x 4' x 8')
 * 				2EG0 2EG0 High Cube Dry
 * 				(20' x 9'6'' x 8'/8'2'')
 * 				42B0 42B0 Bulk (40' x 8'6'' x 8')
 * 				42G0 42G0
 * 				Dry (40' x 8'6'' x 8')
 * 				42G1 42G1 Dry (40' x 8'6'' x 8')
 * 				42H0 42H0
 * 				Insulated (40' x 8'6'' x 8')
 * 				42P1 42P1 Flat (40' x 8'6'' x 8')
 * 				42P2
 * 				42P2 Flat (40' x 8'6'' x 8')
 * 				42P3 42P3 Flat Collapsible (40' x 8'6''
 * 				x 8')
 * 				42P5 42P5 Platform Superstructure (40' x 8'6'' x 8')
 * 				42P6 42P6
 * 				Platform (40' x 8'6'' x 8')
 * 				42P8 42P8 Platform (40' x 8'6'' x 8')
 * 				42P9 42P9 Platform (40' x 8'6'' x 8')
 * 				42R0 42R0 Reefer (40' x 8'6'' x
 * 				8')
 * 				42R1 42R1 Reefer (40' x 8'6'' x 8')
 * 				42R3 42R3 Reefer (40' x 8'6''
 * 				x 8')
 * 				42R9 42R9 Reefer (40' x 8'6'' x 8')
 * 				42S1 42S1 Automobile (40' x
 * 				8'6'' x 8')
 * 				42T2 42T2 Tank (40' x 8'6'' x 8')
 * 				42T5 42T5 Tank for
 * 				Dangerous Liquid (40' x 8'6'' x 8')
 * 				42T6 42T6 Tank for Dangerous
 * 				Liquid (40' x 8'6'' x 8')
 * 				42T8 42T8 Tank for Gas (40' x 8'6'' x 8')
 * 				42U1 42U1 Open Top (40' x 8'6'' x 8')
 * 				42U6 42U6 Hard Top (40' x 8'6''
 * 				x 8')
 * 				42V0 42V0 Ventilated (40' x 8'6'' x 8')
 * 				45B3 45B3 High Cube Bulk
 * 				(40' x 9'6'' x 8')
 * 				45G0 45G0 High Cube Dry (40' x 9'6'' x 8')
 * 				45G1
 * 				45G1 High Cube Dry (40' x 9'6'' x 8')
 * 				45P3 45P3 High Cube Flat
 * 				Collapsible (40' x 9'6'' x 8')
 * 				45P8 45P8 High Cube Platform (40' x
 * 				9'6'' x 8')
 * 				45R1 45R1 High Cube Reefer (40' x 9'6'' x 8')
 * 				45R9 45R9
 * 				High Cube Reefer (40' x 9'6'' x 8')
 * 				45U1 45U1 High Cube Open Top (40'
 * 				x 9'6'' x 8')
 * 				45U6 45U6 High Cube Hard Top (40' x 9'6'' x 8')
 * 				46H0
 * 				46H0 High Cube Insulated (40' x 9'6'' x 8')
 * 				46P3 46P3 High Cube Flat
 * 				Collapsible (40' x 9'6'' x 8')
 * 				48P0 48P0 Platform (40' x 4'3'' x 8')
 * 				48T8 48T8 Tank for Gas (40' x 4'3'' x 8')
 * 				48U1 48U1 Open Top (40' x
 * 				4'3'' x 8')
 * 				49P0 49P0 Platform (40' x 4' x 8')
 * 				4CG0 4CG0 Dry (40' x
 * 				8'6'' x 8'/8'2'')
 * 				L0G1 L0G1 Dry (45' x 8' x 8')
 * 				L2G1 L2G1 Dry (45' x
 * 				8'6'' x 8')
 * 				L5G1 L5G1 High Cube Dry (45' x 9'6'' x 8')
 * 				L5R0 L5R0 High
 * 				Cube Reefer (45' x 9'6'' x 8')
 * 				L5R1 L5R1 High Cube Reefer (45' x
 * 				9'6'' x 8')
 * 				L5R2 L5R2 High Cube Reefer (45' x 9'6'' x 8')
 * 				L5R3 L5R3
 * 				High Cube Reefer (45' x 9'6'' x 8')
 * 				L5R4 L5R4 High Cube Reefer (45' x
 * 				9'6'' x 8')
 * 				L5R8 L5R8 High Cube Reefer (45' x 9'6'' x 8')
 * 				L5R9 L5R9
 * 				High Cube Reefer (45' x 9'6'' x 8')
 * 				LDG1 LDG1 High Cube Dry (45' x 9'
 * 				x 8'/8'2'')
 * 				LDG8 LDG8 High Cube General Purpose / Dry (45' x 9' x
 * 				8'/8'2'')
 * 				LEG1 LEG1 High Cube Dry (45' x 9'6'' x 8'/8'2'')
 * 				LEG8 LEG8
 * 				High Cube General Purpose / Dry (45' x 9'6'' x 8'/8'2'')
 * 				LEG9 LEG9
 * 				High Cube General Purpose / Dry (45' x 9'6'' x 8'/8'2'')
 * 				LLG1 LLG1
 * 				Dry (45' x 8'6'' x >8'2'')
 * 				LNG1 LNG1 High Cube Dry (45' x 9'6'' x
 * 				>8'2'')
 * 				LNR1 LNR1 High Cube Reefer (45' x 9'6'' x >8'2'')
 * 			
 * 
 * <p>Java class for ISOContainerSizeTypeStructure complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ISOContainerSizeTypeStructure"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="ISOContainerHeight" type="{http://services.apmoller.net/AMM/v4}ISOContainerHeightStructure"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ISOContainerSizeTypeStructure", propOrder = {
    "isoContainerHeight"
})
public class ISOContainerSizeTypeStructure {

    @XmlElement(name = "ISOContainerHeight", required = true)
    protected ISOContainerHeightStructure isoContainerHeight;

    /**
     * Gets the value of the isoContainerHeight property.
     * 
     * @return
     *     possible object is
     *     {@link ISOContainerHeightStructure }
     *     
     */
    public ISOContainerHeightStructure getISOContainerHeight() {
        return isoContainerHeight;
    }

    /**
     * Sets the value of the isoContainerHeight property.
     * 
     * @param value
     *     allowed object is
     *     {@link ISOContainerHeightStructure }
     *     
     */
    public void setISOContainerHeight(ISOContainerHeightStructure value) {
        this.isoContainerHeight = value;
    }

}
