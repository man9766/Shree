
package com.apmoller.main.model.response;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for ValidateShipmentOnYieldResponseType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ValidateShipmentOnYieldResponseType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="ClientReference" type="{http://services.apmoller.net/AMM/v4}String1000NonNullType" minOccurs="0"/&gt;
 *         &lt;element name="CommitmentWeek" type="{http://services.apmoller.net/AMM/v4}Integer6Type" minOccurs="0"/&gt;
 *         &lt;element name="LargeBookingLimitFFE" type="{http://services.apmoller.net/AMM/v4}String21NonNullType" minOccurs="0"/&gt;
 *         &lt;element name="Shipment" type="{http://services.apmoller.net/AMM/v4}ShipmentCustomValResType"/&gt;
 *         &lt;element name="ValidationDetails" type="{http://services.apmoller.net/AMM/v4}ValidationDetailsType" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="ShipmentUptakeAcceptanceCode" type="{http://services.apmoller.net/AMM/v4}String3NonNullType" minOccurs="0"/&gt;
 *         &lt;element name="ShipmentUptakeAcceptanceDescription" type="{http://services.apmoller.net/AMM/v4}String50NonNullType" minOccurs="0"/&gt;
 *         &lt;element name="ShipmentValidationOutcomeCode" type="{http://services.apmoller.net/AMM/v4}String50NonNullType" minOccurs="0"/&gt;
 *         &lt;element name="ShipmentValidationOutcomeDescription" type="{http://services.apmoller.net/AMM/v4}String50NonNullType" minOccurs="0"/&gt;
 *         &lt;element name="SteeredLegMessage" type="{http://services.apmoller.net/AMM/v4}String500NonNullType"/&gt;
 *         &lt;element name="SteeredLegStatusCode" type="{http://services.apmoller.net/AMM/v4}String15NonNullType"/&gt;
 *         &lt;element name="UptakeManagerCondition" type="{http://services.apmoller.net/AMM/v4}String1000NonNullType" minOccurs="0"/&gt;
 *         &lt;element name="Message" type="{http://services.apmoller.net/AMM/v4}String500NonNullType"/&gt;
 *         &lt;element name="StatusCode" type="{http://services.apmoller.net/AMM/v4}String15NonNullType"/&gt;
 *         &lt;element name="ValidationWarnings" type="{http://services.apmoller.net/AMM/v4}String4000Type" minOccurs="0"/&gt;
 *         &lt;element name="RequestParameterList" type="{http://services.apmoller.net/AMM/v4}AdditionalRequestParamListType" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ValidateShipmentOnYieldResponseType", propOrder = {
    "clientReference",
    "commitmentWeek",
    "largeBookingLimitFFE",
    "shipment",
    "validationDetails",
    "shipmentUptakeAcceptanceCode",
    "shipmentUptakeAcceptanceDescription",
    "shipmentValidationOutcomeCode",
    "shipmentValidationOutcomeDescription",
    "steeredLegMessage",
    "steeredLegStatusCode",
    "uptakeManagerCondition",
    "message",
    "statusCode",
    "validationWarnings",
    "requestParameterList"
})
@XmlRootElement
public class ValidateShipmentOnYieldResponseType {

    @XmlElement(name = "ClientReference")
    protected String clientReference;
    @XmlElement(name = "CommitmentWeek")
    protected BigInteger commitmentWeek;
    @XmlElement(name = "LargeBookingLimitFFE")
    protected String largeBookingLimitFFE;
    @XmlElement(name = "Shipment", required = true)
    protected ShipmentCustomValResType shipment;
    @XmlElement(name = "ValidationDetails")
    protected List<ValidationDetailsType> validationDetails;
    @XmlElement(name = "ShipmentUptakeAcceptanceCode")
    protected String shipmentUptakeAcceptanceCode;
    @XmlElement(name = "ShipmentUptakeAcceptanceDescription")
    protected String shipmentUptakeAcceptanceDescription;
    @XmlElement(name = "ShipmentValidationOutcomeCode")
    protected String shipmentValidationOutcomeCode;
    @XmlElement(name = "ShipmentValidationOutcomeDescription")
    protected String shipmentValidationOutcomeDescription;
    @XmlElement(name = "SteeredLegMessage", required = true)
    protected String steeredLegMessage;
    @XmlElement(name = "SteeredLegStatusCode", required = true)
    protected String steeredLegStatusCode;
    @XmlElement(name = "UptakeManagerCondition")
    protected String uptakeManagerCondition;
    @XmlElement(name = "Message", required = true)
    protected String message;
    @XmlElement(name = "StatusCode", required = true)
    protected String statusCode;
    @XmlElement(name = "ValidationWarnings")
    protected String validationWarnings;
    @XmlElement(name = "RequestParameterList")
    protected AdditionalRequestParamListType requestParameterList;

    /**
     * Gets the value of the clientReference property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getClientReference() {
        return clientReference;
    }

    /**
     * Sets the value of the clientReference property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setClientReference(String value) {
        this.clientReference = value;
    }

    /**
     * Gets the value of the commitmentWeek property.
     * 
     * @return
     *     possible object is
     *     {@link BigInteger }
     *     
     */
    public BigInteger getCommitmentWeek() {
        return commitmentWeek;
    }

    /**
     * Sets the value of the commitmentWeek property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigInteger }
     *     
     */
    public void setCommitmentWeek(BigInteger value) {
        this.commitmentWeek = value;
    }

    /**
     * Gets the value of the largeBookingLimitFFE property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLargeBookingLimitFFE() {
        return largeBookingLimitFFE;
    }

    /**
     * Sets the value of the largeBookingLimitFFE property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLargeBookingLimitFFE(String value) {
        this.largeBookingLimitFFE = value;
    }

    /**
     * Gets the value of the shipment property.
     * 
     * @return
     *     possible object is
     *     {@link ShipmentCustomValResType }
     *     
     */
    public ShipmentCustomValResType getShipment() {
        return shipment;
    }

    /**
     * Sets the value of the shipment property.
     * 
     * @param value
     *     allowed object is
     *     {@link ShipmentCustomValResType }
     *     
     */
    public void setShipment(ShipmentCustomValResType value) {
        this.shipment = value;
    }

    /**
     * Gets the value of the validationDetails property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the validationDetails property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getValidationDetails().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link ValidationDetailsType }
     * 
     * 
     */
    public List<ValidationDetailsType> getValidationDetails() {
        if (validationDetails == null) {
            validationDetails = new ArrayList<ValidationDetailsType>();
        }
        return this.validationDetails;
    }

    public void setValidationDetails(List<ValidationDetailsType> validationDetails) {
		this.validationDetails = validationDetails;
	}

	/**
     * Gets the value of the shipmentUptakeAcceptanceCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getShipmentUptakeAcceptanceCode() {
        return shipmentUptakeAcceptanceCode;
    }

    /**
     * Sets the value of the shipmentUptakeAcceptanceCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setShipmentUptakeAcceptanceCode(String value) {
        this.shipmentUptakeAcceptanceCode = value;
    }

    /**
     * Gets the value of the shipmentUptakeAcceptanceDescription property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getShipmentUptakeAcceptanceDescription() {
        return shipmentUptakeAcceptanceDescription;
    }

    /**
     * Sets the value of the shipmentUptakeAcceptanceDescription property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setShipmentUptakeAcceptanceDescription(String value) {
        this.shipmentUptakeAcceptanceDescription = value;
    }

    /**
     * Gets the value of the shipmentValidationOutcomeCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getShipmentValidationOutcomeCode() {
        return shipmentValidationOutcomeCode;
    }

    /**
     * Sets the value of the shipmentValidationOutcomeCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setShipmentValidationOutcomeCode(String value) {
        this.shipmentValidationOutcomeCode = value;
    }

    /**
     * Gets the value of the shipmentValidationOutcomeDescription property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getShipmentValidationOutcomeDescription() {
        return shipmentValidationOutcomeDescription;
    }

    /**
     * Sets the value of the shipmentValidationOutcomeDescription property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setShipmentValidationOutcomeDescription(String value) {
        this.shipmentValidationOutcomeDescription = value;
    }

    /**
     * Gets the value of the steeredLegMessage property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSteeredLegMessage() {
        return steeredLegMessage;
    }

    /**
     * Sets the value of the steeredLegMessage property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSteeredLegMessage(String value) {
        this.steeredLegMessage = value;
    }

    /**
     * Gets the value of the steeredLegStatusCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSteeredLegStatusCode() {
        return steeredLegStatusCode;
    }

    /**
     * Sets the value of the steeredLegStatusCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSteeredLegStatusCode(String value) {
        this.steeredLegStatusCode = value;
    }

    /**
     * Gets the value of the uptakeManagerCondition property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUptakeManagerCondition() {
        return uptakeManagerCondition;
    }

    /**
     * Sets the value of the uptakeManagerCondition property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUptakeManagerCondition(String value) {
        this.uptakeManagerCondition = value;
    }

    /**
     * Gets the value of the message property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMessage() {
        return message;
    }

    /**
     * Sets the value of the message property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMessage(String value) {
        this.message = value;
    }

    /**
     * Gets the value of the statusCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getStatusCode() {
        return statusCode;
    }

    /**
     * Sets the value of the statusCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setStatusCode(String value) {
        this.statusCode = value;
    }

    /**
     * Gets the value of the validationWarnings property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getValidationWarnings() {
        return validationWarnings;
    }

    /**
     * Sets the value of the validationWarnings property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setValidationWarnings(String value) {
        this.validationWarnings = value;
    }

    /**
     * Gets the value of the requestParameterList property.
     * 
     * @return
     *     possible object is
     *     {@link AdditionalRequestParamListType }
     *     
     */
    public AdditionalRequestParamListType getRequestParameterList() {
        return requestParameterList;
    }

    /**
     * Sets the value of the requestParameterList property.
     * 
     * @param value
     *     allowed object is
     *     {@link AdditionalRequestParamListType }
     *     
     */
    public void setRequestParameterList(AdditionalRequestParamListType value) {
        this.requestParameterList = value;
    }

}
