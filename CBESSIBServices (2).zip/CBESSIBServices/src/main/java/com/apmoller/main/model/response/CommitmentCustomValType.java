
package com.apmoller.main.model.response;

import java.math.BigInteger;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;


/**
 * When we promise / commit to a customer to that
 * 				there will be space available on a vessel either on weekly basis
 * 				(regular) or as a total number of FFE with a weekly limit
 * 				(Irreglular)
 * 
 * <p>Java class for CommitmentCustomValType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="CommitmentCustomValType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="CommitmentId" type="{http://services.apmoller.net/AMM/v4}Integer20Type"/&gt;
 *         &lt;element name="CommitmentTypeInd" type="{http://services.apmoller.net/AMM/v4}String20NonNullType"/&gt;
 *         &lt;element name="IrregularCommitment" type="{http://services.apmoller.net/AMM/v4}IrregularCommitmentCustomConsType" minOccurs="0"/&gt;
 *         &lt;element name="IsConcernCode" type="{http://services.apmoller.net/AMM/v4}BooleanType"/&gt;
 *         &lt;element name="RegularCommitment" type="{http://services.apmoller.net/AMM/v4}RegularCommitmentCustomFFEConsType" minOccurs="0"/&gt;
 *         &lt;element name="ValidFromDttm" type="{http://services.apmoller.net/AMM/v4}Integer6Type"/&gt;
 *         &lt;element name="ValidToDttm" type="{http://services.apmoller.net/AMM/v4}Integer6Type"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "CommitmentCustomValType", propOrder = {
    "commitmentId",
    "commitmentTypeInd",
    "irregularCommitment",
    "isConcernCode",
    "regularCommitment",
    "validFromDttm",
    "validToDttm"
})
public class CommitmentCustomValType {

    @XmlElement(name = "CommitmentId", required = true)
    protected BigInteger commitmentId;
    @XmlElement(name = "CommitmentTypeInd", required = true)
    protected String commitmentTypeInd;
    @XmlElement(name = "IrregularCommitment")
    protected IrregularCommitmentCustomConsType irregularCommitment;
    @XmlElement(name = "IsConcernCode", required = true)
    @XmlSchemaType(name = "anySimpleType")
    protected String isConcernCode;
    @XmlElement(name = "RegularCommitment")
    protected RegularCommitmentCustomFFEConsType regularCommitment;
    @XmlElement(name = "ValidFromDttm", required = true)
    protected BigInteger validFromDttm;
    @XmlElement(name = "ValidToDttm", required = true)
    protected BigInteger validToDttm;

    /**
     * Gets the value of the commitmentId property.
     * 
     * @return
     *     possible object is
     *     {@link BigInteger }
     *     
     */
    public BigInteger getCommitmentId() {
        return commitmentId;
    }

    /**
     * Sets the value of the commitmentId property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigInteger }
     *     
     */
    public void setCommitmentId(BigInteger value) {
        this.commitmentId = value;
    }

    /**
     * Gets the value of the commitmentTypeInd property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCommitmentTypeInd() {
        return commitmentTypeInd;
    }

    /**
     * Sets the value of the commitmentTypeInd property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCommitmentTypeInd(String value) {
        this.commitmentTypeInd = value;
    }

    /**
     * Gets the value of the irregularCommitment property.
     * 
     * @return
     *     possible object is
     *     {@link IrregularCommitmentCustomConsType }
     *     
     */
    public IrregularCommitmentCustomConsType getIrregularCommitment() {
        return irregularCommitment;
    }

    /**
     * Sets the value of the irregularCommitment property.
     * 
     * @param value
     *     allowed object is
     *     {@link IrregularCommitmentCustomConsType }
     *     
     */
    public void setIrregularCommitment(IrregularCommitmentCustomConsType value) {
        this.irregularCommitment = value;
    }

    /**
     * Gets the value of the isConcernCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getIsConcernCode() {
        return isConcernCode;
    }

    /**
     * Sets the value of the isConcernCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setIsConcernCode(String value) {
        this.isConcernCode = value;
    }

    /**
     * Gets the value of the regularCommitment property.
     * 
     * @return
     *     possible object is
     *     {@link RegularCommitmentCustomFFEConsType }
     *     
     */
    public RegularCommitmentCustomFFEConsType getRegularCommitment() {
        return regularCommitment;
    }

    /**
     * Sets the value of the regularCommitment property.
     * 
     * @param value
     *     allowed object is
     *     {@link RegularCommitmentCustomFFEConsType }
     *     
     */
    public void setRegularCommitment(RegularCommitmentCustomFFEConsType value) {
        this.regularCommitment = value;
    }

    /**
     * Gets the value of the validFromDttm property.
     * 
     * @return
     *     possible object is
     *     {@link BigInteger }
     *     
     */
    public BigInteger getValidFromDttm() {
        return validFromDttm;
    }

    /**
     * Sets the value of the validFromDttm property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigInteger }
     *     
     */
    public void setValidFromDttm(BigInteger value) {
        this.validFromDttm = value;
    }

    /**
     * Gets the value of the validToDttm property.
     * 
     * @return
     *     possible object is
     *     {@link BigInteger }
     *     
     */
    public BigInteger getValidToDttm() {
        return validToDttm;
    }

    /**
     * Sets the value of the validToDttm property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigInteger }
     *     
     */
    public void setValidToDttm(BigInteger value) {
        this.validToDttm = value;
    }

}
