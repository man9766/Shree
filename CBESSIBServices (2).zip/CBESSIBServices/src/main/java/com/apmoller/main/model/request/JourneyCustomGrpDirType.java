
package com.apmoller.main.model.request;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * A Journey is a "Transport product" is the core
 * 				business offering that the enterprise provides to its customers,
 * 				i.e. moving something from point A to point B.
 * 				The "Transport
 * 				product" is defined by
 * 				- Trade lane
 * 				- Place of receipt (Business
 * 				Defined Area)
 * 				- Place of delivery (Business Defined Area)
 * 				-
 * 				Receipt/delivery mode (CY/Container Yard or SD/Store Door)
 * 				- Cargo
 * 				type
 * 				- Container type / size
 * 				- Sea Carrier
 * 
 * 				A "Transport product"
 * 				consists of one or more "Transport Product
 * 				Legs" of which at least
 * 				one will always be an "Ocean product".
 * 				In addition to the mandatory
 * 				"Ocean product" there can be more "Ocean
 * 				products" and also one or
 * 				more "Haulage products" attached to the
 * 				"Transport" product.
 * 				Read more
 * 				about the various types of Transport Product Legs in the
 * 				entity
 * 				description for the entity "Transport Product Leg".
 * 				ARIS DEFINITION
 * 				A
 * 				Transport Product defined in terms of:
 * 
 * 				- Place of Receipt BDA
 * 				(Business Defined Area) - see note below
 * 				- First Load Port (optional)
 * 				- Last Discharge Port (optional)
 * 				- Place of Delivery BDA - see note
 * 				below
 * 				- Cargo Type(s)
 * 				- Sea Carrier
 * 				- Direction (optional)
 * 				First Load
 * 				Port and Last Discharge Port must either be both present or
 * 				both
 * 				missing, a Journey cannot have just a single Port. A Journey
 * 				with
 * 				Load Ports specified is known as 'Absolute'. A Journey with
 * 				Load
 * 				Ports not specified is known as 'Generic'.
 * 				Note that there are many
 * 				type of BDAs for different purposes, and access
 * 				to this data will
 * 				need to apply the appropriate filter by using the
 * 				correct BDA Type -
 * 				in this case, there will be a BDA Type
 * 				corresponding to something
 * 				such as "Trade Zone".
 * 
 * 
 * <p>Java class for JourneyCustomGrpDirType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="JourneyCustomGrpDirType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="CardinalDirection" type="{http://services.apmoller.net/AMM/v4}CardinalDirectionStructure" minOccurs="0"/&gt;
 *         &lt;element name="JourneyGroup" type="{http://services.apmoller.net/AMM/v4}JourneyGroupStructure"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "JourneyCustomGrpDirType", propOrder = {
    "cardinalDirection",
    "journeyGroup"
})
public class JourneyCustomGrpDirType {

    @XmlElement(name = "CardinalDirection")
    protected CardinalDirectionStructure cardinalDirection;
    @XmlElement(name = "JourneyGroup", required = true)
    protected JourneyGroupStructure journeyGroup;

    /**
     * Gets the value of the cardinalDirection property.
     * 
     * @return
     *     possible object is
     *     {@link CardinalDirectionStructure }
     *     
     */
    public CardinalDirectionStructure getCardinalDirection() {
        return cardinalDirection;
    }

    /**
     * Sets the value of the cardinalDirection property.
     * 
     * @param value
     *     allowed object is
     *     {@link CardinalDirectionStructure }
     *     
     */
    public void setCardinalDirection(CardinalDirectionStructure value) {
        this.cardinalDirection = value;
    }

    /**
     * Gets the value of the journeyGroup property.
     * 
     * @return
     *     possible object is
     *     {@link JourneyGroupStructure }
     *     
     */
    public JourneyGroupStructure getJourneyGroup() {
        return journeyGroup;
    }

    /**
     * Sets the value of the journeyGroup property.
     * 
     * @param value
     *     allowed object is
     *     {@link JourneyGroupStructure }
     *     
     */
    public void setJourneyGroup(JourneyGroupStructure value) {
        this.journeyGroup = value;
    }

}
