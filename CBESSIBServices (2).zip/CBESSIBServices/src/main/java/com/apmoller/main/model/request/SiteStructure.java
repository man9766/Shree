
package com.apmoller.main.model.request;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;


/**
 * A site is a location that is of relevance to the
 * 				enterprise, it can be a harbour, inland point etc. and the site can
 * 				have diferent facilities like maritime container terminal, warehouse
 * 				etc.
 * 
 * <p>Java class for SiteStructure complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="SiteStructure"&gt;
 *   &lt;complexContent&gt;
 *     &lt;extension base="{http://services.apmoller.net/AMM/v4}DefinedAreaCustomSiteType"&gt;
 *     &lt;/extension&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "SiteStructure")
public class SiteStructure
    extends DefinedAreaCustomSiteType
{


}
