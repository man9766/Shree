
package com.apmoller.main.model.request;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * A mode of service for transport between the
 * 				Customer and Carrier at the start point (Place Of Receipt) of and
 * 				termination point (Place Of Delivery) of the Carrier�s transport
 * 				responsibily.
 * 				The supported modes are:
 * 				- SD: The Carrier provides 'end
 * 				to end' Container transport, from the
 * 				Place Of Receipt to the Place
 * 				Of Delivery
 * 				- CY: The Carrier provides Container transport from
 * 				(export) / to
 * 				(import) a container yard separate from the Customer's
 * 				premises
 * 				- CFS: The Carrier provides Container transport from / to a
 * 				Container
 * 				Freight Station. This mode is typically used in cases where
 * 				cargo
 * 				from / to multiple Customers is to be consolidated /
 * 				deconsolidated
 * 
 * 				- BB: Breakbulk (uncontainerised)
 * 				- CC: Conventional
 * 				Cargo (uncontainerised)
 * 
 * 				Business rules determining allowable
 * 				combinations of Receipt-Delivery Mode
 * 				for a Shipment at origin and
 * 				destination are not detailed here
 * 			
 * 
 * <p>Java class for Receipt-DeliveryModeStructure complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="Receipt-DeliveryModeStructure"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="ReceiptDeliveryCode" type="{http://services.apmoller.net/AMM/v4}String7NonNullType"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "Receipt-DeliveryModeStructure", propOrder = {
    "receiptDeliveryCode"
})
public class ReceiptDeliveryModeStructure {

    @XmlElement(name = "ReceiptDeliveryCode", required = true)
    protected String receiptDeliveryCode;

    /**
     * Gets the value of the receiptDeliveryCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getReceiptDeliveryCode() {
        return receiptDeliveryCode;
    }

    /**
     * Sets the value of the receiptDeliveryCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setReceiptDeliveryCode(String value) {
        this.receiptDeliveryCode = value;
    }

}
