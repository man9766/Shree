
package com.apmoller.main.model.request;

import java.math.BigDecimal;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for LinkCostStructure complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="LinkCostStructure"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="CostAmount" type="{http://services.apmoller.net/AMM/v4}Decimal18d4Type" minOccurs="0"/&gt;
 *         &lt;element name="CurrencyUnit" type="{http://services.apmoller.net/AMM/v4}CurrencyUnitStructure" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "LinkCostStructure", propOrder = {
    "costAmount",
    "currencyUnit"
})
public class LinkCostStructure {

    @XmlElement(name = "CostAmount")
    protected BigDecimal costAmount;
    @XmlElement(name = "CurrencyUnit")
    protected CurrencyUnitStructure currencyUnit;

    /**
     * Gets the value of the costAmount property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getCostAmount() {
        return costAmount;
    }

    /**
     * Sets the value of the costAmount property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setCostAmount(BigDecimal value) {
        this.costAmount = value;
    }

    /**
     * Gets the value of the currencyUnit property.
     * 
     * @return
     *     possible object is
     *     {@link CurrencyUnitStructure }
     *     
     */
    public CurrencyUnitStructure getCurrencyUnit() {
        return currencyUnit;
    }

    /**
     * Sets the value of the currencyUnit property.
     * 
     * @param value
     *     allowed object is
     *     {@link CurrencyUnitStructure }
     *     
     */
    public void setCurrencyUnit(CurrencyUnitStructure value) {
        this.currencyUnit = value;
    }

}
