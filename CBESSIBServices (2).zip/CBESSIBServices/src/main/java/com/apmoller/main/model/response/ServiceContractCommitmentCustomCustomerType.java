
package com.apmoller.main.model.response;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * This associative entity type resolves the manay to
 * 				many relationshipnship between Service Contract and Commitment.
 * 
 * 				A
 * 				Service Contract can have Zero to many Commitments both (in state
 * 				requested, Confirmed or Expired) with different charateristica as
 * 				Equipment Type, Cargo Type ect.
 * 
 * 				A Commitment is agreed for 1 to many
 * 				Service Contracts. Which means
 * 				that we can collect a total commitment
 * 				for more than 1 Service
 * 				Contract.
 * 
 * <p>Java class for ServiceContractCommitmentCustomCustomerType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ServiceContractCommitmentCustomCustomerType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="Concern" type="{http://services.apmoller.net/AMM/v4}CustomerCustomCodeType" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ServiceContractCommitmentCustomCustomerType", propOrder = {
    "concern"
})
public class ServiceContractCommitmentCustomCustomerType {

    @XmlElement(name = "Concern")
    protected CustomerCustomCodeType concern;

    /**
     * Gets the value of the concern property.
     * 
     * @return
     *     possible object is
     *     {@link CustomerCustomCodeType }
     *     
     */
    public CustomerCustomCodeType getConcern() {
        return concern;
    }

    /**
     * Sets the value of the concern property.
     * 
     * @param value
     *     allowed object is
     *     {@link CustomerCustomCodeType }
     *     
     */
    public void setConcern(CustomerCustomCodeType value) {
        this.concern = value;
    }

}
