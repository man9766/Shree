
package com.apmoller.main.model.response;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * Information about transport between two Shipment
 * 				Route Points, OR, about Pre Carriage transport to the Place of
 * 				Receipt (first Shipment Route Point) or On-Carriage transport from
 * 				the Place of Delivery (last Shipment Route Point).
 * 				In the case of
 * 				Pre-Carriage / On-Carriage, there is only one
 * 				associated Shipment
 * 				Route Point.
 * 
 * 				The transport information can include:
 * 				- Start Shipment
 * 				Route Point
 * 				- End Shipment Route Point
 * 				- Expected Arrival Time
 * 				-
 * 				Expected Departure Time
 * 				- Transport Mode
 * 				- Voyage Number
 * 				- Vessel Block
 * 				Stowage Code
 * 
 * 
 * 
 * <p>Java class for ShipmentRouteLinkCustomSteeredLegType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ShipmentRouteLinkCustomSteeredLegType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="Arrival" type="{http://services.apmoller.net/AMM/v4}DatedVoyageCustomType"/&gt;
 *         &lt;element name="End" type="{http://services.apmoller.net/AMM/v4}ShipmentRoutePointStructure"/&gt;
 *         &lt;element name="Start" type="{http://services.apmoller.net/AMM/v4}ShipmentRoutePointStructure"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ShipmentRouteLinkCustomSteeredLegType", propOrder = {
    "arrival",
    "end",
    "start"
})
public class ShipmentRouteLinkCustomSteeredLegType {

    @XmlElement(name = "Arrival", required = true)
    protected DatedVoyageCustomType arrival;
    @XmlElement(name = "End", required = true)
    protected ShipmentRoutePointStructure end;
    @XmlElement(name = "Start", required = true)
    protected ShipmentRoutePointStructure start;

    /**
     * Gets the value of the arrival property.
     * 
     * @return
     *     possible object is
     *     {@link DatedVoyageCustomType }
     *     
     */
    public DatedVoyageCustomType getArrival() {
        return arrival;
    }

    /**
     * Sets the value of the arrival property.
     * 
     * @param value
     *     allowed object is
     *     {@link DatedVoyageCustomType }
     *     
     */
    public void setArrival(DatedVoyageCustomType value) {
        this.arrival = value;
    }

    /**
     * Gets the value of the end property.
     * 
     * @return
     *     possible object is
     *     {@link ShipmentRoutePointStructure }
     *     
     */
    public ShipmentRoutePointStructure getEnd() {
        return end;
    }

    /**
     * Sets the value of the end property.
     * 
     * @param value
     *     allowed object is
     *     {@link ShipmentRoutePointStructure }
     *     
     */
    public void setEnd(ShipmentRoutePointStructure value) {
        this.end = value;
    }

    /**
     * Gets the value of the start property.
     * 
     * @return
     *     possible object is
     *     {@link ShipmentRoutePointStructure }
     *     
     */
    public ShipmentRoutePointStructure getStart() {
        return start;
    }

    /**
     * Sets the value of the start property.
     * 
     * @param value
     *     allowed object is
     *     {@link ShipmentRoutePointStructure }
     *     
     */
    public void setStart(ShipmentRoutePointStructure value) {
        this.start = value;
    }

}
