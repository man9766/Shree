
package com.apmoller.main.model.request;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * A Party with an interest in a Shipment.
 * 
 * 				Excludes
 * 				Organisational Units within the Enterprise responsible for handling
 * 				or approval of the shipment
 * 
 * 
 * <p>Java class for ShipmentPartyStructure complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ShipmentPartyStructure"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="ShipmentPartyRole" type="{http://services.apmoller.net/AMM/v4}ShipmentPartyRoleStructure" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ShipmentPartyStructure", propOrder = {
    "shipmentPartyRole"
})
public class ShipmentPartyStructure {

    @XmlElement(name = "ShipmentPartyRole")
    protected ShipmentPartyRoleStructure shipmentPartyRole;

    /**
     * Gets the value of the shipmentPartyRole property.
     * 
     * @return
     *     possible object is
     *     {@link ShipmentPartyRoleStructure }
     *     
     */
    public ShipmentPartyRoleStructure getShipmentPartyRole() {
        return shipmentPartyRole;
    }

    /**
     * Sets the value of the shipmentPartyRole property.
     * 
     * @param value
     *     allowed object is
     *     {@link ShipmentPartyRoleStructure }
     *     
     */
    public void setShipmentPartyRole(ShipmentPartyRoleStructure value) {
        this.shipmentPartyRole = value;
    }

}
