
package com.apmoller.main.model.request;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * A carrier (aka. Common Carrier) is a person or
 * 				company that transports goods or people for any person or company
 * 				and that is responsible for any possible loss of the goods during
 * 				transport.
 * 				The carrier does not necessarily have to own or even be in
 * 				the
 * 				possession of a means of transport. Unless otherwise agreed upon
 * 				in
 * 				the contract, the carrier may use whatever means of transport
 * 				approved in its operating authority, as long as it is the most
 * 				favourable from the cargo interests� point of view. The carriers'
 * 				duty is to get the goods to the agreed destination within the agreed
 * 				time or within reasonable time.
 * 				An NVOCC (Non Vessel Operating Common
 * 				Carrier) is a common carrier
 * 				that holds itself out to the public to
 * 				provide ocean transportation,
 * 				issues its own house bills of lading or
 * 				equivalent document, but
 * 				does not operate the vessels by which ocean
 * 				transportation is
 * 				provided (e.g DB Schencker SCAC code DBSC, DAMCO
 * 				scac code DMCQ).
 * 				The NVOCC accepts the liabilities of a carrier in
 * 				certain cases. The
 * 				freight forwarder does not accept the liabilities
 * 				of a carrier in
 * 				any case.
 * 				The Standard Carrier Alpha Code (SCAC) is a
 * 				unique code used to
 * 				identify transportation companies, e.g. MAEU for
 * 				Maersk Line, SAFM
 * 				for SafMarine, MCPU for MCC Transport etc.
 * 			
 * 
 * <p>Java class for CarrierStructure complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="CarrierStructure"&gt;
 *   &lt;complexContent&gt;
 *     &lt;extension base="{http://services.apmoller.net/AMM/v4}PartyRoleStructure"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="StandardCarrierAlphaCd" type="{http://services.apmoller.net/AMM/v4}String50NonNullType" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/extension&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "CarrierStructure", propOrder = {
    "standardCarrierAlphaCd"
})
public class CarrierStructure
    extends PartyRoleStructure
{

    @XmlElement(name = "StandardCarrierAlphaCd")
    protected String standardCarrierAlphaCd;

    /**
     * Gets the value of the standardCarrierAlphaCd property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getStandardCarrierAlphaCd() {
        return standardCarrierAlphaCd;
    }

    /**
     * Sets the value of the standardCarrierAlphaCd property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setStandardCarrierAlphaCd(String value) {
        this.standardCarrierAlphaCd = value;
    }

}
