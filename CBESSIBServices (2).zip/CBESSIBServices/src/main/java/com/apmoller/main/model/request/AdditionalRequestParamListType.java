
package com.apmoller.main.model.request;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for AdditionalRequestParamListType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="AdditionalRequestParamListType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="RequestParameter" type="{http://services.apmoller.net/AMM/v4}AdditionalRequestParameterType" maxOccurs="unbounded" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
/*
*/
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "AdditionalRequestParamListType", propOrder = {
    "requestParameter"
})
public class AdditionalRequestParamListType implements Serializable {

    @XmlElement(name = "RequestParameter")
    protected List<AdditionalRequestParameterType> requestParameter;

    /**
     * Gets the value of the requestParameter property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the requestParameter property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getRequestParameter().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link AdditionalRequestParameterType }
     * 
     * 
     */
    public List<AdditionalRequestParameterType> getRequestParameter() {
        if (requestParameter == null) {
            requestParameter = new ArrayList<AdditionalRequestParameterType>();
        }
        return this.requestParameter;
    }

}
