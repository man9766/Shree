
package com.apmoller.main.model.request;

import java.math.BigInteger;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * When we promise / commit to a customer to that
 * 				there will be space available on a vessel either on weekly basis
 * 				(regular) or as a total number of FFE with a weekly limit
 * 				(Irreglular)
 * 
 * <p>Java class for CommitmentCustomIdType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="CommitmentCustomIdType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="CommitmentId" type="{http://services.apmoller.net/AMM/v4}Integer20Type"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "CommitmentCustomIdType", propOrder = {
    "commitmentId"
})
public class CommitmentCustomIdType {

    @XmlElement(name = "CommitmentId", required = true)
    protected BigInteger commitmentId;

    /**
     * Gets the value of the commitmentId property.
     * 
     * @return
     *     possible object is
     *     {@link BigInteger }
     *     
     */
    public BigInteger getCommitmentId() {
        return commitmentId;
    }

    /**
     * Sets the value of the commitmentId property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigInteger }
     *     
     */
    public void setCommitmentId(BigInteger value) {
        this.commitmentId = value;
    }

}
