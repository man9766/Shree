
package com.apmoller.main.model.request;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSeeAlso;
import javax.xml.bind.annotation.XmlType;


/**
 * An item of equipment. Examples include:
 * 				-
 * 				Containers
 * 				- Ancilliary equipment such as Gensets, Chassis
 * 				Candidate
 * 				attributes (some generic, others mandated by the requirements of an
 * 				attached RCD device) include:
 * 
 * 				- Equipment Empty/Utilised indicator
 * 				-
 * 				Usability Status (available or not available)
 * 				- Equipment number
 * 				(including prefix and check-digit)
 * 				- Equipment Type
 * 				- Equipment
 * 				Sub-Type
 * 				- 'ISO' Code
 * 				- Reefer Type
 * 				- Equipment Profile id
 * 				- In/out
 * 				fleet status
 * 				- Equipment into fleet date/time
 * 				- Equipment into fleet
 * 				location
 * 				- Leasing Company Information
 * 				- CSC-inspection location
 * 				- CSC
 * 				inspection date
 * 				- Next CSC inspection date
 * 				- Refurbishment date
 * 				-
 * 				Equipment modification information
 * 				- Chassis Licence Number
 * 			
 * 
 * <p>Java class for EquipmentCustomContType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="EquipmentCustomContType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;extension base="{http://services.apmoller.net/AMM/v4}AssetCustomEmptyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="ContainerProfile" type="{http://services.apmoller.net/AMM/v4}ContainerProfileStructure"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/extension&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "EquipmentCustomContType", propOrder = {
    "containerProfile"
})
@XmlSeeAlso({
    ContainerCustomIdType.class
})
public class EquipmentCustomContType
    extends AssetCustomEmptyType
{

    @XmlElement(name = "ContainerProfile", required = true)
    protected ContainerProfileStructure containerProfile;

    /**
     * Gets the value of the containerProfile property.
     * 
     * @return
     *     possible object is
     *     {@link ContainerProfileStructure }
     *     
     */
    public ContainerProfileStructure getContainerProfile() {
        return containerProfile;
    }

    /**
     * Sets the value of the containerProfile property.
     * 
     * @param value
     *     allowed object is
     *     {@link ContainerProfileStructure }
     *     
     */
    public void setContainerProfile(ContainerProfileStructure value) {
        this.containerProfile = value;
    }

}
