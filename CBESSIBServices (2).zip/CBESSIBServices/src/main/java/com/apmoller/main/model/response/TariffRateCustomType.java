
package com.apmoller.main.model.response;

import java.math.BigDecimal;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * The calculation basis for the tariff rate for a
 * 				specific Transport Leg
 * 
 * 
 * <p>Java class for TariffRateCustomType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="TariffRateCustomType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="CountryCurrency" type="{http://services.apmoller.net/AMM/v4}CountryCurrencyStructure"/&gt;
 *         &lt;element name="TariffRateValue" type="{http://services.apmoller.net/AMM/v4}Decimal18d4WithNegativeType"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "TariffRateCustomType", propOrder = {
    "countryCurrency",
    "tariffRateValue"
})
public class TariffRateCustomType {

    @XmlElement(name = "CountryCurrency", required = true)
    protected CountryCurrencyStructure countryCurrency;
    @XmlElement(name = "TariffRateValue", required = true)
    protected BigDecimal tariffRateValue;

    /**
     * Gets the value of the countryCurrency property.
     * 
     * @return
     *     possible object is
     *     {@link CountryCurrencyStructure }
     *     
     */
    public CountryCurrencyStructure getCountryCurrency() {
        return countryCurrency;
    }

    /**
     * Sets the value of the countryCurrency property.
     * 
     * @param value
     *     allowed object is
     *     {@link CountryCurrencyStructure }
     *     
     */
    public void setCountryCurrency(CountryCurrencyStructure value) {
        this.countryCurrency = value;
    }

    /**
     * Gets the value of the tariffRateValue property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getTariffRateValue() {
        return tariffRateValue;
    }

    /**
     * Sets the value of the tariffRateValue property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setTariffRateValue(BigDecimal value) {
        this.tariffRateValue = value;
    }

}
