
package com.apmoller.main.model.request;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for ShipmentPartyRolesType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ShipmentPartyRolesType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="BookedByCustomer" type="{http://services.apmoller.net/AMM/v4}ShipmentPartyStructure" minOccurs="0"/&gt;
 *         &lt;element name="ContractualCustomer" type="{http://services.apmoller.net/AMM/v4}ShipmentPartyStructure" minOccurs="0"/&gt;
 *         &lt;element name="InwardForwarder" type="{http://services.apmoller.net/AMM/v4}ShipmentPartyStructure" minOccurs="0"/&gt;
 *         &lt;element name="NamedAccountProductCustomer" type="{http://services.apmoller.net/AMM/v4}ShipmentPartyStructure" minOccurs="0"/&gt;
 *         &lt;element name="OutwardForwarder" type="{http://services.apmoller.net/AMM/v4}ShipmentPartyStructure" minOccurs="0"/&gt;
 *         &lt;element name="Shipper" type="{http://services.apmoller.net/AMM/v4}ShipmentPartyStructure" minOccurs="0"/&gt;
 *         &lt;element name="PriceOwner" type="{http://services.apmoller.net/AMM/v4}ShipmentPartyStructure" minOccurs="0"/&gt;
 *         &lt;element name="NamedAccountCustomer" type="{http://services.apmoller.net/AMM/v4}ShipmentPartyStructure" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ShipmentPartyRolesType", propOrder = {
    "bookedByCustomer",
    "contractualCustomer",
    "inwardForwarder",
    "namedAccountProductCustomer",
    "outwardForwarder",
    "shipper",
    "priceOwner",
    "namedAccountCustomer"
})
public class ShipmentPartyRolesType {

    @XmlElement(name = "BookedByCustomer")
    protected ShipmentPartyStructure bookedByCustomer;
    @XmlElement(name = "ContractualCustomer")
    protected ShipmentPartyStructure contractualCustomer;
    @XmlElement(name = "InwardForwarder")
    protected ShipmentPartyStructure inwardForwarder;
    @XmlElement(name = "NamedAccountProductCustomer")
    protected ShipmentPartyStructure namedAccountProductCustomer;
    @XmlElement(name = "OutwardForwarder")
    protected ShipmentPartyStructure outwardForwarder;
    @XmlElement(name = "Shipper")
    protected ShipmentPartyStructure shipper;
    @XmlElement(name = "PriceOwner")
    protected ShipmentPartyStructure priceOwner;
    @XmlElement(name = "NamedAccountCustomer")
    protected ShipmentPartyStructure namedAccountCustomer;

    /**
     * Gets the value of the bookedByCustomer property.
     * 
     * @return
     *     possible object is
     *     {@link ShipmentPartyStructure }
     *     
     */
    public ShipmentPartyStructure getBookedByCustomer() {
        return bookedByCustomer;
    }

    /**
     * Sets the value of the bookedByCustomer property.
     * 
     * @param value
     *     allowed object is
     *     {@link ShipmentPartyStructure }
     *     
     */
    public void setBookedByCustomer(ShipmentPartyStructure value) {
        this.bookedByCustomer = value;
    }

    /**
     * Gets the value of the contractualCustomer property.
     * 
     * @return
     *     possible object is
     *     {@link ShipmentPartyStructure }
     *     
     */
    public ShipmentPartyStructure getContractualCustomer() {
        return contractualCustomer;
    }

    /**
     * Sets the value of the contractualCustomer property.
     * 
     * @param value
     *     allowed object is
     *     {@link ShipmentPartyStructure }
     *     
     */
    public void setContractualCustomer(ShipmentPartyStructure value) {
        this.contractualCustomer = value;
    }

    /**
     * Gets the value of the inwardForwarder property.
     * 
     * @return
     *     possible object is
     *     {@link ShipmentPartyStructure }
     *     
     */
    public ShipmentPartyStructure getInwardForwarder() {
        return inwardForwarder;
    }

    /**
     * Sets the value of the inwardForwarder property.
     * 
     * @param value
     *     allowed object is
     *     {@link ShipmentPartyStructure }
     *     
     */
    public void setInwardForwarder(ShipmentPartyStructure value) {
        this.inwardForwarder = value;
    }

    /**
     * Gets the value of the namedAccountProductCustomer property.
     * 
     * @return
     *     possible object is
     *     {@link ShipmentPartyStructure }
     *     
     */
    public ShipmentPartyStructure getNamedAccountProductCustomer() {
        return namedAccountProductCustomer;
    }

    /**
     * Sets the value of the namedAccountProductCustomer property.
     * 
     * @param value
     *     allowed object is
     *     {@link ShipmentPartyStructure }
     *     
     */
    public void setNamedAccountProductCustomer(ShipmentPartyStructure value) {
        this.namedAccountProductCustomer = value;
    }

    /**
     * Gets the value of the outwardForwarder property.
     * 
     * @return
     *     possible object is
     *     {@link ShipmentPartyStructure }
     *     
     */
    public ShipmentPartyStructure getOutwardForwarder() {
        return outwardForwarder;
    }

    /**
     * Sets the value of the outwardForwarder property.
     * 
     * @param value
     *     allowed object is
     *     {@link ShipmentPartyStructure }
     *     
     */
    public void setOutwardForwarder(ShipmentPartyStructure value) {
        this.outwardForwarder = value;
    }

    /**
     * Gets the value of the shipper property.
     * 
     * @return
     *     possible object is
     *     {@link ShipmentPartyStructure }
     *     
     */
    public ShipmentPartyStructure getShipper() {
        return shipper;
    }

    /**
     * Sets the value of the shipper property.
     * 
     * @param value
     *     allowed object is
     *     {@link ShipmentPartyStructure }
     *     
     */
    public void setShipper(ShipmentPartyStructure value) {
        this.shipper = value;
    }

    /**
     * Gets the value of the priceOwner property.
     * 
     * @return
     *     possible object is
     *     {@link ShipmentPartyStructure }
     *     
     */
    public ShipmentPartyStructure getPriceOwner() {
        return priceOwner;
    }

    /**
     * Sets the value of the priceOwner property.
     * 
     * @param value
     *     allowed object is
     *     {@link ShipmentPartyStructure }
     *     
     */
    public void setPriceOwner(ShipmentPartyStructure value) {
        this.priceOwner = value;
    }

    /**
     * Gets the value of the namedAccountCustomer property.
     * 
     * @return
     *     possible object is
     *     {@link ShipmentPartyStructure }
     *     
     */
    public ShipmentPartyStructure getNamedAccountCustomer() {
        return namedAccountCustomer;
    }

    /**
     * Sets the value of the namedAccountCustomer property.
     * 
     * @param value
     *     allowed object is
     *     {@link ShipmentPartyStructure }
     *     
     */
    public void setNamedAccountCustomer(ShipmentPartyStructure value) {
        this.namedAccountCustomer = value;
    }

}
