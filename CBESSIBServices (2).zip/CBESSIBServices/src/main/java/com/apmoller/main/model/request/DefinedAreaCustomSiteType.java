
package com.apmoller.main.model.request;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSeeAlso;
import javax.xml.bind.annotation.XmlType;


/**
 * The supertype entity to all geographic and other
 * 				kinds of areas such as Business Defined Areas (which still have a
 * 				geographic aspect to their definition). Some areas are 'point', have
 * 				specific geographical coordinates (e.g. the "city Centre" point)
 * 				while other have a geographic boundary (defined perimeter) enclosing
 * 				an area such as a Continent, Country, City or Site.
 * 			
 * 
 * <p>Java class for DefinedAreaCustomSiteType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="DefinedAreaCustomSiteType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="SiteCode" type="{http://services.apmoller.net/AMM/v4}AlternativeCodeCustomString8Type"/&gt;
 *         &lt;element name="GeoID" type="{http://services.apmoller.net/AMM/v4}AlternativeCodeStructure" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "DefinedAreaCustomSiteType", propOrder = {
    "siteCode",
    "geoID"
})
@XmlSeeAlso({
    SiteStructure.class
})
public class DefinedAreaCustomSiteType {

    @XmlElement(name = "SiteCode", required = true)
    protected AlternativeCodeCustomString8Type siteCode;
    @XmlElement(name = "GeoID")
    protected AlternativeCodeStructure geoID;

    /**
     * Gets the value of the siteCode property.
     * 
     * @return
     *     possible object is
     *     {@link AlternativeCodeCustomString8Type }
     *     
     */
    public AlternativeCodeCustomString8Type getSiteCode() {
        return siteCode;
    }

    /**
     * Sets the value of the siteCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link AlternativeCodeCustomString8Type }
     *     
     */
    public void setSiteCode(AlternativeCodeCustomString8Type value) {
        this.siteCode = value;
    }

    /**
     * Gets the value of the geoID property.
     * 
     * @return
     *     possible object is
     *     {@link AlternativeCodeStructure }
     *     
     */
    public AlternativeCodeStructure getGeoID() {
        return geoID;
    }

    /**
     * Sets the value of the geoID property.
     * 
     * @param value
     *     allowed object is
     *     {@link AlternativeCodeStructure }
     *     
     */
    public void setGeoID(AlternativeCodeStructure value) {
        this.geoID = value;
    }

}
