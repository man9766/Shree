package com.apmoller.main.exception;

public class InvalidRequestException extends BaseException {
	
	
	public InvalidRequestException()
	{
		super(ErrorCodes.InvalidRequest);
	}

}
