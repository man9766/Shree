package com.apmoller.main.exception;

public class BusinessServiceLayerException extends Exception {

	private static final long serialVersionUID = 1L;
	private String errorMessage;
	
	
	public String getErrorMessage() {
		return errorMessage;
	}

	public BusinessServiceLayerException(String errorMessage) {
		super(errorMessage);
		this.errorMessage =errorMessage;
	}


	public BusinessServiceLayerException() {
		super();
		// TODO Auto-generated constructor stub
	}

}
