
package com.apmoller.main.model.response;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * A cargo characteristic that is relevant to
 * 				transport order execution. Each characteristic is also categorized
 * 				as either 'Standard' or 'Special'. Examples of Cargo Types and
 * 				Standard / Special categorizations are:
 * 				- Dry - (Standard)
 * 				- Live
 * 				Reefer (Special)
 * 				- Dangerous (often also referred to as Hazardous) -
 * 				(Special)
 * 				- Out Of Gauge (OOG) - (Special)
 * 				- Break Bulk - (Special)
 * 			
 * 
 * <p>Java class for CargoTypeStructure complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="CargoTypeStructure"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="CargoTypeCd" type="{http://services.apmoller.net/AMM/v4}String4NonNullType"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "CargoTypeStructure", propOrder = {
    "cargoTypeCd"
})
public class CargoTypeStructure {

    @XmlElement(name = "CargoTypeCd", required = true)
    protected String cargoTypeCd;

    /**
     * Gets the value of the cargoTypeCd property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCargoTypeCd() {
        return cargoTypeCd;
    }

    /**
     * Sets the value of the cargoTypeCd property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCargoTypeCd(String value) {
        this.cargoTypeCd = value;
    }

}
