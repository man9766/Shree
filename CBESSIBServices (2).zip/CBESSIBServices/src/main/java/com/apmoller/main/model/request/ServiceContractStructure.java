
package com.apmoller.main.model.request;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * Specific Number representing An actual, requested
 * 				or proposed agreement between a Carrier and a Customer for cargo
 * 				transport services.
 * 				Specifies:
 * 				- charge rates,
 * 				- cargo volume,
 * 				- service
 * 				level
 * 				to be provided by the Carrier, and a contract validity period.
 * 
 * 				A Service Contract can identify Affiliate Customer Organisations
 * 				that
 * 				can be parties to Shipments moved under the contract.
 * 			
 * 
 * <p>Java class for ServiceContractStructure complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ServiceContractStructure"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="ServiceContractNumber" type="{http://services.apmoller.net/AMM/v4}String9NonNullType"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ServiceContractStructure", propOrder = {
    "serviceContractNumber"
})
public class ServiceContractStructure {

    @XmlElement(name = "ServiceContractNumber", required = true)
    protected String serviceContractNumber;

    /**
     * Gets the value of the serviceContractNumber property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getServiceContractNumber() {
        return serviceContractNumber;
    }

    /**
     * Sets the value of the serviceContractNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setServiceContractNumber(String value) {
        this.serviceContractNumber = value;
    }

}
