
package com.apmoller.main.model.request;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * Holds the valid possible combinations of height
 * 				and width of a container.
 * 				Some type dont't have a fixed value but can
 * 				be in a range or just >=
 * 				greater or equal to.
 * 
 * 				Permitted Values in
 * 				inches:
 * 
 * 				Height Width
 * 				<=4" 8
 * 				4"3 8
 * 				8 8
 * 				8"6 8
 * 				8"6 >8"2
 * 				8"6 8/8"2
 * 				9 8/8"2
 * 				9"6 8
 * 				9"6 >8"2
 * 				9"6 8/8"2
 * 				>9"6 8
 * 
 * <p>Java class for ISOContainerHeightStructure complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ISOContainerHeightStructure"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="ISOContainerHeightCd" type="{http://services.apmoller.net/AMM/v4}String5NonNullType"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ISOContainerHeightStructure", propOrder = {
    "isoContainerHeightCd"
})
public class ISOContainerHeightStructure {

    @XmlElement(name = "ISOContainerHeightCd", required = true)
    protected String isoContainerHeightCd;

    /**
     * Gets the value of the isoContainerHeightCd property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getISOContainerHeightCd() {
        return isoContainerHeightCd;
    }

    /**
     * Sets the value of the isoContainerHeightCd property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setISOContainerHeightCd(String value) {
        this.isoContainerHeightCd = value;
    }

}
