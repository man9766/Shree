package com.apmoller.main.exception;

public class DaoAccessException extends BaseException {

	public DaoAccessException() {
		super(ErrorCodes.DataAccessException);
		// TODO Auto-generated constructor stub
	}

}
