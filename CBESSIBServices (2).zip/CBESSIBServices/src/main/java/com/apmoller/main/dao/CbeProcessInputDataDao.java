/*package com.apmoller.main.dao;



import java.util.List;

import org.springframework.stereotype.Component;

import com.apmoller.main.model.RequestData;
import com.apmoller.main.model.ResponseData;

@Component
public interface CbeProcessInputDataDao  {

	public ResponseData processInputData(RequestData addDetails) throws Exception;
	public List<RequestData> processInputDataRequest(String operator);
}
*/