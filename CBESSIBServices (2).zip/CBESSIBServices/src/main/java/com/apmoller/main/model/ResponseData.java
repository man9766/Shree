package com.apmoller.main.model;

import java.io.Serializable;

public class ResponseData implements Serializable {
	String message;
	String responseCode;

	public ResponseData() {
		super();
	}

	public ResponseData(String message, String responseCode) {
		super();
		this.message = message;
		this.responseCode = responseCode;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public String getResponseCode() {
		return responseCode;
	}

	public void setResponseCode(String responseCode) {
		this.responseCode = responseCode;
	}

	@Override
	public String toString() {
		return "ResponseData [message=" + message + ", responseCode="
				+ responseCode + "]";
	}

}
