
package com.apmoller.main.model.response;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;


/**
 * A buyer (or potential buyer) of a Product offered
 * 				by the Enterprise. A Customer may be an Organisation or a Person
 * 				acting on behalf of an Organisation.
 * 				Exclusion: A buyer of an Asset
 * 				is not a Customer
 * 
 * <p>Java class for CustomerCustomCodeType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="CustomerCustomCodeType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;extension base="{http://services.apmoller.net/AMM/v4}PartyRoleStructure"&gt;
 *     &lt;/extension&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "CustomerCustomCodeType")
public class CustomerCustomCodeType
    extends PartyRoleStructure
{


}
