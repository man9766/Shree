
package com.apmoller.main.model.request;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlSeeAlso;
import javax.xml.bind.annotation.XmlType;


/**
 * Data about items of value or usefulness owned by
 * 				Parties.
 * 				Includes items used in executing the Enterprise's business,
 * 				such as Vessels
 * 				and Containers, and the characteristics of these
 * 				items.
 * 				Also includes Cash, and nontangible Assets such as trademarks,
 * 				patents,
 * 				copyrights and goodwill.
 * 
 * 				Something - either tangible (e.g. a
 * 				Vessel, a Container, or a Crane) or
 * 				intangible (eg a service or an IT
 * 				asset) - with a value to the
 * 				Enterprise which is owned by the
 * 				Enterprise, regardless of what that
 * 				Asset might be.
 * 				This entity is
 * 				used as an all-purpose link to more specific entities
 * 				within the
 * 				Asset data domain.
 * 
 * 				An item of value or usefulness owned by a Party or
 * 				Parties.
 * 				Asset is the supertype of all entity types that represent
 * 				assets of
 * 				various kinds (eg Equipment, Facility...)
 * 
 * 				Example attributes
 * 				include
 * 				- Asset Value
 * 
 * <p>Java class for AssetCustomEmptyType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="AssetCustomEmptyType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "AssetCustomEmptyType")
@XmlSeeAlso({
    EquipmentCustomContType.class
})
public class AssetCustomEmptyType {


}
