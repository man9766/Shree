
package com.apmoller.main.model.request;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * A shipping container registered by the enterprise,
 * 				this could e.g. be a normal standard dry 40' container or a 20' tank
 * 				container.
 * 
 * <p>Java class for ContainerCustomIdType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ContainerCustomIdType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;extension base="{http://services.apmoller.net/AMM/v4}EquipmentCustomContType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="ISOSerialNum" type="{http://services.apmoller.net/AMM/v4}String13NonNullType"/&gt;
 *         &lt;element name="DangerousCharacteristics" type="{http://services.apmoller.net/AMM/v4}DangerousCharacteristicsCustomTBProdType" maxOccurs="unbounded" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/extension&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ContainerCustomIdType", propOrder = {
    "isoSerialNum",
    "dangerousCharacteristics"
})
public class ContainerCustomIdType
    extends EquipmentCustomContType
{

    @XmlElement(name = "ISOSerialNum", required = true)
    protected String isoSerialNum;
    @XmlElement(name = "DangerousCharacteristics")
    protected List<DangerousCharacteristicsCustomTBProdType> dangerousCharacteristics;

    /**
     * Gets the value of the isoSerialNum property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getISOSerialNum() {
        return isoSerialNum;
    }

    /**
     * Sets the value of the isoSerialNum property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setISOSerialNum(String value) {
        this.isoSerialNum = value;
    }

    /**
     * Gets the value of the dangerousCharacteristics property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the dangerousCharacteristics property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getDangerousCharacteristics().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link DangerousCharacteristicsCustomTBProdType }
     * 
     * 
     */
    public List<DangerousCharacteristicsCustomTBProdType> getDangerousCharacteristics() {
        if (dangerousCharacteristics == null) {
            dangerousCharacteristics = new ArrayList<DangerousCharacteristicsCustomTBProdType>();
        }
        return this.dangerousCharacteristics;
    }

}
