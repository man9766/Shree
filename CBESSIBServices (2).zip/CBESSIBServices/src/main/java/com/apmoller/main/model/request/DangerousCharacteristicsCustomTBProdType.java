
package com.apmoller.main.model.request;

import java.math.BigInteger;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for DangerousCharacteristicsCustomTBProdType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="DangerousCharacteristicsCustomTBProdType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="UnGroup" type="{http://services.apmoller.net/AMM/v4}Integer6Type" minOccurs="0"/&gt;
 *         &lt;element name="IMOClass" type="{http://services.apmoller.net/AMM/v4}String6NonNullType" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "DangerousCharacteristicsCustomTBProdType", propOrder = {
    "unGroup",
    "imoClass"
})
public class DangerousCharacteristicsCustomTBProdType {

    @XmlElement(name = "UnGroup")
    protected BigInteger unGroup;
    @XmlElement(name = "IMOClass")
    protected String imoClass;

    /**
     * Gets the value of the unGroup property.
     * 
     * @return
     *     possible object is
     *     {@link BigInteger }
     *     
     */
    public BigInteger getUnGroup() {
        return unGroup;
    }

    /**
     * Sets the value of the unGroup property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigInteger }
     *     
     */
    public void setUnGroup(BigInteger value) {
        this.unGroup = value;
    }

    /**
     * Gets the value of the imoClass property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getIMOClass() {
        return imoClass;
    }

    /**
     * Sets the value of the imoClass property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setIMOClass(String value) {
        this.imoClass = value;
    }

}
