/*package com.apmoller.main.test;




import static org.junit.Assert.assertEquals;

import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import com.apmoller.main.dao.impl.CbeProcessInputDataDaoImpl;
import com.apmoller.main.model.RequestData;
import com.apmoller.main.model.ResponseData;
import com.apmoller.main.service.CbeProcessInputDataService;
import com.apmoller.main.service.impl.CbeProcessInputDataServiceImpl;




public class CbeProcessInputDataServiceTEST {

	@Autowired
	CbeProcessInputDataService serviceImplObj;
	
	@Autowired
	ResponseData responseData;
	
	@Autowired
	RequestData requestData;
	
	
	
	
	
	
	@Test
	public void test_process_Input_Data_TEST() {
		ResponseData responseData =  new ResponseData();
		RequestData requestData = new RequestData();
		responseData.setMessage("Request has been processed Successfully with out Database Service!!");
		responseData.setResponseCode("SUCCESS00");
		
		
		requestData.setBookedbycustomercd("ABC");
		requestData.setContractualcustomercd("ABC");
		requestData.setEndsitecode("ABC");
		requestData.setOperater("ABC");
		requestData.setPriceownercd("ABC");
		requestData.setShipmentid("ABC");
		requestData.setShippercd("ABC");
		requestData.setStartsitecode("ABC");
		
		
		
		CbeProcessInputDataDaoImpl mockito = mock(CbeProcessInputDataDaoImpl.class);
		when(mockito.processInputData(requestData)).thenReturn(responseData);
		
		CbeProcessInputDataServiceImpl serviceImplObj = new CbeProcessInputDataServiceImpl();
		serviceImplObj.setCbeProcessInputDataDao(mockito);
		
		ResponseData responseDataOutput  = serviceImplObj.processInputData(requestData);
		assertEquals(responseDataOutput.getResponseCode(), "SUCCESS00");
	
		
	}

	
	

	@Test
	public void test_process_Input_Data() {
		ResponseData responseData;
		RequestData requestData = new RequestData();
		
		requestData.setBookedByCustomerCd("ABC");
		requestData.setContractualCustomerCd("ABC");
		requestData.setEndSiteCode("ABC");
		requestData.setOperater("ABC");
		requestData.setPriceOwnerCd("ABC");
		requestData.setShipmentId("ABC");
		requestData.setShipperCd("ABC");
		requestData.setStartSiteCode("ABC");
		
		
		
		
		CbeProcessInputDataServiceImpl CbeProSerImpl = new CbeProcessInputDataServiceImpl();
		CbeProSerImpl.setCbeProcessInputDataDao(new MockCbeProcessInputDataDaoImpl());
		
		responseData = CbeProSerImpl.processInputData(requestData);
		System.out.println(responseData.getMessage());
		System.out.println(responseData.getResponseCode());
		
		
	}

	
	
	
	@Test
	public void test_process_Input_Data_TESTDB() {
		ResponseData responseData =  new ResponseData();
		RequestData requestData = new RequestData();
		//responseData.setMessage("Request has been processed Successfully!!");
		//responseData.setResponseCode("SUCCESS00");
		
		requestData.setBookedbycustomercd("ABC");
		requestData.setContractualcustomercd("ABC");
		requestData.setEndsitecode("ABC");
		requestData.setOperater("ABC");
		requestData.setPriceownercd("ABC");
		requestData.setShipmentid("ABC");
		requestData.setShippercd("ABC");
		requestData.setStartsitecode("ABC");		
		
		
		
			
		responseData  = serviceImplObj.processInputData(requestData);
		assertEquals(responseData.getResponseCode(), "SUCCESS00");
	
		
	}
	
	
}
*/