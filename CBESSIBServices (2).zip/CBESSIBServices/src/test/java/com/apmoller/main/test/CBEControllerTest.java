package com.apmoller.main.test;



import com.apmoller.main.controller.CBEController;


import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.io.Reader;
import java.nio.charset.Charset;

import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.DefaultHttpClient;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;



@RunWith(SpringJUnit4ClassRunner.class)
//@ContextConfiguration("classpath:test-servlet-context.xml")
public class CBEControllerTest {
	public static final MediaType APPLICATION_JSON_UTF8 = new MediaType(
			MediaType.TEXT_XML.getType(),
			MediaType.TEXT_XML.getSubtype(), Charset.forName("utf8"));

	private final String EMPLOYEE_REQUEST = "{\"name\" : \"ename\"}";
	
	
	private MockMvc mockMvc;
	
	String xml2String ;

	/*@Autowired
	private CBEController cbeController;
*/
	@Before
	public void setup() throws IOException {
		
		File xmlFile = new File("D:\\MAERSK\\CBE\\JavaClasses\\XML_Service\\src\\test\\resources\\info.xml"); // Let's get XML file as String using BufferedReader
		// FileReader uses platform's default character encoding
		// if you need to specify a different encoding, use InputStreamReader
		Reader fileReader = new FileReader(xmlFile); 
		BufferedReader bufReader = new BufferedReader(fileReader); 
		StringBuilder sb = new StringBuilder();
		String line = bufReader.readLine();
		while( line != null)
		{ 
			sb.append(line).append("\n");
			line = bufReader.readLine();
			}
		xml2String = sb.toString();

		
	}

	@Test
	public void shouldSaveEmployee() throws Exception {
		CBEController cbeController =  new CBEController();
		/*this.mockMvc = MockMvcBuilders.standaloneSetup(cbeController)
				.build();
		this.mockMvc
				.perform(
						post("/processXMLrequest/").content(xml2String)
								.contentType(APPLICATION_JSON_UTF8).accept(APPLICATION_JSON_UTF8))
				.andExpect(status().isOk())
				.andExpect(jsonPath("$id", is("e1")))
				.andExpect(jsonPath("$name", is("ename")));*/
		
		
		DefaultHttpClient httpClient = new DefaultHttpClient();
		HttpPost postRequest = new HttpPost("http://localhost:8082/processXMLrequest");
		StringEntity input = new StringEntity(xml2String);
		input.setContentType("text/xml");
		postRequest.setEntity(input);
		CloseableHttpResponse response = httpClient.execute(postRequest);
		System.out.println("Test");
	}
	
	/*@Test
	public void shouldNotFindTheResource() throws Exception{
		this.mockMvc
		.perform(
				post("/employee/store/").content(EMPLOYEE_REQUEST)
						.contentType(APPLICATION_JSON_UTF8))
		.andExpect(status().is(404));
	}*/
}