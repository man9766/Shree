package com.tcs.eurekaClient.serviceController;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.client.discovery.DiscoveryClient;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;



@RestController
public class ServiceController {
	
	@Autowired
	DiscoveryClient discoveryClient;
	
	@Autowired
	RestTemplate rest;
	
	@RequestMapping(value="/getAsssetBalByID/{custId}", method=RequestMethod.GET)
	public String getAsssetBalById(@PathVariable(value="custId") String custId){
		String s=rest.getForObject("http://ASSETSERVICE/assetSummary/getAssetBalById/"+custId, String.class);
		return s;
	}
	
	@RequestMapping(value="/totalLoan&CreditAmntById/{custId}", method=RequestMethod.GET)
	public String getLiabilityBalById(@PathVariable(value="custId") String custId){
		String s=rest.getForObject("http://LIABILITYSERVICE/Loan/totalLoan&CreditAmntById/"+custId, String.class);
		return s;
	}
	
	
	
	@RequestMapping(value="/getBalance/{custId}", method=RequestMethod.GET)
	public String getBalance(@PathVariable(value="custId") String custId){
		String s=rest.getForObject("http://ACCOUNTSUMMARY/getAvailableBalance/"+custId, String.class);
		return s;
	}
	
	
	
	

}
