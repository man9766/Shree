package com.tcs.main.Controller;

import java.util.List;

import javax.websocket.server.PathParam;

import org.apache.catalina.authenticator.SavedRequest;


import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.tcs.main.dao.AssetRepository;
import com.tcs.main.model.AssetDetails;

@RestController

public class AssetController {
	
	//private static final Logger logger = LoggerFactory.getLogger(AssetController.class);
	
	
	
	
	@Autowired
	AssetRepository ur;
	
	@RequestMapping(value="/AddAssetDetails" ,method=RequestMethod.POST)
	public AssetDetails saveUsers(@RequestBody AssetDetails user)
	{
		System.out.println(user.toString());
		return ur.save(user);
	}

	
	@RequestMapping(value="/getAssetList",method=RequestMethod.GET)
	public List<AssetDetails> findAllUsers(){
		return ur.findAll();
		
	}
	
	@RequestMapping(value="/getAssetById/{custId}",method=RequestMethod.GET)
	public List<AssetDetails> getUserAccountDetails(@PathVariable(value="custId") int custId)
	{
		return ur.findBycustId(custId);
		
	}
	@RequestMapping(value="/updateAssetDetails" ,method=RequestMethod.PUT)
	public AssetDetails UpdateUsers(@RequestBody AssetDetails user)
	{
		System.out.println(user.toString());
		return ur.save(user);
	}
	@RequestMapping(value="/deleteAsset/{accNumber}",method=RequestMethod.DELETE)
	public void deleteUser( @PathVariable(value="accNumber")Integer accNumber)
	{
		System.out.println("AccountNo :**************"+accNumber);
		 ur.delete(accNumber);
	}
	
}
