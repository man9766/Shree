package com.tcs.main.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.data.repository.CrudRepository;

import com.tcs.main.model.AssetDetails;

@EnableJpaRepositories
public interface AssetRepository extends CrudRepository<AssetDetails,Integer> {
	
	AssetDetails save(AssetDetails user);
	
	List<AssetDetails> findAll();

	List<AssetDetails> findBycustId(int custId);
	
	void delete(Integer custId);
}
