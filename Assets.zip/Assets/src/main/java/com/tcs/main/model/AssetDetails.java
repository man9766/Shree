package com.tcs.main.model;

import java.sql.Timestamp;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
@Entity
@Table(name="ASSETS",schema="springboot")
public class AssetDetails {
	
	       int accNumber;
				 String		custId;
			 String	productName;
			 String	currencyCode;
			 int	interest;
			int productType;
			int productSubType;
			String status;
			Date openDate;
			Date closeDate;
			int TWDBalance;
			int branchCode;
			int availBalWOD;
			int TDFaceAmt;
			Date accDueDate;
		    String 	term1;
			String term2;
			Timestamp accUpdateTimestamp;
			Timestamp accSyncTimestamp;
			String system;
			public int getAccNumber() {
				return accNumber;
			}
			public void setAccNumber(int accNumber) {
				this.accNumber = accNumber;
			}
			    @Id
				@GeneratedValue
			public String getCustId() {
				return custId;
			}
			public void setCustId(String custId) {
				this.custId = custId;
			}
			public String getProductName() {
				return productName;
			}
			public void setProductName(String productName) {
				this.productName = productName;
			}
			public String getCurrencyCode() {
				return currencyCode;
			}
			public void setCurrencyCode(String currencyCode) {
				this.currencyCode = currencyCode;
			}
			public int getInterest() {
				return interest;
			}
			public void setInterest(int interest) {
				this.interest = interest;
			}
			public int getProductType() {
				return productType;
			}
			public void setProductType(int productType) {
				this.productType = productType;
			}
			public int getProductSubType() {
				return productSubType;
			}
			public void setProductSubType(int productSubType) {
				this.productSubType = productSubType;
			}
			public String getStatus() {
				return status;
			}
			public void setStatus(String status) {
				this.status = status;
			}
			public Date getOpenDate() {
				return openDate;
			}
			public void setOpenDate(Date openDate) {
				this.openDate = openDate;
			}
			public Date getCloseDate() {
				return closeDate;
			}
			public void setCloseDate(Date closeDate) {
				this.closeDate = closeDate;
			}
			public int getTWDBalance() {
				return TWDBalance;
			}
			public void setTWDBalance(int tWDBalance) {
				TWDBalance = tWDBalance;
			}
			public int getBranchCode() {
				return branchCode;
			}
			public void setBranchCode(int branchCode) {
				this.branchCode = branchCode;
			}
			public int getAvailBalWOD() {
				return availBalWOD;
			}
			public void setAvailBalWOD(int availBalWOD) {
				this.availBalWOD = availBalWOD;
			}
			public int getTDFaceAmt() {
				return TDFaceAmt;
			}
			public void setTDFaceAmt(int tDFaceAmt) {
				TDFaceAmt = tDFaceAmt;
			}
			public Date getAccDueDate() {
				return accDueDate;
			}
			public void setAccDueDate(Date accDueDate) {
				this.accDueDate = accDueDate;
			}
			public String getTerm1() {
				return term1;
			}
			public void setTerm1(String term1) {
				this.term1 = term1;
			}
			public String getTerm2() {
				return term2;
			}
			public void setTerm2(String term2) {
				this.term2 = term2;
			}
			public Timestamp getAccUpdateTimestamp() {
				return accUpdateTimestamp;
			}
			public void setAccUpdateTimestamp(Timestamp accUpdateTimestamp) {
				this.accUpdateTimestamp = accUpdateTimestamp;
			}
			public Timestamp getAccSyncTimestamp() {
				return accSyncTimestamp;
			}
			public void setAccSyncTimestamp(Timestamp accSyncTimestamp) {
				this.accSyncTimestamp = accSyncTimestamp;
			}
			public String getSystem() {
				return system;
			}
			public void setSystem(String system) {
				this.system = system;
			}
  
	
	
	
	
	
}
