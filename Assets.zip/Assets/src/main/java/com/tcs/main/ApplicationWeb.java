package com.tcs.main;

//import org.slf4j.Logger;
///import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ApplicationWeb {
	/*@Autowired
	static Logger logger ;*/
	public static void main(String[]args) {
		
		
		SpringApplication.run(ApplicationWeb.class, args);
		
		/*logger.error("Message logged at ERROR level");
	    logger.warn("Message logged at WARN level");
	    logger.info("Message logged at INFO level");
	    logger.debug("Message logged at DEBUG level");*/
	}

}
