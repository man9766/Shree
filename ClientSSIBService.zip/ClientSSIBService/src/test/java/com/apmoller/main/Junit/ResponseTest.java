package com.apmoller.main.Junit;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.when;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;

import com.apmoller.main.controller.ConsumerRestController;
import com.apmoller.main.model.RequestData;
import com.apmoller.main.model.ResponseData;
import com.apmoller.utility.RequestValidation;



@RunWith(MockitoJUnitRunner.class)
public class ResponseTest {
	
	@Mock
	private ConsumerRestController restContMock;
	
	@Mock
	private RequestValidation requestValidationMock;
	
	@InjectMocks
	private RequestValidation requestValidation;
	
	/*@Test
	public void testResponse()
	{
		ConsumerRestController restContMock;
		ConsumerRestController forActualResponse = null;
		
		restContMock = Mockito.mock(ConsumerRestController.class);
		
		
		RequestData requestData = new RequestData();
		ResponseData responseData = new ResponseData();
		responseData.setMessage("SUCCESS");
		responseData.setResponseCode("0000");
		
		
		requestData.setBookedByCustomerCd("1");
		requestData.setContractualCustomerCd("contractualCustomerCd");
		requestData.setEndSiteCode("endSiteCode");
		requestData.setOperater("operater");
		requestData.setPriceOwnerCd("priceOwnerCd");
		requestData.setShipmentId("shipmentId");
		requestData.setShipperCd("shipperCd");
		requestData.setStartSiteCode("startSiteCode");
		
		
		 when(restContMock.index(requestData))
         .thenReturn(responseData);
		 
		ResponseData ActualResponseData =  responseData;
		  verify(restContMock).index(requestData);
	   		
	}*/
	
	@Test
	public void testResponseForValidationClass()
	{
		
		RequestValidation requestValidationMock;
		RequestValidation requestValidation = new RequestValidation();
		requestValidationMock = Mockito.mock(RequestValidation.class);
		
		RequestData requestData = new RequestData();
		ResponseData responseData = new ResponseData();
		responseData.setMessage("SUCCESS");
		responseData.setResponseCode("0000");
		
		
		requestData.setBookedByCustomerCd("gvfgyy");
		requestData.setContractualCustomerCd("contractualCustomerCd");
		requestData.setEndSiteCode("endSiteCode");
		requestData.setOperater("fdf");
		requestData.setPriceOwnerCd("priceOwnerCd");
		requestData.setShipmentId("shipmentId");
		requestData.setShipperCd("shipperCd");
		requestData.setStartSiteCode("startSiteCode");
		
		
		 
	/*	 boolean actual = requestValidation.validateRequestData(requestData);	
		 System.out.println(actual);*/
		  
	      //verify(requestValidationMock, atLeastOnce()).validateRequestData(requestData);
		
		
		  when(requestValidationMock.validateRequestData(requestData))
          .thenReturn(true);
		 
		 assertEquals(requestValidationMock.validateRequestData(requestData), true);
	        
	       assertTrue(true);
	}
	private void assertTrue(boolean actual) {
		// TODO Auto-generated method stub
		
	}
	

}
