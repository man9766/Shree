package com.apmoller.main.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.netflix.feign.FeignClient;
import org.springframework.hateoas.Resources;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.apmoller.main.model.RequestData;
import com.apmoller.main.model.ResponseData;


@RestController
public class ConsumerRestController {

	private final RestTemplate restTemplate;

	@Autowired
	public ConsumerRestController(RestTemplate restTemplate) {
		this.restTemplate = restTemplate;
	}

	private static final Logger logger = LoggerFactory
			.getLogger(ConsumerRestController.class);

	/*@RequestMapping(value = "/clientprocessrequest", method = RequestMethod.POST)
	public ResponseData index(@RequestBody RequestData addDetails) {

		logger.info("Inside processrequest Controller");
		ResponseData response = restTemplate.postForObject(
				"http://CBESERVICE/processrequest", addDetails,
				ResponseData.class);
		logger.info("Outside processrequest Controller");
		return response;
	}
	*/
	@FeignClient("CBESSIBService")
	@RequestMapping(value = "/getR",consumes = "application/hal+json")
	interface ReservationFeignClient {
	  @RequestMapping(value = "/processrequest", method = RequestMethod.GET)
	  Resources<RequestData> processInputData();
	}

}
