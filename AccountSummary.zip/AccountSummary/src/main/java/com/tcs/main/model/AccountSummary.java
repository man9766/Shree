package com.tcs.main.model;

import java.io.Serializable;
import java.util.List;

import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection="AccountSummary_1255668")
public class AccountSummary implements Serializable{
	public List<LiabilityDetails> loans;
	public List<AssetDetails> assets;
	public int customerId;
	public List<LiabilityDetails> getLoans() {
		return loans;
	}
	public void setLoans(List<LiabilityDetails> loans) {
		this.loans = loans;
	}
	public List<AssetDetails> getAssets() {
		return assets;
	}
	public void setAssets(List<AssetDetails> assets) {
		this.assets = assets;
	}
	public int getCustomerId() {
		return customerId;
	}
	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}
	
	

}
