package com.tcs.main.controller;

import java.net.URI;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.websocket.server.PathParam;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import ch.qos.logback.classic.spi.STEUtil;

import com.tcs.main.Application;
import com.tcs.main.model.AccountSummary;
import com.tcs.main.model.AssetDetails;
import com.tcs.main.model.LiabilityDetails;

@RestController
public class AccountOverviewController {
	RestTemplate rt=new RestTemplate();
	@RequestMapping(value="/	" ,method=RequestMethod.GET)
	public String ping(){
		return "Ping service is up for Account Summary Micro Service";
	}

	@RequestMapping(value="/getSummary" ,method=RequestMethod.GET)
	public AccountSummary getSummary( @RequestParam int customerId)
	{
		System.out.println("Entered CustId - " + customerId);
		AccountSummary actSummary=new AccountSummary();

		System.out.println("Calling Liability service");
		LiabilityDetails[] user1=rt.getForObject("http://localhost:8085/getLiabilityDetailsById/"+customerId, LiabilityDetails[].class);
		System.out.println("user1 after calling liability service " + user1[0]);
		List<LiabilityDetails> loans = new ArrayList<LiabilityDetails>();

		System.out.println("11111111");
//		if(user1==null){
//			System.out.println("bullable object");
//		}else{
//			System.out.println("2222222222222");
//		}
		for(int i=0;i<user1.length;i++){
			loans.add(user1[i]);
		}

		System.out.println("successfully called liability service");


		System.out.println("Calling Asset service");
		AssetDetails[] user3=rt.getForObject("http://localhost:8084/getAssetById/"+customerId, AssetDetails[].class);

		List<AssetDetails> assets = new ArrayList<AssetDetails>();
		for(int i=0;i<user3.length;i++){
			assets.add(user3[i]);
		}
		

		System.out.println("successfully called Asset service");

		actSummary.setCustomerId(customerId);
		actSummary.setAssets(assets);
		actSummary.setLoans(loans);


		return actSummary;
	}

	@RequestMapping(value="/getAggregate", method=RequestMethod.GET)
	public String getAggregate()
	{
		String output = null;
		AssetDetails[] assets=null;
		LiabilityDetails[] loans = null;
		String url="";
		int active = 0;
		int inactive = 0;
		int nostatus = 0;
		int minBalance=0;
		int maxBalance=0;

		url="http://localhost:8084/getAssetList";

		assets= rt.getForObject(url, AssetDetails[].class);
		int totalBalance=0;
		for(int i =0;i<assets.length;i++)
		{

			totalBalance = totalBalance +assets[i].getBalance();
			if(assets[i].getStatus().equalsIgnoreCase("active"))
			{

				active++;
			}
			else if(assets[i].getStatus().equalsIgnoreCase("inactive"))
			{
				inactive++;
			}
			else nostatus++;

		}
		int i=0;
		if(i==0)
		{
			minBalance = assets[i].getBalance();
			maxBalance = assets[i].getBalance();

		}else{
			if(minBalance > assets[i].getBalance()){
				minBalance = assets[i].getBalance();
			}
			if(maxBalance < assets[i].getBalance()){
				maxBalance = assets[i].getBalance();
			}
		}
		if(assets[i].getCloseDate()!=null)
		{
			int closedAccounts=0;
			closedAccounts++;


			int AvarageBalance = totalBalance/assets.length;
			output = "Assets : - " + "\n";
			output = output + "Total Assets - " + assets.length + "\n";
			output = output + "Active Assets - " + active + "\n";
			output = output + "Inactive Assets - " + inactive + "\n";
			output = output + "Assets with no status - " + nostatus + "\n";		
			output = output + "Total balance - " + totalBalance + "\n";
			output = output + "Average balance - " + AvarageBalance + "\n";
			/*output = output + "minimum balance - " + minBalance + "\n";
			output = output + "maximum balance - " + maxBalance + "\n";*/
			output = output + "Closed Accounts - " + closedAccounts + "\n";
		}

		url="http://localhost:8085/getLiabilityList";
		loans= rt.getForObject(url, LiabilityDetails[].class);
		int closedAccounts = 0;
		int AccountNo;
		String loanType="";
		String openDate="";
		String closeDate="";
		String status="";
		int totalLoanBalance=0;
		int totalPaidBalance=0;
		int totalLeftBalance=0;

		for(int i1=0;i1<loans.length;i1++)
		{
			totalLeftBalance=totalLeftBalance+loans[i1].getLeftBalance();
			totalPaidBalance=totalPaidBalance+loans[i1].getPaidBalance();
			totalLoanBalance=totalLoanBalance+loans[i1].getLoanBalance();
			
			if(loans[i1].getCloseDate()!=null)
			{
				closedAccounts++;
			}
		}

		output= output+"######"+"\n";
		output=output+"liabilities details"+"\n";
		output=output+"total liabilities:"+loans.length+"\n";
		output = output + "Active Assets - " + active + "\n";
		output = output + "Inactive Assets - " + inactive + "\n";
		
		output=output+"totalLoanAmount:"+totalLoanBalance+"\n";
		output=output+"totalPaidBalance:"+totalPaidBalance+"\n";
		output=output+"totalLeftBalance:"+totalLeftBalance+"\n";

		return output;

	}
}






