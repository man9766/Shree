package com.tcs.main;

import java.net.URI;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;


//import com.tcs.main.model.User;

@SpringBootApplication
public class Application {

	public static void main(String args[]){
		
		SpringApplication.run(Application.class, args);
		
//		
//		RestTemplate rt=new RestTemplate();
//		
//		
//		HttpHeaders ht= new HttpHeaders();
//		ht.setContentType(MediaType.APPLICATION_JSON);
//		HttpEntity<Object> e= new HttpEntity<Object>("parameters" , ht);
//		ResponseEntity<Object> user1=rt.exchange("http://localhost:8085/getLiabilityDetailsById/2", HttpMethod.GET,e, Object.class);
//		{
//		System.out.println("dfd"+user1.getBody().toString());
//		}
//		
//		HttpEntity<Object> e1= new HttpEntity<Object>("parameters" , ht);
//		ResponseEntity<Object> user2=rt.exchange("http://localhost:8084/getAssetById/2", HttpMethod.GET,e, Object.class);
//		System.out.println("loan details"+user2.getBody().toString());
	}
	}

