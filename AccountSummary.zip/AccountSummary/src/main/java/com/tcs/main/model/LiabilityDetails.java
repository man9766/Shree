package com.tcs.main.model;

import java.io.Serializable;


public class LiabilityDetails implements Serializable {
	int customerId;
	int AccountNo;
	String loanType;
	String openDate;
	String closeDate;
	String status;
	int loanBalance;
	int paidBalance;
	int leftBalance;
	
	public int getCustomerId() {
		return customerId;
	}
	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}
	public int getAccountNo() {
		return AccountNo;
	}
	public void setAccountNo(int accountNo) {
		this.AccountNo = accountNo;
	}
	public String getLoanType() {
		return loanType;
	}
	public void setLoanType(String loanType) {
		this.loanType = loanType;
	}
	public String getOpenDate() {
		return openDate;
	}
	public void setOpenDate(String openDate) {
		this.openDate = openDate;
	}
	public String getCloseDate() {
		return closeDate;
	}
	public void setCloseDate(String closeDate) {
		this.closeDate = closeDate;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public int getLoanBalance() {
		return loanBalance;
	}
	public void setLoanBalance(int loanBalance) {
		this.loanBalance = loanBalance;
	}
	public int getPaidBalance() {
		return paidBalance;
	}
	public void setPaidBalance(int paidBalance) {
		this.paidBalance = paidBalance;
	}
	public int getLeftBalance() {
		return leftBalance;
	}
	public void setLeftBalance(int leftBalance) {
		this.leftBalance = leftBalance;
	}
	
	
	
	
}
