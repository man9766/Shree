package co.tcs.kafka.produce.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.stream.annotation.EnableBinding;
import org.springframework.context.annotation.Bean;
import org.springframework.integration.support.MessageBuilder;
import org.springframework.kafka.support.KafkaHeaders;
import org.springframework.messaging.Message;
import org.springframework.messaging.MessageHeaders;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import co.tcs.kafka.produce.config.Source;
import co.tcs.kafka.produce.model.Employee;
import co.tcs.kafka.produce.model.Student;

@RestController
@EnableBinding(Source.class)
public class ProduceController {
	@Autowired
	public Source source;


	/* public ProduceController(Source source) {
        this.source = source;
    }*/
	public void sayHello(Employee emp) {

		//source.mytopic1().send(MessageBuilder.withPayload(emp).setHeader(KafkaHeaders.PARTITION_ID, 0).build());
		source.mytopic1().send(MessageBuilder.withPayload(emp).build());
	}

	public void sayHello_1(Employee emp) {

		//source.mytopic1().send(MessageBuilder.withPayload(emp).setHeader(KafkaHeaders.PARTITION_ID, 1).build());
		source.mytopic1().send(MessageBuilder.withPayload(emp).build());
	}


	public void sayHello_2(Employee emp) {

		//source.mytopic1().send(MessageBuilder.withPayload(emp).setHeader(KafkaHeaders.PARTITION_ID, 2).build());
		source.mytopic1().send(MessageBuilder.withPayload(emp).build());
	}
	
	public void sayHello_11(Employee emp) {

		source.mytopic1().send(MessageBuilder.withPayload(emp).setHeader(KafkaHeaders.PARTITION_ID, 0).build());
		//source.mytopic1().send(MessageBuilder.withPayload(emp).build());
	}

	public void sayHello_22(Employee emp) {

		source.mytopic1().send(MessageBuilder.withPayload(emp).setHeader(KafkaHeaders.PARTITION_ID, 1).build());
//		source.mytopic1().send(MessageBuilder.withPayload(emp).build());
	}


	public void sayHello_33(Employee emp) {

		source.mytopic1().send(MessageBuilder.withPayload(emp).setHeader(KafkaHeaders.PARTITION_ID, 2).build());
//		source.mytopic1().send(MessageBuilder.withPayload(emp).build());
	}
	

/*	public void sayHello_topic2(Student emp) {

		source.mytopic2().send(MessageBuilder.withPayload(emp).build());
	}
*/
	@RequestMapping("/test1")
	public String timerMessageSource() {
		final Employee emp= new Employee();
		emp.setId(0);
		emp.setEmpId("00000");
		emp.setName("mytopic1-part-0");
/*		Message<Employee> mes= new Message<Employee>() {

			public Employee getPayload() {
				Employee emp1 = new Employee();
				emp1.setEmpId("one two");
				emp1.setName(" mytopic11");
				return emp;
			}

			public MessageHeaders getHeaders() {
				//MessageHeaders mesageHeader= new MessageHeaders();
				return null;
			}
		};*/

		sayHello(emp);
		return  "Data sent to mytopic1 - partition 0";
	}


	@RequestMapping("/test2")
	public String timerMessageSource1() {
		Employee emp= new Employee();
		emp.setId(1);
		emp.setEmpId("11111");
		emp.setName("mytopic1-part-1");
		sayHello_1(emp);
		return  "Data sent to mytopic1 - partition 1";
	}
	
	@RequestMapping("/test3")
	public String timerMessageSource2() {
		Employee emp= new Employee();
		emp.setId(2);
		emp.setEmpId("22222");
		emp.setName("mytopic1-part-2");
		sayHello_2(emp);
		return  "Data sent to mytopic1 - partition 2";
	}
	
	@RequestMapping("/test11")
	public String timerMessageSource11() {
		final Employee emp= new Employee();
		emp.setId(0);
		emp.setEmpId("00000");
		emp.setName("mytopic1-part-0");
/*		Message<Employee> mes= new Message<Employee>() {

			public Employee getPayload() {
				Employee emp1 = new Employee();
				emp1.setEmpId("one two");
				emp1.setName(" mytopic11");
				return emp;
			}

			public MessageHeaders getHeaders() {
				//MessageHeaders mesageHeader= new MessageHeaders();
				return null;
			}
		};*/

		sayHello_11(emp);
		return  "Data sent to mytopic1 - partition 0";
	}


	@RequestMapping("/test22")
	public String timerMessageSource22() {
		Employee emp= new Employee();
		emp.setId(1);
		emp.setEmpId("11111");
		emp.setName("mytopic1-part-1");
		sayHello_22(emp);
		return  "Data sent to mytopic1 - partition 1";
	}
	
	@RequestMapping("/test33")
	public String timerMessageSource33() {
		Employee emp= new Employee();
		emp.setId(2);
		emp.setEmpId("22222");
		emp.setName("mytopic1-part-2");
		sayHello_33(emp);
		return  "Data sent to mytopic1 - partition 2";
	}
	
/*	@RequestMapping("/testStudent")
	public String timerMessageSource3() {
		Student emp= new Student();
		emp.setStudId("22222");
		emp.setStudName("mytopic1-part-2");
		sayHello_topic2(emp);
		return  "Data sent to mytopic2 - Student data";
	}*/
}
