package co.tcs.kafka.produce.config;

import org.springframework.cloud.stream.binder.PartitionKeyExtractorStrategy;

public interface PartationKeyProduce extends PartitionKeyExtractorStrategy {

}
