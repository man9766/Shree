package co.tcs.kafka.produce;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.stream.annotation.EnableBinding;
import org.springframework.cloud.stream.messaging.Source;

@SpringBootApplication
//@EnableBinding(Source.class)
public class KafkaProduceApplication {
	
	public static void main(String [] args){
		
		SpringApplication.run(KafkaProduceApplication.class, args);
	}

}
