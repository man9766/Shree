package co.tcs.kafka.produce.config;

import org.springframework.cloud.stream.annotation.Output;
import org.springframework.context.annotation.Bean;
import org.springframework.messaging.MessageChannel;
import org.springframework.stereotype.Component;
@Component
public interface Source {
	
	 @Output("mytopic1")	//mytopic1
	  MessageChannel mytopic1();
	
	/* @Output("mytopic2")	//mytopic2
	  MessageChannel mytopic2();*/



}
