package co.tcs.kafka.produce.model;

public class Student {

	public String getStudId() {
		return studId;
	}
	public void setStudId(String studId) {
		this.studId = studId;
	}
	private String studName;
	public String getStudName() {
		return studName;
	}
	public void setStudName(String studName) {
		this.studName = studName;
	}
	private String studId;
	@Override
	public String toString() {
		return "Student [studName=" + studName + ", studId=" + studId + "]";
	}
	
	

}
