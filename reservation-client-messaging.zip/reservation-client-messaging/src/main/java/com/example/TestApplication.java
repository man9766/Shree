package com.example;

import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

/*import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.ServiceInstance;
import org.springframework.cloud.client.circuitbreaker.EnableCircuitBreaker;
import org.springframework.cloud.client.discovery.DiscoveryClient;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;
import org.springframework.cloud.client.loadbalancer.LoadBalanced;
import org.springframework.cloud.netflix.eureka.EnableEurekaClient;
import org.springframework.cloud.netflix.feign.EnableFeignClients;
import org.springframework.cloud.netflix.feign.FeignClient;
import org.springframework.cloud.netflix.zuul.EnableZuulProxy;
import org.springframework.cloud.stream.annotation.EnableBinding;
import org.springframework.cloud.stream.messaging.Source;
import org.springframework.context.MessageSource;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.hateoas.Resources;
import org.springframework.hateoas.config.EnableHypermediaSupport;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.integration.annotation.InboundChannelAdapter;
import org.springframework.messaging.Message;
import org.springframework.messaging.support.MessageBuilder;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;*/

/*@EnableBinding(Source.class)
@EnableHypermediaSupport(type = EnableHypermediaSupport.HypermediaType.HAL)
@EnableDiscoveryClient
@EnableCircuitBreaker
@EnableZuulProxy*/
//@SpringBootApplication
public class TestApplication {
	
	/*@LoadBalanced
	@Bean
	public RestTemplate restTemplate() {
	    return new RestTemplate();
	}
	
		
	public static void main(String[] args) {
		SpringApplication.run(TestApplication.class, args);
	}*/

}

/*
//Kafka Example 
@RestController
@RequestMapping("/reservationskafka")
class ReservationKafkaRestController {	

	@Autowired
	private Source source;
	
	//@Bean
	@RequestMapping(method=RequestMethod.POST, value="/string")
	@InboundChannelAdapter(Source.OUTPUT)
	public Message<String> writeReservationString(@RequestBody Reservation r){
		Message<String> msg = MessageBuilder.withPayload(r.getReservationName()).build();
		//this.source.output().send(msg);
		return msg;
	}
	
	//@Bean
	@RequestMapping(method=RequestMethod.POST, value="/object")
	@InboundChannelAdapter(Source.OUTPUT)
	public Message<Reservation> writeReservationObject(@RequestBody Reservation r){
		Message<Reservation> msg = MessageBuilder.withPayload(r).build();
		//this.source.output().send(msg);
		return msg;
	}	
}


//RESTTemplate Example 
@RestController
@RequestMapping("/reservations")
class ReservationApiGatewayRestController {	
	
	@Autowired
	private RestTemplate restTemplate;
	
	@RequestMapping(method=RequestMethod.GET, value="/names")
	public Collection<String> getReservationNames(){
		
		ParameterizedTypeReference<Resources<Reservation>> ptr = new ParameterizedTypeReference<Resources<Reservation>>() {
		};
		
		//ResponseEntity<Resources<Reservation>> entity = this.restTemplate.exchange("http://localhost:9999/reservation-service/reservations", HttpMethod.GET, null, ptr);	//This is a test for restTemplate
		ResponseEntity<Resources<Reservation>> entity = this.restTemplate.exchange("http://reservation-service/reservations", HttpMethod.GET, null, ptr);
		
		return entity
				.getBody()
				.getContent()
				.stream()
				.map(Reservation::getReservationName)
				.collect(Collectors.toList());
	}
	
}


@RestController
class PingService {
	@RequestMapping(method=RequestMethod.GET, value="/ping")
	public String ping(){
		return "Ping service is up";
		
	}
}


@Component
class Reservation {
	private String reservationName;

	public void setReservationName(String reservationName) {
		this.reservationName = reservationName;
	}

	public String getReservationName() {
		return reservationName;
	}
	
	@Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("Reservation{");
        sb.append("reservationName='").append(reservationName).append('\'');
        sb.append('}');
        return sb.toString();
    }

}
*/