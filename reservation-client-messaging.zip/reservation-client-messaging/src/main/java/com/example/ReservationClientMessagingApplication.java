package com.example;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.circuitbreaker.EnableCircuitBreaker;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;
import org.springframework.cloud.client.loadbalancer.LoadBalanced;
import org.springframework.cloud.netflix.zuul.EnableZuulProxy;
import org.springframework.cloud.stream.annotation.EnableBinding;
import org.springframework.cloud.stream.annotation.Output;
import org.springframework.cloud.stream.messaging.Source;
import org.springframework.context.annotation.Bean;
import org.springframework.integration.annotation.InboundChannelAdapter;
import org.springframework.integration.core.MessageSource;
import org.springframework.messaging.Message;
import org.springframework.messaging.MessageChannel;
import org.springframework.messaging.support.GenericMessage;
import org.springframework.messaging.support.MessageBuilder;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.client.RestTemplate;

import java.text.SimpleDateFormat;
import java.util.Date;

//Create the output channel to send the message over
interface ReservationClientChannels {
	@Output
	MessageChannel output();
}

@EnableDiscoveryClient
@EnableCircuitBreaker
@EnableZuulProxy
@SpringBootApplication
@EnableBinding(ReservationClientChannels.class)
public class ReservationClientMessagingApplication {

	@Bean
	@LoadBalanced
	RestTemplate restTemplate() {
		return new RestTemplate();
	}
	public static void main(String[] args) {
		SpringApplication.run(ReservationClientMessagingApplication.class, args);
	}
	
//	@Bean
//    @InboundChannelAdapter(value = Source.OUTPUT)		//Continuously sends the messages to the channel
//    public MessageSource<String> timerMessageSource() {
//        return () -> new GenericMessage<>(new SimpleDateFormat().format(new Date()));
//    }
	
	
}

/*//Kafka Example 
@RestControllerAdvice
@RequestMapping("/reservationskafka")
class ReservationKafkaRestController {	
	@Bean
    @InboundChannelAdapter(value = Source.OUTPUT)
	@RequestMapping(method=RequestMethod.POST, value="/string")
    public MessageSource<String> writeMessageString(@RequestBody Reservation r) {
        return () -> new GenericMessage<>(r.getReservationName());
    }
}*/

//Kafka Example 
@RestController
@RequestMapping("/reservations")
class ReservationApiGatewayRestController {
	
//	@Autowired
//	@LoadBalanced
	private final RestTemplate restTemplate;

	private final MessageChannel reservationService;

	@Autowired
	public ReservationApiGatewayRestController(
			ReservationClientChannels channels,
			@LoadBalanced RestTemplate restTemplate) {
		this.restTemplate = restTemplate;
		this.reservationService = channels.output();
	}

	
	/*//Send string data over output channel (json format)
	@RequestMapping(method = RequestMethod.POST, value="/string")
	public void writeString(@RequestBody Reservation reservation) {

		String reservationName = reservation.getReservationName();

		Message<String> msg = MessageBuilder
				.withPayload(reservationName)
				.build();

		this.reservationService.send(msg);
	}*/
	
	//Send Object (POJO) data over output channel (json format)
	@RequestMapping(method = RequestMethod.POST, value="/object")
	public void writeObject(@RequestBody Reservation reservation) {
		Message<Reservation> msg = MessageBuilder
				.withPayload(reservation)
				.build();

		this.reservationService.send(msg);
	}
}

@RestController
class PingService {
	@RequestMapping(method=RequestMethod.GET, value="/ping")
	public String ping(){
		return "Ping service is up for ReservationClientMessaging Service";
		
	}
}

@Component
class Reservation {
	private Long id;
	private String reservationName;

	public void setReservationName(String reservationName) {
		this.reservationName = reservationName;
	}

	public String getReservationName() {
		return reservationName;
	}
	
	@Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("Reservation{");
        sb.append("reservationName='").append(reservationName).append('\'');
        sb.append('}');
        return sb.toString();
    }

}

