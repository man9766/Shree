package com.apmoller.main.exception;

public interface ErrorCodes {

    String CustomerNotFoundException="Customer Not Found In Database";
    
    

}