package com.apmoller.main.exception;

public class BaseException extends RuntimeException {

	public BaseException(String message) {
		// TODO Auto-generated constructor stub
		super(message);
	}

}
