package com.apmoller.main.exception;

public class CustomerNotFoundException extends BaseException {
//...
	public CustomerNotFoundException(String custid)
	{
		super(ErrorCodes.CustomerNotFoundException+" "+ custid);
	}
	
}
