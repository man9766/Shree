package com.apmoller.main;

import java.net.URI;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.web.client.RestTemplateBuilder;
import org.springframework.cloud.client.circuitbreaker.EnableCircuitBreaker;
import org.springframework.cloud.netflix.hystrix.dashboard.EnableHystrixDashboard;
import org.springframework.context.annotation.Bean;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

@EnableCircuitBreaker
@RestController
@SpringBootApplication
@EnableHystrixDashboard
@EnableAutoConfiguration
public class WebApplication {

	@Autowired
	private Services service;

	@Bean
	public RestTemplate rest(RestTemplateBuilder builder) {
		return builder.build();
	}

	
	
	/*@RequestMapping(value="/getassetBalance/{custId}" ,method=RequestMethod.GET)
	  public String getAssetBalance( @PathVariable(value="custId") String custId)
	  {
		 RestTemplate restTemplate = new RestTemplate();
	    URI uri = URI.create("http://localhost:8088/assetSummary/getAssetBalById/"+custId);
	    return restTemplate.getForObject(uri, String.class);
	  }
	*/
	
	
	
	@RequestMapping("/getassetBalance/{custId}")
	public String GetAssetService(@PathVariable(value = "custId") String custId) {
		System.out.println("#####"+ custId);
		return service.getAssetBalance(custId);
	}

	/*
	 * @RequestMapping("/to-read") public String readingList() { RestTemplate
	 * restTemplate = new RestTemplate(); URI uri =
	 * URI.create("http://localhost:8090/recommended"); System.out.println(uri);
	 * return restTemplate.getForObject(uri, String.class); }
	 */

	public static void main(String[] args) {
		SpringApplication.run(WebApplication.class, args);
	}

}
