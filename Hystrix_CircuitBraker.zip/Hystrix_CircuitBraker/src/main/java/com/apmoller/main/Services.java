package com.apmoller.main;

import java.net.URI;

import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.client.RestTemplate;

import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;

@Service
public class Services {
	 private final RestTemplate restTemplate;

	  public Services(RestTemplate rest) {
	    this.restTemplate = rest;
	  }

	  @HystrixCommand(fallbackMethod = "reliable"/*,commandProperties = {
			    @HystrixProperty(name = "circuitBreaker.sleepWindowInMilliseconds", value = "20000"),
			    @HystrixProperty(name = "execution.isolation.thread.timeoutInMilliseconds", value = "5000"),
			    @HystrixProperty(name = "circuitBreaker.errorThresholdPercentage", value = "10")
			}*/)
	  public String getAssetBalance(String custId)
	  {
		  System.out.println("CustomerID: "+ custId);
	    URI uri = URI.create("http://localhost:8088/assetSummary/getAssetBalById/"+custId);
	    String response= restTemplate.getForObject(uri, String.class);
	    if(response == null){
	    	System.out.println("CustomerId not found");
	    }
	    return response;
	  }

	  
	  
	  
	  
	  public String reliable(String custId) {
		   
		  return "Asset service is down";
	  }

}
